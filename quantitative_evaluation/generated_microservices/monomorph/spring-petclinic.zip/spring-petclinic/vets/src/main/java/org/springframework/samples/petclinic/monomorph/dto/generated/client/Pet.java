package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.*;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;

// Client proxy imports for related entities
import org.springframework.samples.petclinic.monomorph.dto.generated.client.PetType;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.Visit;

// gRPC infrastructure imports
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;

// Java standard library imports
import java.time.LocalDate;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Auto-generated DTO gRPC client for
 * {@code org.springframework.samples.petclinic.owner.Pet}, wrapping {@link PetDTO}.
 */
public class Pet {

	private PetDTO dtoInstance;

	/**
	 * Default constructor. Initializes an empty Pet with a default DTO instance.
	 */
	public Pet() {
		this.dtoInstance = PetDTO.newBuilder().build();
	}

	/**
	 * Private constructor to initialize from a DTO instance. Used by the fromDTO factory
	 * method.
	 * @param dtoInstance The DTO instance to wrap.
	 */
	private Pet(PetDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
	}

	// mapping methods
	public PetDTO toDTO() {
		return this.dtoInstance;
	}

	public static Pet fromDTO(PetDTO dtoInstance) {
		return new Pet(dtoInstance);
	}

	// TARGET_SERVICE_ID is the unique ID for the ClassA service, provided by the tool
	private static final String TARGET_SERVICE_ID = "customers";

	// --- gRPC Specific Fields ---
	private ManagedChannel businessChannel; // Channel for RPC calls

	private PetServiceGrpc.PetServiceBlockingStub businessStub; // Use this stub for RPC
																// calls

	// Helper methods for gRPC
	protected void performRpcSetup() throws Exception {
		// Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
		ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
		this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
				.build();
		this.businessStub = PetServiceGrpc.newBlockingStub(this.businessChannel);
	}

	protected void performSubclassRpcCleanup() {
		// ... shutdown logic for businessChannel ...
		if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
			try {
				this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
				if (!this.businessChannel.isTerminated()) {
					this.businessChannel.shutdownNow();
				}
			}
			catch (InterruptedException e) {
				// Restore the interrupted status
				Thread.currentThread().interrupt();
			}
		}
	}

	// Implement required methods for gRPC calls here
	// --- START OF gRPC METHOD IMPLEMENTATIONS ---

	/**
	 * Adds a visit to this pet via a gRPC call. The internal state of this Pet object is
	 * updated with the response from the service.
	 * @param visit The Visit client proxy object to add.
	 */
	public void addVisit(Visit visit) {
		try {
			performRpcSetup();
			AddVisitRequest request = AddVisitRequest.newBuilder().setPet(this.toDTO()).setVisit(visit.toDTO()).build();
			AddVisitResponse response = this.businessStub.addVisit(request);
			// Update the internal DTO with the result from the service
			this.dtoInstance = response.getPet();
		}
		catch (Exception e) {
			throw new RuntimeException("gRPC call to addVisit failed", e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	// --- END OF gRPC METHOD IMPLEMENTATIONS ---

	// Implement all other getters and setters corresponding to the DTO fields
	// --- START OF DTO GETTERS AND SETTERS ---

	public Long getId() {
		return this.dtoInstance.getId();
	}

	public void setId(Long id) {
		this.dtoInstance = this.dtoInstance.toBuilder().setId(id).build();
	}

	public boolean isNew() {
		return this.dtoInstance.getId() == 0;
	}

	public String getName() {
		return this.dtoInstance.getName();
	}

	public void setName(String name) {
		this.dtoInstance = this.dtoInstance.toBuilder().setName(name).build();
	}

	public void setBirthDate(LocalDate birthDate) {
		if (birthDate != null) {
			this.dtoInstance = this.dtoInstance.toBuilder().setBirthDate(birthDate.toString()).build();
		}
	}

	public LocalDate getBirthDate() {
		if (this.dtoInstance.getBirthDate() == null || this.dtoInstance.getBirthDate().isEmpty()) {
			return null;
		}
		return LocalDate.parse(this.dtoInstance.getBirthDate());
	}

	public PetType getType() {
		// Reconstruct the PetType client proxy from the flattened typeName field in the
		// DTO
		PetType type = new PetType();
		type.setName(this.dtoInstance.getTypeName());
		return type;
	}

	public void setType(PetType type) {
		if (type != null) {
			this.dtoInstance = this.dtoInstance.toBuilder().setTypeName(type.getName()).build();
		}
	}

	public Collection<Visit> getVisits() {
		// Convert the list of VisitDTOs from the wrapped DTO into a collection of Visit
		// client proxies
		return this.dtoInstance.getVisitsList().stream().map(Visit::fromDTO)
				.collect(Collectors.toCollection(LinkedHashSet::new));
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}