package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.*;

// Java standard library imports
import java.time.LocalDate;

/**
 * Auto-generated DTO gRPC client for
 * {@code org.springframework.samples.petclinic.owner.Visit} and {@link VisitDTO}. This
 * class uses composition to wrap the DTO and expose an API identical to the original
 * class.
 */
public class Visit {

	private VisitDTO dtoInstance;

	/**
	 * Public constructor to initialize from a DTO instance.
	 * @param dtoInstance The DTO instance to wrap.
	 */
	public Visit(VisitDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
	}

	/**
	 * Creates a new instance of Visit for the current date, mirroring the original
	 * class's behavior.
	 */
	public Visit() {
		LocalDate today = LocalDate.now();
		com.google.type.Date protoDate = com.google.type.Date.newBuilder().setYear(today.getYear())
				.setMonth(today.getMonthValue()).setDay(today.getDayOfMonth()).build();
		this.dtoInstance = VisitDTO.newBuilder().setDate(protoDate).build();
	}

	// mapping methods
	public VisitDTO toDTO() {
		return this.dtoInstance;
	}

	public static Visit fromDTO(VisitDTO dtoInstance) {
		return new Visit(dtoInstance);
	}

	// implementation of the gRPC exposed methods
	// No service methods were defined in the proto, so this section remains empty.

	// Implement all other getters and setters corresponding to the DTO fields
	// --- START OF DTO GETTERS AND SETTERS ---

	public Integer getId() {
		return this.dtoInstance.getId();
	}

	public void setId(Integer id) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		if (id != null) {
			builder.setId(id);
		}
		else {
			// proto3 int32 defaults to 0, which is the representation for a cleared
			// field.
			builder.clearId();
		}
		this.dtoInstance = builder.build();
	}

	public LocalDate getDate() {
		if (!this.dtoInstance.hasDate()) {
			return null;
		}
		com.google.type.Date protoDate = this.dtoInstance.getDate();
		// A default google.type.Date has all fields as 0, which is not a valid LocalDate.
		if (protoDate.getYear() == 0 && protoDate.getMonth() == 0 && protoDate.getDay() == 0) {
			return null;
		}
		return LocalDate.of(protoDate.getYear(), protoDate.getMonth(), protoDate.getDay());
	}

	public void setDate(LocalDate date) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		if (date != null) {
			com.google.type.Date protoDate = com.google.type.Date.newBuilder().setYear(date.getYear())
					.setMonth(date.getMonthValue()).setDay(date.getDayOfMonth()).build();
			builder.setDate(protoDate);
		}
		else {
			builder.clearDate();
		}
		this.dtoInstance = builder.build();
	}

	public String getDescription() {
		return this.dtoInstance.getDescription();
	}

	public void setDescription(String description) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		if (description != null) {
			builder.setDescription(description);
		}
		else {
			// proto3 string defaults to empty string.
			builder.clearDescription();
		}
		this.dtoInstance = builder.build();
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}