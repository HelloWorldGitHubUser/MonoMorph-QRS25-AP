package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.owner.*;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.PetDTO;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;

// Java standard library imports
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Auto-generated DTO gRPC client for
 * {@code org.springframework.samples.petclinic.owner.Owner}. This class uses composition
 * to wrap {@link OwnerDTO} and provides the same public API as the original class,
 * delegating remote operations via gRPC.
 */
public class Owner {

	private OwnerDTO dtoInstance;

	/**
	 * Default constructor. Initializes a new Owner with an empty DTO.
	 */
	public Owner() {
		this.dtoInstance = OwnerDTO.newBuilder().build();
	}

	/**
	 * Private constructor to initialize from a DTO instance. Used by the fromDTO factory
	 * method.
	 * @param dtoInstance The DTO to wrap.
	 */
	private Owner(OwnerDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
	}

	// mapping methods
	public OwnerDTO toDTO() {
		return this.dtoInstance;
	}

	public static Owner fromDTO(OwnerDTO dtoInstance) {
		return new Owner(dtoInstance);
	}

	// implementation of the gRPC exposed methods

	// TARGET_SERVICE_ID is the unique ID for the Owner service, provided by the tool
	private static final String TARGET_SERVICE_ID = "customers";

	// --- gRPC Specific Fields ---
	private ManagedChannel businessChannel; // Channel for RPC calls

	private OwnerServiceGrpc.OwnerServiceBlockingStub businessStub; // Use this stub for
																	// RPC calls

	// Helper methods for gRPC
	protected void performRpcSetup() throws Exception {
		// Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
		ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
		this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
				.build();
		this.businessStub = OwnerServiceGrpc.newBlockingStub(this.businessChannel);
	}

	protected void performRpcCleanup() {
		if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
			try {
				this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
				if (!this.businessChannel.isTerminated()) {
					this.businessChannel.shutdownNow();
				}
			}
			catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	// --- START OF gRPC METHOD IMPLEMENTATIONS ---

	/**
	 * Adds the given {@link Visit} to the {@link Pet} with the given identifier by making
	 * a gRPC call.
	 * @param petId the identifier of the {@link Pet}, must not be {@literal null}.
	 * @param visit the visit to add, must not be {@literal null}.
	 * @return The updated Owner instance.
	 */
	public Owner addVisit(Integer petId, Visit visit) {
		try {
			performRpcSetup();
			AddVisitRequest request = AddVisitRequest.newBuilder().setOwner(this.toDTO()).setPetId(petId)
					.setVisit(visit.toDTO()).build();

			AddVisitResponse response = this.businessStub.addVisit(request);
			this.dtoInstance = response.getOwner(); // Update internal state with the
													// result
			return this;
		}
		catch (Exception e) {
			throw new RuntimeException("gRPC call to addVisit failed", e);
		}
		finally {
			performRpcCleanup();
		}
	}

	/**
	 * Return the Pet with the given name by making a gRPC call.
	 * @param name to test
	 * @return a pet if pet name is found, otherwise null.
	 */
	public Pet getPet(String name) {
		return getPet(name, false); // Delegate to the more specific implementation
	}

	/**
	 * Return the Pet with the given id by making a gRPC call.
	 * @param id to test
	 * @return a pet if pet id is found, otherwise null.
	 */
	public Pet getPet(Integer id) {
		try {
			performRpcSetup();
			GetPetByIdRequest request = GetPetByIdRequest.newBuilder().setOwner(this.toDTO()).setId(id).build();

			GetPetResponse response = this.businessStub.getPetById(request);
			return response.hasPet() ? Pet.fromDTO(response.getPet()) : null;
		}
		catch (Exception e) {
			throw new RuntimeException("gRPC call to getPet(Integer) failed", e);
		}
		finally {
			performRpcCleanup();
		}
	}

	/**
	 * Return the Pet with the given name by making a gRPC call.
	 * @param name to test
	 * @param ignoreNew flag to ignore new pets
	 * @return a pet if pet name is found, otherwise null.
	 */
	public Pet getPet(String name, boolean ignoreNew) {
		try {
			performRpcSetup();
			GetPetByNameExtendedRequest request = GetPetByNameExtendedRequest.newBuilder().setOwner(this.toDTO())
					.setName(name).setIgnoreNew(ignoreNew).build();

			GetPetResponse response = this.businessStub.getPetByNameExtended(request);
			return response.hasPet() ? Pet.fromDTO(response.getPet()) : null;
		}
		catch (Exception e) {
			throw new RuntimeException("gRPC call to getPet(String, boolean) failed", e);
		}
		finally {
			performRpcCleanup();
		}
	}

	// --- END OF gRPC METHOD IMPLEMENTATIONS ---

	// --- START OF DTO GETTERS AND SETTERS ---

	public Integer getId() {
		return this.dtoInstance.hasId() ? this.dtoInstance.getId() : null;
	}

	public void setId(Integer id) {
		OwnerDTO.Builder builder = this.dtoInstance.toBuilder();
		if (id == null) {
			builder.clearId();
		}
		else {
			builder.setId(id);
		}
		this.dtoInstance = builder.build();
	}

	public boolean isNew() {
		return getId() == null;
	}

	public String getFirstName() {
		return this.dtoInstance.getFirstName();
	}

	public void setFirstName(String firstName) {
		this.dtoInstance = this.dtoInstance.toBuilder().setFirstName(firstName).build();
	}

	public String getLastName() {
		return this.dtoInstance.getLastName();
	}

	public void setLastName(String lastName) {
		this.dtoInstance = this.dtoInstance.toBuilder().setLastName(lastName).build();
	}

	public String getAddress() {
		return this.dtoInstance.getAddress();
	}

	public void setAddress(String address) {
		this.dtoInstance = this.dtoInstance.toBuilder().setAddress(address).build();
	}

	public String getCity() {
		return this.dtoInstance.getCity();
	}

	public void setCity(String city) {
		this.dtoInstance = this.dtoInstance.toBuilder().setCity(city).build();
	}

	public String getTelephone() {
		return this.dtoInstance.getTelephone();
	}

	public void setTelephone(String telephone) {
		this.dtoInstance = this.dtoInstance.toBuilder().setTelephone(telephone).build();
	}

	public List<Pet> getPets() {
		return this.dtoInstance.getPetsList().stream().map(Pet::fromDTO).collect(Collectors.toList());
	}

	public void addPet(Pet pet) {
		if (pet.isNew()) {
			// Create a new list of PetDTOs to maintain immutability
			List<PetDTO> updatedPets = this.dtoInstance.getPetsList().stream().collect(Collectors.toList());
			updatedPets.add(pet.toDTO());

			this.dtoInstance = this.dtoInstance.toBuilder().clearPets().addAllPets(updatedPets).build();
		}
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}