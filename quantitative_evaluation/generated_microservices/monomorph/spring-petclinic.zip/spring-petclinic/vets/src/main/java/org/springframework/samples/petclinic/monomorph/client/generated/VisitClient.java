package org.springframework.samples.petclinic.monomorph.client.generated;

import org.springframework.samples.petclinic.monomorph.id.shared.client.AbstractRefactoredClient;
import org.springframework.samples.petclinic.monomorph.id.shared.RefactoredObjectID;
import org.springframework.samples.petclinic.monomorph.id.generated.client.VisitServiceGrpc;
import org.springframework.samples.petclinic.monomorph.id.generated.client.VisitServiceOuterClass;
import org.springframework.samples.petclinic.monomorph.id.generated.client.CreateVisitRequest;
import org.springframework.samples.petclinic.monomorph.id.generated.client.VisitId;
import org.springframework.samples.petclinic.monomorph.id.generated.client.GetVisitRequest;
import org.springframework.samples.petclinic.monomorph.id.generated.client.UpdateVisitRequest;
import org.springframework.samples.petclinic.monomorph.id.generated.client.DeleteVisitRequest;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry.ServiceEndpoint;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class VisitClient extends AbstractRefactoredClient {

	private VisitServiceGrpc.VisitServiceBlockingStub blockingStub;
	private ManagedChannel channel;

	// Default constructor for new objects
	public VisitClient() {
		super();
	}

	// Constructor for existing IDs
	public VisitClient(RefactoredObjectID existingObjectId) {
		super(existingObjectId);
	}

	@Override
	protected void performRpcSetup() throws Exception {
		ServiceEndpoint serviceEndpoint = ServiceRegistry.getEndpoint("visits");
		String host = serviceEndpoint.getHost();
		int port = serviceEndpoint.getPort();
		this.channel = ManagedChannelBuilder.forAddress(host, port)
				.usePlaintext()
				.build();
		this.blockingStub = VisitServiceGrpc.newBlockingStub(channel);
	}

	@Override
	protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
		if (args.length != 1 || !(args[0] instanceof VisitDTO)) {
			throw new IllegalArgumentException("Expected a single argument of type VisitDTO for creation.");
		}
		VisitDTO visitDto = (VisitDTO) args[0];
		CreateVisitRequest request = CreateVisitRequest.newBuilder().setVisit(visitDto).build();
		VisitId visitId = blockingStub.createVisit(request).getVisitId();
		return RefactoredObjectID.newBuilder()
				.setInstanceID(String.valueOf(visitId.getId()))
				.setClassID(VisitDTO.class.getSimpleName())
				.setServiceID("visits")
				.build();
	}

	@Override
	protected void performSubclassRpcCleanup() {
		if (channel != null) {
			channel.shutdown();
		}
	}

	public static VisitClient fromID(RefactoredObjectID existingId) {
		return new VisitClient(existingId);
	}

	public VisitDTO getVisit() {
		ensureNotClosed();
		GetVisitRequest request = GetVisitRequest.newBuilder()
				.setVisitId(VisitId.newBuilder().setId(Integer.parseInt(objectId.getInstanceID()))).build();
		return blockingStub.getVisit(request).getVisit();
	}

	public VisitDTO updateVisit(VisitDTO visitDto) {
		ensureNotClosed();
		UpdateVisitRequest request = UpdateVisitRequest.newBuilder()
				.setVisitId(VisitId.newBuilder().setId(Integer.parseInt(objectId.getInstanceID()))).setVisit(visitDto).build();
		return blockingStub.updateVisit(request).getVisit();
	}

	public void deleteVisit() {
		ensureNotClosed();
		DeleteVisitRequest request = DeleteVisitRequest.newBuilder()
				.setVisitId(VisitId.newBuilder().setId(Integer.parseInt(objectId.getInstanceID()))).build();
		blockingStub.deleteVisit(request);
	}

}

