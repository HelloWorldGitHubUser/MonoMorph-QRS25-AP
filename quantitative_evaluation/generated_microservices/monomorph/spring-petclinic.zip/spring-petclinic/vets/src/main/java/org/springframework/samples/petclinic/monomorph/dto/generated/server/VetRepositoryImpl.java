package org.springframework.samples.petclinic.monomorph.dto.generated.server;

import io.grpc.stub.StreamObserver;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vetrepository.*;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vet.VetDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.server.VetMapper;
import org.springframework.samples.petclinic.vet.Vet;
import org.springframework.samples.petclinic.vet.VetRepository;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * gRPC Service implementation for VetRepository. - Handles gRPC requests for
 * VetRepository API. - Interacts with Mapper for switching between DTO and VetRepository
 * instances.
 */
public class VetRepositoryImpl extends VetRepositoryServiceGrpc.VetRepositoryServiceImplBase {

	private final VetRepository vetRepository;

	/**
	 * Constructs the service implementation with a dependency on the domain repository.
	 * This uses dependency injection, a standard practice for service-oriented
	 * architectures.
	 * @param vetRepository The business repository for vet data access.
	 */
	public VetRepositoryImpl(VetRepository vetRepository) {
		this.vetRepository = vetRepository;
	}

	// --- Other gRPC methods defined in the proto file ---
	// --- Start of generated code ---

	@Override
	public void findAll(FindAllRequest request, StreamObserver<FindAllResponse> responseObserver) {
		try {
			// The VetRepository is a stateless service injected via the constructor.
			// The VetRepositoryDTO from the request is empty and not used for
			// transformation.

			// Call the corresponding business logic method
			Collection<Vet> vets = this.vetRepository.findAll();

			// Map the domain objects (Vet) to DTOs (VetDTO) using the VetMapper
			List<VetDTO> vetDTOs = vets.stream().map(VetMapper.INSTANCE::toDTO).collect(Collectors.toList());

			// Build and send the response
			FindAllResponse response = FindAllResponse.newBuilder().setDto(VetRepositoryDTO.newBuilder().build()) // Per
																													// proto,
																													// response
																													// includes
																													// an
																													// empty
																													// DTO
					.addAllVets(vetDTOs).build();

			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
		catch (DataAccessException e) {
			responseObserver.onError(io.grpc.Status.INTERNAL
					.withDescription("Failed to retrieve vets: " + e.getMessage()).withCause(e).asRuntimeException());
		}
	}

	@Override
	public void findAllPaged(FindAllPagedRequest request, StreamObserver<FindAllPagedResponse> responseObserver) {
		try {
			// The VetRepository is a stateless service injected via the constructor.
			// The VetRepositoryDTO from the request is empty and not used for
			// transformation.

			// Map the PageableDTO from the request to a Spring Data Pageable object
			PageableDTO pageableDTO = request.getPageable();
			Pageable pageable = PageRequest.of(pageableDTO.getPageNumber(), pageableDTO.getPageSize());

			// Call the corresponding business logic method
			Page<Vet> vetPage = this.vetRepository.findAll(pageable);

			// Map the resulting Page<Vet> to the PageVetDTO for the response
			List<VetDTO> vetDTOs = vetPage.getContent().stream().map(VetMapper.INSTANCE::toDTO)
					.collect(Collectors.toList());

			PageVetDTO pageVetDTO = PageVetDTO.newBuilder().addAllContent(vetDTOs)
					.setTotalElements(vetPage.getTotalElements()).setTotalPages(vetPage.getTotalPages())
					.setNumber(vetPage.getNumber()).setSize(vetPage.getSize()).build();

			// Build and send the response
			FindAllPagedResponse response = FindAllPagedResponse.newBuilder()
					.setDto(VetRepositoryDTO.newBuilder().build()) // Per proto, response
																	// includes an empty
																	// DTO
					.setPage(pageVetDTO).build();

			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
		catch (DataAccessException e) {
			responseObserver
					.onError(io.grpc.Status.INTERNAL.withDescription("Failed to retrieve paged vets: " + e.getMessage())
							.withCause(e).asRuntimeException());
		}
	}
	// --- End of generated code ---

}