package org.springframework.samples.petclinic.owner;

import org.springframework.dao.DataAccessException;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.Owner;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.PetType;
import java.util.List;

public interface OwnerRepository {

	Owner findById(Integer id) throws DataAccessException;

	List<PetType> findPetTypes() throws DataAccessException;

	void save(Owner owner) throws DataAccessException;

}
