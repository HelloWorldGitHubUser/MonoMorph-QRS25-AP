
package org.springframework.samples.petclinic.monomorph.dto.generated.server;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vet.VetDTO;
import org.springframework.samples.petclinic.vet.Vet;

/**
 * Auto-generated MapStruct mapper for converting between {@link Vet} and {@link VetDTO}.
 */
@Mapper(componentModel = "default")
public interface VetMapper {

	/**
	 * Singleton instance of this mapper. Use this to access mapping methods.
	 */
	VetMapper INSTANCE = Mappers.getMapper(VetMapper.class);

	/**
	 * Maps from {@link VetDTO} to {@link Vet}.
	 * @param dto The source DTO object.
	 * @return The mapped {@link Vet} object.
	 */
	Vet fromDTO(VetDTO dto);

	/**
	 * Maps from {@link Vet} to {@link VetDTO}.
	 * @param original The source of the Original object.
	 * @return The mapped {@link VetDTO} object.
	 */
	VetDTO toDTO(Vet domain);

}