
package org.springframework.samples.petclinic.monomorph.dto.generated.server;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.specialty.SpecialtyDTO;
import org.springframework.samples.petclinic.vet.Specialty;

/**
 * Auto-generated MapStruct mapper for converting between {@link Specialty} and
 * {@link SpecialtyDTO}.
 */
@Mapper(componentModel = "default")
public interface SpecialtyMapper {

	/**
	 * Singleton instance of this mapper. Use this to access mapping methods.
	 */
	SpecialtyMapper INSTANCE = Mappers.getMapper(SpecialtyMapper.class);

	/**
	 * Maps from {@link SpecialtyDTO} to {@link Specialty}.
	 * @param dto The source DTO object.
	 * @return The mapped {@link Specialty} object.
	 */
	Specialty fromDTO(SpecialtyDTO dto);

	/**
	 * Maps from {@link Specialty} to {@link SpecialtyDTO}.
	 * @param original The source of the Original object.
	 * @return The mapped {@link SpecialtyDTO} object.
	 */
	SpecialtyDTO toDTO(Specialty domain);

}