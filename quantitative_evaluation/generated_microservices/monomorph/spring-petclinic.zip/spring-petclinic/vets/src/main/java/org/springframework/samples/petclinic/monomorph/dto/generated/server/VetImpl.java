package org.springframework.samples.petclinic.monomorph.dto.generated.server;

import io.grpc.stub.StreamObserver;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vet.GetNrOfSpecialtiesRequest;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vet.GetNrOfSpecialtiesResponse;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vet.VetDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vet.VetServiceGrpc;
import org.springframework.samples.petclinic.vet.Vet;

/**
 * gRPC Service implementation for Vet. - Handles gRPC requests for Vet API. - Interacts
 * with Mapper for switching between DTO and Vet instances.
 */
public class VetImpl extends VetServiceGrpc.VetServiceImplBase {

	@Override
	public void getNrOfSpecialties(GetNrOfSpecialtiesRequest request,
			StreamObserver<GetNrOfSpecialtiesResponse> responseObserver) {
		// Retrieve the DTO from the request
		VetDTO requestDto = request.getDto();

		// Map the DTO to the original domain class
		Vet vet = VetMapper.INSTANCE.fromDTO(requestDto);

		// Call the corresponding business logic method
		int nrOfSpecialties = vet.getNrOfSpecialties();

		// Build and send the response
		// Since getNrOfSpecialties() is a read-only operation, the state of the vet
		// object
		// does not change. We can reuse the request DTO for the response.
		GetNrOfSpecialtiesResponse response = GetNrOfSpecialtiesResponse.newBuilder().setDto(requestDto)
				.setResult(nrOfSpecialties).build();

		responseObserver.onNext(response);
		responseObserver.onCompleted();
	}

}
