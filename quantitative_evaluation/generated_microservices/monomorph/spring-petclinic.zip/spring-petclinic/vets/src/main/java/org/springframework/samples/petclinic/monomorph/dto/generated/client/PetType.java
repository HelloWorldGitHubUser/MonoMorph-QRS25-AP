package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pettype.PetTypeDTO;

/**
 * Auto-generated DTO gRPC client for the PetType data object, which corresponds to the
 * {@link PetTypeDTO} message. This class acts as a client-side representation of the
 * PetType entity, using composition to manage its state via the DTO.
 */
public class PetType {

	private PetTypeDTO dtoInstance;

	/**
	 * Default constructor to create a new, empty PetType instance.
	 */
	public PetType() {
		this.dtoInstance = PetTypeDTO.newBuilder().build();
	}

	/**
	 * Private constructor to initialize from a DTO instance. Used by the fromDTO factory
	 * method.
	 * @param dtoInstance The DTO instance to wrap.
	 */
	private PetType(PetTypeDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
	}

	// mapping methods
	public PetTypeDTO toDTO() {
		return this.dtoInstance;
	}

	public static PetType fromDTO(PetTypeDTO dtoInstance) {
		return new PetType(dtoInstance);
	}

	// implementation of the gRPC exposed methods
	// No gRPC service methods were defined in the proto definition for PetType.

	// Implement all other getters and setters corresponding to the DTO fields
	// --- START OF DTO GETTERS AND SETTERS ---

	public Integer getId() {
		return this.dtoInstance.getId();
	}

	public void setId(Integer id) {
		PetTypeDTO.Builder builder = this.dtoInstance.toBuilder();
		if (id == null) {
			builder.clearId();
		}
		else {
			builder.setId(id);
		}
		this.dtoInstance = builder.build();
	}

	public String getName() {
		return this.dtoInstance.getName();
	}

	public void setName(String name) {
		PetTypeDTO.Builder builder = this.dtoInstance.toBuilder();
		if (name == null) {
			builder.clearName();
		}
		else {
			builder.setName(name);
		}
		this.dtoInstance = builder.build();
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}
