package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.specialty.*;

/**
 * Auto-generated DTO gRPC client for
 * {@code org.springframework.samples.petclinic.vet.Specialty}. This class uses
 * composition to wrap the DTO {@link SpecialtyDTO}.
 */
public class Specialty {

	private SpecialtyDTO dtoInstance;

	/**
	 * Private constructor to create an instance from a DTO. Used by the fromDTO factory
	 * method.
	 * @param dtoInstance The DTO to wrap.
	 */
	private Specialty(SpecialtyDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
	}

	/**
	 * Public no-argument constructor for API compatibility. Initializes with a default
	 * DTO instance.
	 */
	public Specialty() {
		this.dtoInstance = SpecialtyDTO.newBuilder().build();
	}

	/**
	 * Returns the internal DTO instance.
	 * @return The {@link SpecialtyDTO} instance.
	 */
	public SpecialtyDTO toDTO() {
		return this.dtoInstance;
	}

	/**
	 * Factory method to create a new client instance from a DTO.
	 * @param dtoInstance The DTO to be wrapped.
	 * @return A new {@link Specialty} client instance.
	 */
	public static Specialty fromDTO(SpecialtyDTO dtoInstance) {
		if (dtoInstance == null) {
			return new Specialty();
		}
		return new Specialty(dtoInstance);
	}

	// No gRPC service methods were defined in the proto file.

	// Implement all other getters and setters corresponding to the DTO fields
	// --- START OF DTO GETTERS AND SETTERS ---

	/**
	 * Gets the ID of the specialty. Corresponds to the 'id' field in the DTO.
	 * @return The specialty ID.
	 */
	public Integer getId() {
		return this.dtoInstance.getId();
	}

	/**
	 * Sets the ID of the specialty. Updates the internal DTO instance.
	 * @param id The specialty ID. A null value will be mapped to the default (0).
	 */
	public void setId(Integer id) {
		SpecialtyDTO.Builder builder = this.dtoInstance.toBuilder();
		if (id != null) {
			builder.setId(id);
		}
		else {
			builder.clearId();
		}
		this.dtoInstance = builder.build();
	}

	/**
	 * Gets the name of the specialty. Corresponds to the 'name' field in the DTO.
	 * @return The specialty name.
	 */
	public String getName() {
		return this.dtoInstance.getName();
	}

	/**
	 * Sets the name of the specialty. Updates the internal DTO instance.
	 * @param name The specialty name. A null value will be mapped to the default ("").
	 */
	public void setName(String name) {
		SpecialtyDTO.Builder builder = this.dtoInstance.toBuilder();
		if (name != null) {
			builder.setName(name);
		}
		else {
			builder.clearName();
		}
		this.dtoInstance = builder.build();
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}