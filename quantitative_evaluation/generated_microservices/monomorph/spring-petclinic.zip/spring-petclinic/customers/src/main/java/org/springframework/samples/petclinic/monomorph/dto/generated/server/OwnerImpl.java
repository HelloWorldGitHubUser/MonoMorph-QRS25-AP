package org.springframework.samples.petclinic.monomorph.dto.generated.server;

import io.grpc.stub.StreamObserver;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.owner.*;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.PetDTO;
import org.springframework.samples.petclinic.owner.Owner;
import org.springframework.samples.petclinic.owner.Pet;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.Visit;

/**
 * gRPC Service implementation for Owner. - Handles gRPC requests for Owner API. -
 * Interacts with Mapper for switching between DTO and Owner instances.
 */
public class OwnerImpl extends OwnerServiceGrpc.OwnerServiceImplBase {

	// --- Start of generated code ---

	/**
	 * Implements the AddVisit RPC method. Maps the request DTOs to domain objects, calls
	 * the business logic, and maps the result back to a response DTO.
	 */
	@Override
	public void addVisit(AddVisitRequest request, StreamObserver<AddVisitResponse> responseObserver) {
		// Map the DTO to the original class
		Owner owner = OwnerMapper.INSTANCE.fromDTO(request.getOwner());
		Visit visit = Visit.fromDTO(request.getVisit());

		// Call the corresponding business logic method
		Owner updatedOwner = owner.addVisit(request.getPetId(), visit);

		// Map the output back to the DTO
		OwnerDTO responseDto = OwnerMapper.INSTANCE.toDTO(updatedOwner);

		// Build and send the response
		AddVisitResponse response = AddVisitResponse.newBuilder().setOwner(responseDto).build();
		responseObserver.onNext(response);
		responseObserver.onCompleted();
	}

	/**
	 * Implements the GetPetByName RPC method. Maps the request DTO to a domain object,
	 * calls the business logic, and maps the resulting Pet domain object (if found) to a
	 * response DTO.
	 */
	@Override
	public void getPetByName(GetPetByNameRequest request, StreamObserver<GetPetResponse> responseObserver) {
		// Map the DTO to the original class
		Owner owner = OwnerMapper.INSTANCE.fromDTO(request.getOwner());

		// Call the corresponding business logic method
		Pet pet = owner.getPet(request.getName());

		// Build the response
		GetPetResponse.Builder responseBuilder = GetPetResponse.newBuilder();
		if (pet != null) {
			PetDTO petDto = PetMapper.INSTANCE.toDTO(pet);
			responseBuilder.setPet(petDto);
		}
		responseObserver.onNext(responseBuilder.build());
		responseObserver.onCompleted();
	}

	/**
	 * Implements the GetPetById RPC method. Maps the request DTO to a domain object,
	 * calls the business logic, and maps the resulting Pet domain object (if found) to a
	 * response DTO.
	 */
	@Override
	public void getPetById(GetPetByIdRequest request, StreamObserver<GetPetResponse> responseObserver) {
		// Map the DTO to the original class
		Owner owner = OwnerMapper.INSTANCE.fromDTO(request.getOwner());

		// Call the corresponding business logic method
		Pet pet = owner.getPet(request.getId());

		// Build the response
		GetPetResponse.Builder responseBuilder = GetPetResponse.newBuilder();
		if (pet != null) {
			PetDTO petDto = PetMapper.INSTANCE.toDTO(pet);
			responseBuilder.setPet(petDto);
		}
		responseObserver.onNext(responseBuilder.build());
		responseObserver.onCompleted();
	}

	/**
	 * Implements the GetPetByNameExtended RPC method. Maps the request DTO to a domain
	 * object, calls the business logic with extended parameters, and maps the resulting
	 * Pet domain object (if found) to a response DTO.
	 */
	@Override
	public void getPetByNameExtended(GetPetByNameExtendedRequest request,
			StreamObserver<GetPetResponse> responseObserver) {
		// Map the DTO to the original class
		Owner owner = OwnerMapper.INSTANCE.fromDTO(request.getOwner());

		// Call the corresponding business logic method
		Pet pet = owner.getPet(request.getName(), request.getIgnoreNew());

		// Build the response
		GetPetResponse.Builder responseBuilder = GetPetResponse.newBuilder();
		if (pet != null) {
			PetDTO petDto = PetMapper.INSTANCE.toDTO(pet);
			responseBuilder.setPet(petDto);
		}
		responseObserver.onNext(responseBuilder.build());
		responseObserver.onCompleted();
	}

	// --- End of generated code ---

}