package org.springframework.samples.petclinic.monomorph.dto.generated.client.support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Basic {@code Page} implementation. This class is intended to mimic the behavior of
 * Spring Data's PageImpl class.
 *
 * @param <T> the type of the elements in this page.
 */
public class PageImpl<T> implements Page<T>, Serializable {

	private static final long serialVersionUID = 867755909294344406L;

	private final List<T> content = new ArrayList<>();

	private final Pageable pageable;

	private final long total;

	/**
	 * Creates a new {@link PageImpl} with the given content and {@link Pageable}.
	 * @param content the content of this page, must not be {@literal null}.
	 * @param pageable the paging information, must not be {@literal null}.
	 * @param total the total amount of items available.
	 */
	public PageImpl(List<T> content, Pageable pageable, long total) {

		if (content == null) {
			throw new IllegalArgumentException("Content must not be null!");
		}

		this.content.addAll(content);
		this.pageable = pageable;
		this.total = total;
	}

	/**
	 * Creates a new {@link PageImpl} with the given content.
	 * @param content the content of this page, must not be {@literal null}.
	 */
	public PageImpl(List<T> content) {
		this(content, Pageable.unpaged(), (content == null) ? 0 : content.size());
	}

	@Override
	public int getNumber() {
		return pageable == null ? 0 : pageable.getPageNumber();
	}

	@Override
	public int getSize() {
		return pageable == null ? 0 : pageable.getPageSize();
	}

	@Override
	public int getTotalPages() {
		return getSize() == 0 ? 1 : (int) Math.ceil((double) total / (double) getSize());
	}

	@Override
	public long getTotalElements() {
		return total;
	}

	@Override
	public boolean hasNext() {
		return getNumber() + 1 < getTotalPages();
	}

	@Override
	public boolean hasPrevious() {
		return getNumber() > 0;
	}

	@Override
	public boolean isFirst() {
		return !hasPrevious();
	}

	@Override
	public boolean isLast() {
		return !hasNext();
	}

	@Override
	public List<T> getContent() {
		return Collections.unmodifiableList(content);
	}

	// Removed @Override as isEmpty() is not in the Page interface
	public boolean isEmpty() {
		return content.isEmpty();
	}

	@Override
	public Pageable getPageable() {
		return pageable;
	}

	@Override
	public <U> Page<U> map(Function<? super T, ? extends U> converter) {
		return new PageImpl<>(getConvertedContent(converter), getPageable(), total);
	}

	protected <U> List<U> getConvertedContent(Function<? super T, ? extends U> converter) {
		return this.content.stream().map(converter).collect(Collectors.toList());
	}

	@Override
	public Iterator<T> iterator() {
		return this.content.iterator();
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}

		if (!(obj instanceof PageImpl)) {
			return false;
		}

		PageImpl<?> that = (PageImpl<?>) obj;

		return this.total == that.total && this.content.equals(that.content) && this.pageable.equals(that.pageable);
	}

	@Override
	public int hashCode() {

		int result = 17;

		result += 31 * (int) (total ^ (total >>> 32));
		result += 31 * content.hashCode();
		result += 31 * pageable.hashCode();

		return result;
	}

	@Override
	public String toString() {

		String contentType = "UNKNOWN";
		String content = "[]";

		if (!this.content.isEmpty()) {
			contentType = this.content.get(0).getClass().getName();
			content = this.content.toString();
		}

		return String.format("Page %s of %d containing %s instances", getNumber() + 1, getTotalPages(), contentType);
	}

}
