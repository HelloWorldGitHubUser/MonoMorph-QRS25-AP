package org.springframework.samples.petclinic.monomorph.client.generated;

import org.springframework.samples.petclinic.monomorph.id.shared.RefactoredObjectID;
import org.springframework.samples.petclinic.monomorph.id.shared.client.AbstractRefactoredClient;

public class VisitClient extends AbstractRefactoredClient {

	private VisitClient(RefactoredObjectID id) {
		super(id);
	}

	public static VisitClient fromID(RefactoredObjectID id) {
		return new VisitClient(id);
	}

	@Override
	protected void performSubclassRpcCleanup() {
		// No specific RPC cleanup needed for VisitClient yet
	}

	@Override
	protected void performRpcSetup() throws Exception {
		// No specific RPC setup needed for VisitClient yet
	}

	@Override
	protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
		// This client is for existing IDs, so remote creation is not applicable here.
		// If this client were to support creation, this method would be implemented.
		throw new UnsupportedOperationException("VisitClient does not support remote creation via this method.");
	}

}
