package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vetrepository.*;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;

// Assumed client-side support classes for pagination, mirroring Spring Data's API.
import org.springframework.samples.petclinic.monomorph.dto.generated.client.support.Page;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.support.Pageable;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.support.PageImpl;

// Assumed Spring framework dependencies are available on the client-side.
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Auto-generated DTO gRPC client for {@link VetRepository} and {@link VetRepositoryDTO}.
 * This class provides the same API as the original repository interface but delegates
 * calls to a remote gRPC service. It implements AutoCloseable to manage the gRPC channel
 * lifecycle.
 */
public class VetRepository implements AutoCloseable {

	private final VetRepositoryDTO dtoInstance;

	/**
	 * Default constructor. Initializes the gRPC connection.
	 */
	public VetRepository() {
		this.dtoInstance = VetRepositoryDTO.newBuilder().build();
		try {
			performRpcSetup();
		}
		catch (Exception e) {
			throw new RuntimeException("Failed to setup gRPC client for VetRepository", e);
		}
	}

	/**
	 * Constructor to initialize from a DTO instance. Used by the fromDTO factory method.
	 * @param dtoInstance The DTO instance to use.
	 */
	public VetRepository(VetRepositoryDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
		try {
			performRpcSetup();
		}
		catch (Exception e) {
			throw new RuntimeException("Failed to setup gRPC client for VetRepository", e);
		}
	}

	// mapping methods
	public VetRepositoryDTO toDTO() {
		return this.dtoInstance;
	}

	public static VetRepository fromDTO(VetRepositoryDTO dtoInstance) {
		return new VetRepository(dtoInstance);
	}

	// implementation of the gRPC exposed methods

	// TARGET_SERVICE_ID is the unique ID for the ClassA service, provided by the tool
	private static final String TARGET_SERVICE_ID = "vets";

	// --- gRPC Specific Fields ---
	private ManagedChannel businessChannel; // Channel for RPC calls

	private VetRepositoryServiceGrpc.VetRepositoryServiceBlockingStub businessStub; // Use
																					// this
																					// stub
																					// for
																					// RPC
																					// calls

	// Helper methods for gRPC
	protected void performRpcSetup() throws Exception {
		// Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
		ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
		this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
				.build();
		this.businessStub = VetRepositoryServiceGrpc.newBlockingStub(this.businessChannel);
	}

	protected void performSubclassRpcCleanup() {
		// ... shutdown logic for businessChannel ...
		if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
			try {
				this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
				if (!this.businessChannel.isTerminated()) {
					this.businessChannel.shutdownNow();
				}
			}
			catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	@Override
	public void close() {
		performSubclassRpcCleanup();
	}

	// Implement required methods for gRPC calls here
	// --- START OF gRPC METHOD IMPLEMENTATIONS ---

	/**
	 * Retrieve all <code>Vet</code>s from the remote data store. Corresponds to the
	 * FindAll RPC.
	 * @return a <code>Collection</code> of <code>Vet</code>s
	 * @throws DataAccessException if the gRPC call fails
	 */
	public Collection<Vet> findAll() throws DataAccessException {
		try {
			FindAllRequest request = FindAllRequest.newBuilder().setDto(this.dtoInstance).build();
			FindAllResponse response = this.businessStub.findAll(request);
			return response.getVetsList().stream().map(Vet::fromDTO).collect(Collectors.toList());
		}
		catch (StatusRuntimeException e) {
			throw new DataAccessResourceFailureException("gRPC call to VetRepository.findAll failed", e);
		}
	}

	/**
	 * Retrieve all <code>Vet</code>s from the remote data store in Pages. Corresponds to
	 * the FindAllPaged RPC.
	 * @param pageable The pagination information.
	 * @return a <code>Page</code> of <code>Vet</code>s
	 * @throws DataAccessException if the gRPC call fails
	 */
	public Page<Vet> findAll(Pageable pageable) throws DataAccessException {
		try {
			PageableDTO pageableDto = PageableDTO.newBuilder().setPageNumber(pageable.getPageNumber())
					.setPageSize(pageable.getPageSize()).build();

			FindAllPagedRequest request = FindAllPagedRequest.newBuilder().setDto(this.dtoInstance)
					.setPageable(pageableDto).build();

			FindAllPagedResponse response = this.businessStub.findAllPaged(request);
			PageVetDTO pageDto = response.getPage();

			List<Vet> content = pageDto.getContentList().stream().map(Vet::fromDTO).collect(Collectors.toList());

			return new PageImpl<>(content, pageable, pageDto.getTotalElements());
		}
		catch (StatusRuntimeException e) {
			throw new DataAccessResourceFailureException("gRPC call to VetRepository.findAll(Pageable) failed", e);
		}
	}

	// --- END OF gRPC METHOD IMPLEMENTATIONS ---

	// Implement all other getters and setters corresponding to the DTO fields
	// --- START OF DTO GETTERS AND SETTERS ---
	// VetRepositoryDTO is empty, so there are no getters or setters to implement.
	// --- END OF DTO GETTERS AND SETTERS ---

}
