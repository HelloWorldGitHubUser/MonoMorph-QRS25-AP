package org.springframework.samples.petclinic.monomorph.dto.generated.server;

import io.grpc.stub.StreamObserver;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.Visit;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.AddVisitRequest;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.AddVisitResponse;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.PetDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.PetServiceGrpc;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;
import org.springframework.samples.petclinic.owner.Pet;

/**
 * gRPC Service implementation for Pet. - Handles gRPC requests for Pet API. - Interacts
 * with Mapper for switching between DTO and Pet instances.
 */
public class PetImpl extends PetServiceGrpc.PetServiceImplBase {

	@Override
	public void addVisit(AddVisitRequest request, StreamObserver<AddVisitResponse> responseObserver) {
		// Retrieve DTOs from the request
		PetDTO petDto = request.getPet();
		VisitDTO visitDto = request.getVisit();

		// Map DTOs to domain/proxy objects
		Pet pet = PetMapper.INSTANCE.fromDTO(petDto);
		// Per the rules, use the fromDTO static method on the Visit proxy class
		Visit visit = Visit.fromDTO(visitDto);

		// Call the business logic method on the domain object
		pet.addVisit(visit);

		// Map the updated domain object back to a DTO for the response
		PetDTO updatedPetDto = PetMapper.INSTANCE.toDTO(pet);

		// Build and send the response
		AddVisitResponse response = AddVisitResponse.newBuilder().setPet(updatedPetDto).build();
		responseObserver.onNext(response);
		responseObserver.onCompleted();
	}

}