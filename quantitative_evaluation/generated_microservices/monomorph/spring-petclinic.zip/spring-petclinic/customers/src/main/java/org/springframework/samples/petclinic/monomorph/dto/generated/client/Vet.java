package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.vet.*;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.specialty.SpecialtyDTO;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;
import org.springframework.samples.petclinic.model.BaseEntity;

// Java standard library imports
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Auto-generated DTO gRPC client for
 * {@code org.springframework.samples.petclinic.vet.Vet} and {@link VetDTO}.
 */
public class Vet extends BaseEntity {

	private VetDTO dtoInstance;

	/**
	 * Default constructor. Initializes an empty Vet object.
	 */
	public Vet() {
		this.dtoInstance = VetDTO.newBuilder().build();
	}

	private Vet(VetDTO dtoInstance) {
		// Private constructor to initialize from a DTO instance
		this.dtoInstance = dtoInstance;
	}

	// mapping methods
	public VetDTO toDTO() {
		return this.dtoInstance;
	}

	public static Vet fromDTO(VetDTO dtoInstance) {
		return new Vet(dtoInstance);
	}

	// TARGET_SERVICE_ID is the unique ID for the Vet service, provided by the tool
	private static final String TARGET_SERVICE_ID = "vets";

	// --- gRPC Specific Fields ---
	private ManagedChannel businessChannel; // Channel for RPC calls

	private VetServiceGrpc.VetServiceBlockingStub businessStub; // Use this stub for RPC

	// calls

	// Helper methods for gRPC
	protected void performRpcSetup() throws Exception {
		// Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
		ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
		this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
				.build();
		this.businessStub = VetServiceGrpc.newBlockingStub(this.businessChannel);
	}

	protected void performSubclassRpcCleanup() {
		// Shutdown logic for businessChannel
		if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
			try {
				this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
				if (!this.businessChannel.isTerminated()) {
					this.businessChannel.shutdownNow();
				}
			}
			catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	// --- START OF gRPC METHOD IMPLEMENTATIONS ---

	/**
	 * Corresponds to the original getNrOfSpecialties() method. This method makes a remote
	 * gRPC call to the VetService.
	 * @return The number of specialties for this vet.
	 */
	public int getNrOfSpecialties() {
		try {
			performRpcSetup();
			GetNrOfSpecialtiesRequest request = GetNrOfSpecialtiesRequest.newBuilder().setDto(this.toDTO()).build();
			GetNrOfSpecialtiesResponse response = this.businessStub.getNrOfSpecialties(request);
			// Update internal state with the response DTO to ensure consistency
			this.dtoInstance = response.getDto();
			return response.getResult();
		}
		catch (Exception e) {
			// In a real-world application, more sophisticated error handling would be
			// needed.
			// For this example, we'll re-throw as a runtime exception.
			throw new RuntimeException("gRPC call to getNrOfSpecialties failed", e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	// --- END OF gRPC METHOD IMPLEMENTATIONS ---

	// --- START OF DTO GETTERS AND SETTERS ---

	// Note: The original Vet class extends Person, which extends BaseEntity.
	// We replicate the public API of those classes here.

	@Override
	public Integer getId() {
		// In proto3, the default value for int32 is 0. We map 0 to null
		// to align with the original class's use of Integer.
		return this.dtoInstance.getId() == 0 ? null : this.dtoInstance.getId();
	}

	@Override
	public void setId(Integer id) {
		this.dtoInstance = this.dtoInstance.toBuilder().setId(id == null ? 0 : id).build();
	}

	public String getFirstName() {
		return this.dtoInstance.getFirstName();
	}

	public void setFirstName(String firstName) {
		this.dtoInstance = this.dtoInstance.toBuilder().setFirstName(firstName == null ? "" : firstName).build();
	}

	public String getLastName() {
		return this.dtoInstance.getLastName();
	}

	public void setLastName(String lastName) {
		this.dtoInstance = this.dtoInstance.toBuilder().setLastName(lastName == null ? "" : lastName).build();
	}

	/**
	 * Gets the list of specialties. This method converts the internal list of
	 * SpecialtyDTOs to a list of client-side Specialty proxy objects.
	 * @return A list of Specialty objects.
	 */
	public List<Specialty> getSpecialties() {
		return this.dtoInstance.getSpecialtiesList().stream().map(Specialty::fromDTO).collect(Collectors.toList());
	}

	/**
	 * Adds a specialty to this vet. This method mimics the original class's API.
	 * @param specialty The specialty to add.
	 */
	public void addSpecialty(Specialty specialty) {
		if (specialty != null) {
			SpecialtyDTO specialtyDto = specialty.toDTO();
			this.dtoInstance = this.dtoInstance.toBuilder().addSpecialties(specialtyDto).build();
		}
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}
