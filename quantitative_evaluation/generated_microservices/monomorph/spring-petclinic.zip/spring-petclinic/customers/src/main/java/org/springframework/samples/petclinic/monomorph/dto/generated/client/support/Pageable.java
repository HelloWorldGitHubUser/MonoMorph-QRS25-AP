package org.springframework.samples.petclinic.monomorph.dto.generated.client.support;

/**
 * Basic interface for pagination. This interface is intended to mimic the behavior of
 * Spring Data's Pageable interface.
 */
public interface Pageable {

	/**
	 * Returns the page number.
	 * @return the page number.
	 */
	int getPageNumber();

	/**
	 * Returns the page size.
	 * @return the page size.
	 */
	int getPageSize();

	/**
	 * Returns the offset to be applied to the query.
	 * @return the offset to be applied to the query.
	 */
	long getOffset();

	/**
	 * Returns the sorting parameters.
	 * @return the sorting parameters.
	 */
	// Sort getSort(); // Assuming Sort is not needed for now, or will be a separate DTO

	/**
	 * Returns a new {@link Pageable} with the next page number.
	 * @return a new {@link Pageable} with the next page number.
	 */
	Pageable next();

	/**
	 * Returns a new {@link Pageable} with the previous page number.
	 * @return a new {@link Pageable} with the previous page number.
	 */
	Pageable previousOrFirst();

	/**
	 * Returns a new {@link Pageable} with the first page number.
	 * @return a new {@link Pageable} with the first page number.
	 */
	Pageable first();

	/**
	 * Returns whether the current {@link Pageable} is the first one.
	 * @return whether the current {@link Pageable} is the first one.
	 */
	boolean hasPrevious();

	/**
	 * Returns an unpaged {@link Pageable} instance.
	 * @return an unpaged {@link Pageable} instance.
	 */
	static Pageable unpaged() {
		return UnpagedPageable.INSTANCE;
	}

	enum UnpagedPageable implements Pageable {

		INSTANCE;

		@Override
		public int getPageNumber() {
			return 0;
		}

		@Override
		public int getPageSize() {
			return Integer.MAX_VALUE;
		}

		@Override
		public long getOffset() {
			return 0;
		}

		@Override
		public Pageable next() {
			return this;
		}

		@Override
		public Pageable previousOrFirst() {
			return this;
		}

		@Override
		public Pageable first() {
			return this;
		}

		@Override
		public boolean hasPrevious() {
			return false;
		}

	}

}
