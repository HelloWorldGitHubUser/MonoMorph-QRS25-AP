package org.springframework.samples.petclinic.monomorph.id.generated.server;

import com.google.protobuf.Empty;
import io.grpc.stub.StreamObserver;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.owner.OwnerDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pettype.PetTypeDTO;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ClassIdRegistry;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;
import org.springframework.samples.petclinic.monomorph.dto.generated.server.OwnerMapper;
import org.springframework.samples.petclinic.monomorph.dto.generated.server.PetTypeMapper;
import org.springframework.samples.petclinic.monomorph.id.generated.proto.ownerrepository.*;
import org.springframework.samples.petclinic.monomorph.id.shared.RefactoredObjectID;
import org.springframework.samples.petclinic.monomorph.id.shared.server.LeaseManager;
import org.springframework.samples.petclinic.monomorph.id.shared.server.ServerObjectManager;
import org.springframework.samples.petclinic.owner.Owner;
import org.springframework.samples.petclinic.owner.OwnerRepository;
import org.springframework.samples.petclinic.owner.PetType;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * gRPC Service implementation for OwnerRepository. - Handles gRPC requests for
 * OwnerRepository API. - Manages the lifecycle of a singleton OwnerRepository instance. -
 * Interacts with LeaseManager for instance registration/retrieval. - Calls business
 * methods on the retrieved OwnerRepository instance.
 */
public class OwnerRepositoryImpl extends OwnerRepositoryServiceGrpc.OwnerRepositoryServiceImplBase
		implements ServerObjectManager {

	private final LeaseManager leaseManager;

	private final String serviceId = ServiceRegistry.getServiceId();

	private final OwnerRepository ownerRepositoryInstance;

	// Static identifier for the class type managed by this service
	public static final String CLASS_ID = ClassIdRegistry.getClassId("OwnerRepository");

	public OwnerRepositoryImpl(LeaseManager leaseManager, OwnerRepository ownerRepositoryInstance) {
		this.leaseManager = Objects.requireNonNull(leaseManager, "leaseManager cannot be null");
		this.ownerRepositoryInstance = Objects.requireNonNull(ownerRepositoryInstance,
				"ownerRepositoryInstance cannot be null");
	}

	// --- createObject gRPC Method Implementation ---

	@Override
	public void createObject(CreateObjectRequest request, StreamObserver<RefactoredObjectID> responseObserver) {
		try {
			// 1. Extract client ID
			String clientId = request.getClientID();
			// ConstructorArgs is empty for a singleton repository, so no args to process.

			// 2. Use the injected singleton instance
			// The OwnerRepository is a singleton bean managed by the application
			// container.
			// We don't create a new instance; we register the existing one.
			OwnerRepository instance = this.ownerRepositoryInstance;

			// 3. Generate a RefactoredObjectID ID
			RefactoredObjectID responseProto = toID(instance, clientId);

			// 4. Send the response
			responseObserver.onNext(responseProto);
			responseObserver.onCompleted();
		}
		catch (Exception e) {
			responseObserver.onError(e);
		}
	}

	// --- Start of ServerObjectManager method implementations ---
	@Override
	public RefactoredObjectID toID(Object instance, String clientId) throws Exception {
		// Validate if id instance exists
		String instanceId = leaseManager.findInstanceIdForInstance(instance);
		if (instanceId == null) {
			// Generate a new unique instance ID
			instanceId = UUID.randomUUID().toString();
		}
		// Register with LeaseManager
		boolean registered = leaseManager.registerInstanceAndGrantLease(instanceId, CLASS_ID, instance, clientId);
		if (!registered) {
			throw new RuntimeException("Failed to register new instance ID: " + instanceId);
		}
		// Build RefactoredObjectID
		return RefactoredObjectID.newBuilder().setInstanceID(instanceId).setClassID(CLASS_ID)
				.setServiceID(this.serviceId).build();
	}

	@Override
	public RefactoredObjectID toID(Object instance) throws Exception {
		return toID(instance, serviceId);
	}

	@Override
	public OwnerRepository fromID(RefactoredObjectID id) throws Exception {
		// Validate the class ID
		if (id.getClassID() == null || !id.getClassID().equals(CLASS_ID)) {
			throw new IllegalArgumentException("class ID mismatch: expected " + CLASS_ID + ", got " + id.getClassID());
		}
		// Retrieve the instance from LeaseManager
		OwnerRepository instance = (OwnerRepository) leaseManager.getInstance(id.getInstanceID());
		if (instance == null) {
			throw new IllegalArgumentException("No instance found for ID: " + id.getInstanceID());
		}
		return instance;
	}

	@Override
	public String getManagedClassId() {
		return CLASS_ID;
	}

	@Override
	public String getServiceId() {
		return serviceId;
	}
	// --- End of ServerObjectManager method implementations ---

	// --- Other gRPC methods defined in the proto file ---

	@Override
	public void findById(FindByIdRequest request, StreamObserver<FindByIdResponse> responseObserver) {
		try {
			OwnerRepository instance = fromID(request.getObjectId());
			Owner owner = instance.findById(request.getId());

			FindByIdResponse.Builder responseBuilder = FindByIdResponse.newBuilder();
			if (owner != null) {
				OwnerDTO ownerDto = OwnerMapper.INSTANCE.toDTO(owner);
				responseBuilder.setOwner(ownerDto);
			}

			responseObserver.onNext(responseBuilder.build());
			responseObserver.onCompleted();
		}
		catch (Exception e) {
			responseObserver.onError(e);
		}
	}

	@Override
	public void findPetTypes(FindPetTypesRequest request, StreamObserver<FindPetTypesResponse> responseObserver) {
		try {
			OwnerRepository instance = fromID(request.getObjectId());
			List<PetType> petTypes = instance.findPetTypes();

			List<PetTypeDTO> petTypeDTOs = petTypes.stream().map(PetTypeMapper.INSTANCE::toDTO)
					.collect(Collectors.toList());

			FindPetTypesResponse response = FindPetTypesResponse.newBuilder().addAllPetTypes(petTypeDTOs).build();

			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
		catch (Exception e) {
			responseObserver.onError(e);
		}
	}

	@Override
	public void save(SaveRequest request, StreamObserver<Empty> responseObserver) {
		try {
			OwnerRepository instance = fromID(request.getObjectId());
			Owner owner = OwnerMapper.INSTANCE.fromDTO(request.getOwner());
			instance.save(owner);

			responseObserver.onNext(Empty.getDefaultInstance());
			responseObserver.onCompleted();
		}
		catch (Exception e) {
			responseObserver.onError(e);
		}
	}

}
