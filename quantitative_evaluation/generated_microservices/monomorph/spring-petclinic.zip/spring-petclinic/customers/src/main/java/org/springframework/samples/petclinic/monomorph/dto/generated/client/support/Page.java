package org.springframework.samples.petclinic.monomorph.dto.generated.client.support;

import java.util.List;
import java.util.Iterator;
import java.util.function.Function;

/**
 * A page of data. This interface is intended to mimic the behavior of Spring Data's Page
 * interface.
 *
 * @param <T> the type of the elements in this page.
 */
public interface Page<T> extends Iterable<T> {

	/**
	 * Returns the page content as {@link List}.
	 * @return the page content as {@link List}.
	 */
	List<T> getContent();

	/**
	 * Returns the number of the current {@link Page}.
	 * @return the number of the current {@link Page}.
	 */
	int getNumber();

	/**
	 * Returns the size of the {@link Page}.
	 * @return the size of the {@link Page}.
	 */
	int getSize();

	/**
	 * Returns the total amount of elements.
	 * @return the total amount of elements.
	 */
	long getTotalElements();

	/**
	 * Returns the total number of pages.
	 * @return the total number of pages.
	 */
	int getTotalPages();

	/**
	 * Returns if there is a next {@link Page}.
	 * @return if there is a next {@link Page}.
	 */
	boolean hasNext();

	/**
	 * Returns if there is a previous {@link Page}.
	 * @return if there is a previous {@link Page}.
	 */
	boolean hasPrevious();

	/**
	 * Returns if the current {@link Page} is the first one.
	 * @return if the current {@link Page} is the first one.
	 */
	boolean isFirst();

	/**
	 * Returns if the current {@link Page} is the last one.
	 * @return if the current {@link Page} is the last one.
	 */
	boolean isLast();

	/**
	 * Returns the {@link Pageable} that was used to request the current {@link Page}.
	 * @return the {@link Pageable} that was used to request the current {@link Page}.
	 */
	Pageable getPageable();

	/**
	 * Returns the sorting parameters for the {@link Page}.
	 * @return the sorting parameters for the {@link Page}.
	 */
	// Sort getSort(); // Assuming Sort is not needed for now, or will be a separate DTO

	/**
	 * Returns a new {@link Page} with the content of the current {@link Page} mapped by
	 * the given {@link Function}.
	 * @param converter the converter {@link Function} to apply to the content of the
	 * current {@link Page}.
	 * @param <U> the type of the elements in the new page.
	 * @return a new {@link Page} with the content of the current {@link Page} mapped by
	 * the given {@link Function}.
	 */
	<U> Page<U> map(Function<? super T, ? extends U> converter);

	@Override
	Iterator<T> iterator();

}
