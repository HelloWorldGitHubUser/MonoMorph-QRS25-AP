package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.*;
import com.google.type.Date;
import java.time.LocalDate;

/**
 * Auto-generated DTO gRPC client for the Visit entity, using composition with
 * {@link VisitDTO}. This class provides the same public API as the original
 * {@code org.springframework.samples.petclinic.owner.Visit} class.
 */
public class Visit {

	private VisitDTO dtoInstance;

	/**
	 * Private constructor to create an instance from a DTO. Used by the fromDTO factory
	 * method.
	 * @param dtoInstance The DTO instance to wrap.
	 */
	private Visit(VisitDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
	}

	/**
	 * Creates a new instance of Visit for the current date, mimicking the original
	 * class's behavior.
	 */
	public Visit() {
		LocalDate now = LocalDate.now();
		this.dtoInstance = VisitDTO.newBuilder()
				.setDate(Date.newBuilder().setYear(now.getYear()).setMonth(now.getMonthValue())
						.setDay(now.getDayOfMonth()).build())
				.setDescription("") // Initialize with empty string to match proto3
									// defaults
				.build();
	}

	/**
	 * Converts this client object to its DTO representation.
	 * @return The underlying {@link VisitDTO} instance.
	 */
	public VisitDTO toDTO() {
		return this.dtoInstance;
	}

	/**
	 * Creates a new Visit client object from a DTO instance.
	 * @param dtoInstance The DTO instance.
	 * @return A new {@link Visit} client object wrapping the DTO.
	 */
	public static Visit fromDTO(VisitDTO dtoInstance) {
		return new Visit(dtoInstance);
	}

	// implementation of the gRPC exposed methods
	// No service methods were defined in the proto, so this section is empty.

	// --- START OF DTO GETTERS AND SETTERS ---

	public Integer getId() {
		return this.dtoInstance.getId();
	}

	public void setId(Integer id) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		if (id != null) {
			builder.setId(id);
		}
		else {
			// proto3 int32 cannot be null; clearing sets it to the default value (0).
			builder.clearId();
		}
		this.dtoInstance = builder.build();
	}

	public LocalDate getDate() {
		if (!this.dtoInstance.hasDate()) {
			return null;
		}
		Date protoDate = this.dtoInstance.getDate();
		return LocalDate.of(protoDate.getYear(), protoDate.getMonth(), protoDate.getDay());
	}

	public void setDate(LocalDate date) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		if (date != null) {
			builder.setDate(Date.newBuilder().setYear(date.getYear()).setMonth(date.getMonthValue())
					.setDay(date.getDayOfMonth()).build());
		}
		else {
			builder.clearDate();
		}
		this.dtoInstance = builder.build();
	}

	public String getDescription() {
		return this.dtoInstance.getDescription();
	}

	public void setDescription(String description) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		// proto3 strings cannot be null; use empty string as the default for null inputs.
		builder.setDescription(description == null ? "" : description);
		this.dtoInstance = builder.build();
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}