# **Microservice "visits" ("visits") Report**
## Microservice Summary
 The microservice "visits"  contains a total of **35** classes and files:
  - **13** classes were selected from the decomposition file
  - **15** new classes were added or generated
  - **7** new proto files were added or generated

 The microservice has a new main class "[MonoMorphVisitsMain](src/main/java/org/springframework/samples/petclinic/monomorph/MonoMorphVisitsMain.java)" that combines the old main of the monolith "[PetClinicApplication](src/main/java/org/springframework/samples/petclinic/PetClinicApplication.java)" and the new gRPC main class "[MonoMorphVisitsServerGRPC](src/main/java/org/springframework/samples/petclinic/monomorph/id/MonoMorphVisitsServerGRPC.java)".

---

---

## Changes
 The following changes were made in order to create the microservice:
### Dependencies
 The dependencies of the microservice have been updated. The following packages were added to the file [pom.xml](pom.xml):
 - `com.github.ben-manes.caffeine:caffeine:2.8.0`
 - `com.google.protobuf:protobuf-java:3.25.5`
 - `io.grpc:grpc-netty-shaded:1.71.0`
 - `io.grpc:grpc-protobuf:1.71.0`
 - `io.grpc:grpc-stub:1.71.0`
 - `javax.annotation:javax.annotation-api:1.3.2`
 - `org.mapstruct:mapstruct:1.6.3`

### Copied Classes
 The following classes were copied from the original microservice based on the decomposition:
 - `org.springframework.samples.petclinic.model.BaseEntity` was copied to [src/main/java/org/springframework/samples/petclinic/model/BaseEntity.java](src/main/java/org/springframework/samples/petclinic/model/BaseEntity.java)
 - `org.springframework.samples.petclinic.model.NamedEntity` was copied to [src/main/java/org/springframework/samples/petclinic/model/NamedEntity.java](src/main/java/org/springframework/samples/petclinic/model/NamedEntity.java)
 - `org.springframework.samples.petclinic.model.Person` was copied to [src/main/java/org/springframework/samples/petclinic/model/Person.java](src/main/java/org/springframework/samples/petclinic/model/Person.java)
 - `org.springframework.samples.petclinic.model.ValidatorTests` was copied to [src/test/java/org/springframework/samples/petclinic/model/ValidatorTests.java](src/test/java/org/springframework/samples/petclinic/model/ValidatorTests.java)
 - `org.springframework.samples.petclinic.PetClinicApplication` was copied to [src/main/java/org/springframework/samples/petclinic/PetClinicApplication.java](src/main/java/org/springframework/samples/petclinic/PetClinicApplication.java)
 - `org.springframework.samples.petclinic.owner.Visit` was copied to [src/main/java/org/springframework/samples/petclinic/owner/Visit.java](src/main/java/org/springframework/samples/petclinic/owner/Visit.java)
 - `org.springframework.samples.petclinic.owner.VisitController` was copied to [src/main/java/org/springframework/samples/petclinic/owner/VisitController.java](src/main/java/org/springframework/samples/petclinic/owner/VisitController.java)
 - `org.springframework.samples.petclinic.owner.VisitControllerTests` was copied to [src/test/java/org/springframework/samples/petclinic/owner/VisitControllerTests.java](src/test/java/org/springframework/samples/petclinic/owner/VisitControllerTests.java)
 - `org.springframework.samples.petclinic.system.CrashController` was copied to [src/main/java/org/springframework/samples/petclinic/system/CrashController.java](src/main/java/org/springframework/samples/petclinic/system/CrashController.java)
 - `org.springframework.samples.petclinic.system.CrashControllerTests` was copied to [src/test/java/org/springframework/samples/petclinic/system/CrashControllerTests.java](src/test/java/org/springframework/samples/petclinic/system/CrashControllerTests.java)
 - `org.springframework.samples.petclinic.PetClinicRuntimeHints` was copied to [src/main/java/org/springframework/samples/petclinic/PetClinicRuntimeHints.java](src/main/java/org/springframework/samples/petclinic/PetClinicRuntimeHints.java)
 - `org.springframework.samples.petclinic.owner.PetTypeFormatter` was copied to [src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java](src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java)
 - `org.springframework.samples.petclinic.system.WelcomeController` was copied to [src/main/java/org/springframework/samples/petclinic/system/WelcomeController.java](src/main/java/org/springframework/samples/petclinic/system/WelcomeController.java)

### New Services
 The following gRPC services were generated and added to expose their corresponding classes to other microservices:
 - Class `org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitService`:
   - Exposes the API of [org.springframework.samples.petclinic.owner.Visit](src/main/java/org/springframework/samples/petclinic/owner/Visit.java)
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/server/VisitImpl.java](src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/server/VisitImpl.java)
   - Corresponding Proto service `VisitService` in file [visit.proto](src/main/proto/visit.proto)
   - DTO Message: VisitDTO in [visit.proto](src/main/proto/visit.proto)
   - Mapper class: [org.springframework.samples.petclinic.monomorph.dto.generated.server.VisitMapper](src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/server/VisitMapper.java)

### New Clients
 The following gRPC clients were generated and added to invoke their corresponding servers through RPCs. They serve as proxies to their corresponding original classes:
 - Class `org.springframework.samples.petclinic.monomorph.id.generated.client.OwnerRepository`:
   - A proxy for `org.springframework.samples.petclinic.owner.OwnerRepository`
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/client/OwnerRepository.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/client/OwnerRepository.java)
   - Corresponding Proto service `OwnerRepositoryService` in file [owner_repository.proto](src/main/proto/owner_repository.proto)
 - Class `org.springframework.samples.petclinic.monomorph.dto.generated.client.Owner`:
   - A proxy for `org.springframework.samples.petclinic.owner.Owner`
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/client/Owner.java](src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/client/Owner.java)
   - Corresponding Proto service `OwnerService` in file [owner.proto](src/main/proto/owner.proto)
   - DTO Message: OwnerDTO in [owner.proto](src/main/proto/owner.proto)
 - Class `org.springframework.samples.petclinic.monomorph.dto.generated.client.Pet`:
   - A proxy for `org.springframework.samples.petclinic.owner.Pet`
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/client/Pet.java](src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/client/Pet.java)
   - Corresponding Proto service `PetService` in file [pet.proto](src/main/proto/pet.proto)
   - DTO Message: PetDTO in [pet.proto](src/main/proto/pet.proto)
 - Class `org.springframework.samples.petclinic.monomorph.dto.generated.client.PetType`:
   - A proxy for `org.springframework.samples.petclinic.owner.PetType`
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/client/PetType.java](src/main/java/org/springframework/samples/petclinic/monomorph/dto/generated/client/PetType.java)
   - Corresponding Proto service `PetTypeService` in file [pet_type.proto](src/main/proto/pet_type.proto)
   - DTO Message: PetTypeDTO in [pet_type.proto](src/main/proto/pet_type.proto)

### Shared Utilities
 The following helper classes were added to the microservice in order to implement the pattern and shared logic defined in the approach (leasing, service discovery, ID mapping, etc):
 - Helper Class `AbstractRefactoredClient.java`:
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/client/AbstractRefactoredClient.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/client/AbstractRefactoredClient.java)
   - Description: The AbstractRefactoredClient class is a base class for all client classes that use the leasing API. It provides the common methods for the generated client classes and incorporates the leasing logic. It is shared by all microservices.
 - Helper Class `ServerObjectManager.java`:
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/server/ServerObjectManager.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/server/ServerObjectManager.java)
   - Description: The ServerObjectManager interface defines the methods for managing the objects to IDs and vice versa. It is shared by all microservices.
 - Helper Proto file `leasing.proto`:
   - Location: [src/main/proto/leasing.proto](src/main/proto/leasing.proto)
   - Description: The proto file describing the leasing service api and messages. Required for the leasing/TTL logic. It is shared by all server microservices.
 - Helper Class `GrpcLeaseRpcClient.java`:
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/client/GrpcLeaseRpcClient.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/client/GrpcLeaseRpcClient.java)
   - Description: The GrpcLeaseRpcClient class is a gRPC client that implements LeaseRpcClient and that interacts with the LeasingServiceImpl class. It is shared by all microservices.
 - Helper Class `LeaseRpcClient.java`:
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/client/LeaseRpcClient.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/shared/client/LeaseRpcClient.java)
   - Description: The LeaseRpcClient interface defines the methods that the client microservices can use to interact with the LeaseManager. It is shared by all microservices.
 - Helper Proto file `shared.proto`:
   - Location: [src/main/proto/shared.proto](src/main/proto/shared.proto)
   - Description: The proto file that describes the RefactoredObjectID messages required for exchanging instance IDs across microservices. It is shared by all server microservices.
### Generated Utilities
 The following helper classes were generated and customized for the microservice "visits":
 - Class `ServiceRegistry` was generated for the microservice:
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/helpers/ServiceRegistry.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/helpers/ServiceRegistry.java)
   - Description: A utility class that serves as a placeholder for service discovery. It is customized for each microservice.
 - Class `ClassIdRegistry` was generated for the microservice:
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/helpers/ClassIdRegistry.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/helpers/ClassIdRegistry.java)
   - Description: A utility class that defines the CLASSIDs for the classes that are exchanged between microservices. It is customized for each microservice.
 - Class `IDMapper` was generated for the microservice:
   - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/helpers/IDMapper.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/generated/helpers/IDMapper.java)
   - Description: A utility class for mapping a RefactoredObjectID into actual type instances (if the type is in the microservice) or client instances and vice versa. It is customized for each microservice.
 -  Class `MonoMorphVisitsServerGRPC`:
     - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/id/MonoMorphVisitsServerGRPC.java](src/main/java/org/springframework/samples/petclinic/monomorph/id/MonoMorphVisitsServerGRPC.java)
     - Description: A Server class with a main method that initializes and exposes the new gRPC services
 -  Class `MonoMorphVisitsMain`:
     - Location: [src/main/java/org/springframework/samples/petclinic/monomorph/MonoMorphVisitsMain.java](src/main/java/org/springframework/samples/petclinic/monomorph/MonoMorphVisitsMain.java)
     - Description: A new entrypoint class that combines the old entrypoint of the monolith and the new gRPC server class
     - **This is the main entrypoint of the microservice**

### Updated Imports
 The following imports were updated in the microservice:
 - In class [org.springframework.samples.petclinic.owner.PetTypeFormatter](src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java):
   - `org.springframework.samples.petclinic.owner.OwnerRepository` was replaced with `org.springframework.samples.petclinic.monomorph.id.generated.client.OwnerRepository`
   - `org.springframework.samples.petclinic.owner.PetType` was replaced with `org.springframework.samples.petclinic.monomorph.dto.generated.client.PetType`
 - In class [org.springframework.samples.petclinic.owner.VisitController](src/main/java/org/springframework/samples/petclinic/owner/VisitController.java):
   - `org.springframework.samples.petclinic.owner.OwnerRepository` was replaced with `org.springframework.samples.petclinic.monomorph.id.generated.client.OwnerRepository`
   - `org.springframework.samples.petclinic.owner.Owner` was replaced with `org.springframework.samples.petclinic.monomorph.dto.generated.client.Owner`
   - `org.springframework.samples.petclinic.owner.Pet` was replaced with `org.springframework.samples.petclinic.monomorph.dto.generated.client.Pet`
 - In class [org.springframework.samples.petclinic.owner.VisitControllerTests](src/test/java/org/springframework/samples/petclinic/owner/VisitControllerTests.java):
   - `org.springframework.samples.petclinic.owner.OwnerRepository` was replaced with `org.springframework.samples.petclinic.monomorph.id.generated.client.OwnerRepository`
   - `org.springframework.samples.petclinic.owner.Owner` was replaced with `org.springframework.samples.petclinic.monomorph.dto.generated.client.Owner`
   - `org.springframework.samples.petclinic.owner.Pet` was replaced with `org.springframework.samples.petclinic.monomorph.dto.generated.client.Pet`

---

---

## Detailed Refactoring Comments for Exposed Services
### Original Class `org.springframework.samples.petclinic.owner.Visit`
#### Service `org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitService`
##### Explanation
 The `org.springframework.samples.petclinic.owner.Visit` class is a JPA entity representing a pet's visit. It extends `org.springframework.samples.petclinic.model.BaseEntity`, which provides an `id` field of type `Integer`. The `Visit` class itself defines two fields: `date` and `description`. The `VisitDTO` message is designed to be a direct data representation of the `Visit` entity. It will contain three fields corresponding to the entity's properties: `id`, `date`, and `description`. The field names are preserved from the original Java class to ensure clarity and ease of mapping. The Java field types are mapped to their corresponding Protobuf types as follows: `Integer id` is mapped to `int32`, `java.time.LocalDate date` is mapped to `google.type.Date`, and `java.lang.String description` is mapped to `string`. To use the `google.type.Date` type for the `date` field, the corresponding definition must be imported. The required import statement is `import "google/type/date.proto";`. 
##### Comments
 The field numbers (`1`, `2`, `3`) are assigned sequentially. Once a service using this DTO is in production, these numbers must not be changed to ensure backward compatibility. Using `google.type.Date` is the recommended approach for handling `java.time.LocalDate` as it accurately represents the date-only semantics without including unnecessary time or timezone information. The `id` field is included as it is inherited from the `BaseEntity` superclass and is essential for uniquely identifying the resource.
#### Server Class `org.springframework.samples.petclinic.monomorph.dto.generated.server.VisitImpl`
##### Explanation
 
##### Comments
 The implementation of VisitImpl is an empty class because the preceding proto generation step was explicitly scoped to create only the VisitDTO message without any associated rpc service methods. This implementation correctly fulfills the gRPC service contract as defined, ensuring compliance with the "implement only what is required" principle. Should the VisitService in the proto definition be updated with methods in the future, this class would be the place to implement them, following the specified DTO mapping patterns.

---


---

## Detailed Refactoring Comments for Consumed Services
### Original Class `org.springframework.samples.petclinic.owner.OwnerRepository`
#### Client Class `org.springframework.samples.petclinic.monomorph.id.generated.client.OwnerRepository` (Service `OwnerRepositoryService`)
##### Explanation
 The provided code is a gRPC client implementation for the OwnerRepository interface. It extends the AbstractRefactoredClient class and implements the OwnerRepository interface. The class acts as a proxy, forwarding method calls to a remote gRPC service. The gRPC-specific fields include a ManagedChannel for RPC calls and a blocking stub for the OwnerRepositoryService. The class includes methods for performing RPC setup, creating and getting IDs, and performing subclass RPC cleanup. Additionally, it implements the methods from the OwnerRepository interface, such as findById, findPetTypes, and save, by forwarding the calls to the remote gRPC service.
##### Comments
 This implementation ensures backward compatibility by only implementing the methods defined in the proto service definition. The client implementation is transparent to existing code, and the refactoring is minimal and invasive.

---

### Original Class `org.springframework.samples.petclinic.owner.Owner`
#### Client Class `org.springframework.samples.petclinic.monomorph.dto.generated.client.Owner` (Service `OwnerService`)
##### Explanation
 The implementation of the gRPC client for the `Owner` class follows the DTO composition pattern, ensuring decoupling of the client's API from the underlying data representation. The client class maintains a private `OwnerDTO` instance to hold its state, and provides public getters and setters that delegate to this instance. The gRPC methods are implemented to interact with the remote service, following a standard pattern that includes establishing a connection, building the request message, invoking the remote method, processing the response, and cleaning up the gRPC channel.
##### Comments
 The implementation strictly adheres to the provided requirements, focusing on API compatibility and minimal invasive changes. The use of protobuf-generated DTOs ensures immutability and type safety. The gRPC methods are implemented to handle null values correctly and update the client's state as needed.

---

### Original Class `org.springframework.samples.petclinic.owner.Pet`
#### Client Class `org.springframework.samples.petclinic.monomorph.dto.generated.client.Pet` (Service `PetService`)
##### Explanation
 The provided code is a gRPC client for the `Pet` class, designed using a composition-based DTO pattern. It ensures API compatibility and seamless integration. The client uses a `PetDTO` protobuf message as the single source of truth for the pet's data. The `addVisit` method orchestrates the RPC call to add a visit to the pet, updating the client's state with the response from the server.
##### Comments
 The client uses the `performRpcSetup` and `performSubclassRpcCleanup` methods to manage the gRPC channel's lifecycle. The `TARGET_SERVICE_ID` is used to discover the correct microservice endpoint, making the client robust to changes in network location.

---

### Original Class `org.springframework.samples.petclinic.owner.PetType`
#### Client Class `org.springframework.samples.petclinic.monomorph.dto.generated.client.PetType` (Service `PetTypeService`)
##### Explanation
 The `PetType` class is a client-side representation of the `PetType` entity, using composition to manage its state via a gRPC Data Transfer Object (`PetTypeDTO`). It provides a stable API to the rest of the application while using the DTO for data transfer. The class includes a default constructor, a private constructor for internal use, and methods to map between the `PetType` instance and the `PetTypeDTO`. The setters handle `null` inputs gracefully by resetting the corresponding protobuf fields to their default values.
##### Comments
 This class serves as a 'Data Transfer Object Client' or a 'Local Proxy' for the `PetType` entity, enabling the monolith to interact with it as if it were a local object, while the underlying data structure is prepared for remote communication.

---

---
