package org.springframework.samples.petclinic.monomorph.dto.generated.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.Visit;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;
import com.google.type.Date;
import java.time.LocalDate;

@Mapper
public interface VisitMapper {

	VisitMapper INSTANCE = Mappers.getMapper(VisitMapper.class);

	VisitDTO toDTO(Visit visit);

	Visit fromDTO(VisitDTO visitDTO);

	default LocalDate map(Date protoDate) {
		if (protoDate == null) {
			return null;
		}
		return LocalDate.of(protoDate.getYear(), protoDate.getMonth(), protoDate.getDay());
	}

	default Date map(LocalDate localDate) {
		if (localDate == null) {
			return null;
		}
		return Date.newBuilder().setYear(localDate.getYear()).setMonth(localDate.getMonthValue())
				.setDay(localDate.getDayOfMonth()).build();
	}

}
