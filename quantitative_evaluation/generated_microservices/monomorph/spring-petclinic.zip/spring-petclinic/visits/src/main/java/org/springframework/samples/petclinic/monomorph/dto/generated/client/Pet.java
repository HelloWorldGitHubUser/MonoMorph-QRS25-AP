package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.*;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pettype.PetTypeDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.mapper.VisitMapper;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;
import org.springframework.samples.petclinic.monomorph.id.shared.RefactoredObjectID;
import org.springframework.samples.petclinic.monomorph.id.shared.client.AbstractRefactoredClient;

// Java standard library imports
import java.time.LocalDate;
import java.util.Collection;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Auto-generated DTO gRPC client for
 * {@link org.springframework.samples.petclinic.owner.Pet}. This client uses composition
 * with {@link PetDTO} to manage state and communicates with a remote service.
 */
public class Pet extends AbstractRefactoredClient {

	private PetDTO dtoInstance;

	/**
	 * Default constructor. Initializes with an empty DTO.
	 */
	public Pet() {
		this.dtoInstance = PetDTO.newBuilder().build();
	}

	/**
	 * DTO-based constructor. Used by the fromDTO factory method.
	 * @param dtoInstance The DTO to initialize the client with.
	 */
	public Pet(PetDTO dtoInstance) {
		this.dtoInstance = dtoInstance;
	}

	/**
	 * Converts this client instance to its DTO representation.
	 * @return The internal PetDTO instance.
	 */
	public PetDTO toDTO() {
		return this.dtoInstance;
	}

	/**
	 * Creates a client instance from a DTO.
	 * @param dtoInstance The DTO to create the client from.
	 * @return A new Pet client instance.
	 */
	public static Pet fromDTO(PetDTO dtoInstance) {
		return new Pet(dtoInstance);
	}

	// TARGET_SERVICE_ID is the unique ID for the ClassA service, provided by the tool
	private static final String TARGET_SERVICE_ID = "customers";

	// --- gRPC Specific Fields ---
	private transient ManagedChannel businessChannel; // Channel for RPC calls

	private transient PetServiceGrpc.PetServiceBlockingStub businessStub; // Use this stub
																			// for RPC
																			// calls

	// Helper methods for gRPC
	@Override
	protected void performRpcSetup() throws Exception {
		// Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
		ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
		this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
				.build();
		this.businessStub = PetServiceGrpc.newBlockingStub(this.businessChannel);
	}

	@Override
	protected void performSubclassRpcCleanup() {
		if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
			try {
				this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
				if (!this.businessChannel.isTerminated()) {
					this.businessChannel.shutdownNow();
				}
			}
			catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	@Override
	public RefactoredObjectID toID() {
		return RefactoredObjectID.newBuilder().setInstanceId(this.getId() != null ? String.valueOf(this.getId()) : "")
				.setClassId(this.getClass().getSimpleName()).setServiceId(TARGET_SERVICE_ID).build();
	}

	public static Pet fromID(RefactoredObjectID refactoredObjectID) {
		Pet pet = new Pet();
		if (refactoredObjectID.hasInstanceId()) {
			pet.setId(Long.parseLong(refactoredObjectID.getInstanceId()));
		}
		return pet;
	}

	@Override
	protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
		try {
			performRpcSetup();
			CreatePetRequest request = CreatePetRequest.newBuilder().setPet(this.toDTO()).build();
			CreatePetResponse response = this.businessStub.createPet(request);
			this.dtoInstance = response.getPet();
			return this.toID();
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	// --- START OF gRPC METHOD IMPLEMENTATIONS ---

	/**
	 * Adds a visit to this pet by making a remote gRPC call. The client's internal state
	 * is updated with the response from the server.
	 * @param visit The Visit client object to add.
	 */
	public void addVisit(Visit visit) {
		try {
			performRpcSetup();
			VisitDTO visitDto = VisitMapper.INSTANCE.toDTO(visit);

			AddVisitRequest request = AddVisitRequest.newBuilder().setPet(this.dtoInstance).setVisit(visitDto).build();

			AddVisitResponse response = this.businessStub.addVisit(request);
			this.dtoInstance = response.getPet();
		}
		catch (Exception e) {
			throw new RuntimeException("gRPC call failed for addVisit: " + e.getMessage(), e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	public Pet save() throws Exception {
		if (this.getId() == null) {
			performRemoteCreateAndGetId(null); // Pass null for clientId if not available
		}
		try {
			performRpcSetup();
			SavePetRequest request = SavePetRequest.newBuilder().setPet(this.toDTO()).build();
			SavePetResponse response = this.businessStub.savePet(request);
			this.dtoInstance = response.getPet();
			return this;
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	// --- END OF gRPC METHOD IMPLEMENTATIONS ---

	// --- START OF DTO GETTERS AND SETTERS ---

	public Long getId() {
		return this.dtoInstance.getId();
	}

	public void setId(Long id) {
		this.dtoInstance = this.dtoInstance.toBuilder().setId(id).build();
	}

	public String getName() {
		return this.dtoInstance.getName();
	}

	public void setName(String name) {
		this.dtoInstance = this.dtoInstance.toBuilder().setName(name).build();
	}

	public LocalDate getBirthDate() {
		if (this.dtoInstance.getBirthDate() == null || this.dtoInstance.getBirthDate().isEmpty()) {
			return null;
		}
		return LocalDate.parse(this.dtoInstance.getBirthDate());
	}

	public void setBirthDate(LocalDate birthDate) {
		String dateStr = (birthDate == null) ? "" : birthDate.toString();
		this.dtoInstance = this.dtoInstance.toBuilder().setBirthDate(dateStr).build();
	}

	public PetType getType() {
		if (this.dtoInstance.getTypeName() == null || this.dtoInstance.getTypeName().isEmpty()) {
			return null;
		}
		PetTypeDTO typeDto = PetTypeDTO.newBuilder().setName(this.dtoInstance.getTypeName()).build();
		return PetType.fromDTO(typeDto);
	}

	public void setType(PetType type) {
		String typeName = (type == null) ? "" : type.getName();
		this.dtoInstance = this.dtoInstance.toBuilder().setTypeName(typeName).build();
	}

	public Collection<Visit> getVisits() {
		return this.dtoInstance.getVisitsList().stream().map(VisitMapper.INSTANCE::fromDTO)
				.collect(Collectors.toCollection(LinkedHashSet::new));
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}
