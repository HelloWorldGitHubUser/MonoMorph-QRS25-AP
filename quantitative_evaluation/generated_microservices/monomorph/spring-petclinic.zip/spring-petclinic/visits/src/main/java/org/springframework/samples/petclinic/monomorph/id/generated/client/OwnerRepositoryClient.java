package org.springframework.samples.petclinic.monomorph.id.generated.client;

import org.springframework.samples.petclinic.monomorph.id.shared.client.AbstractRefactoredClient;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;
import org.springframework.samples.petclinic.monomorph.id.shared.RefactoredObjectID;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.Owner;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.PetType;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import org.springframework.samples.petclinic.monomorph.id.generated.proto.ownerrepository.*;
import org.springframework.samples.petclinic.owner.OwnerRepository; // Import the original interface

import java.util.List;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * gRPC Client implementation for the OwnerRepository interface. This class acts as a
 * proxy, forwarding method calls to a remote gRPC service.
 */
public class OwnerRepositoryClient extends AbstractRefactoredClient implements OwnerRepository {

	// TARGET_SERVICE_ID is the unique ID for the OwnerRepository service, provided by the
	// tool
	private static final String TARGET_SERVICE_ID = "customers";

	// --- gRPC Specific Fields ---
	private ManagedChannel businessChannel; // Channel for RPC calls

	private OwnerRepositoryServiceGrpc.OwnerRepositoryServiceBlockingStub businessStub; // Use

	// this
	// stub
	// for
	// RPC
	// calls

	/** Private constructor used by the fromID factory. */
	private OwnerRepositoryClient(RefactoredObjectID existingId) {
		super(existingId); // Use the base constructor for existing IDs
	}

	// --- Implementation of Abstract Methods ---

	@Override
	protected void performRpcSetup() throws Exception {
		// Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
		ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
		this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
				.build();
		this.businessStub = OwnerRepositoryServiceGrpc.newBlockingStub(businessChannel);
	}

	@Override
	protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
		performRpcSetup();
		// Since OwnerRepository is an interface with no constructor, args are empty.
		ConstructorArgs constructorArgs = ConstructorArgs.newBuilder().build();

		CreateObjectRequest createRequest = CreateObjectRequest.newBuilder().setConstructorArgs(constructorArgs)
				.build();

		RefactoredObjectID createResponseProto = this.businessStub.createObject(createRequest);

		return createResponseProto;
	}

	@Override
	protected void performSubclassRpcCleanup() {
		// Shutdown logic for businessChannel
		if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
			try {
				this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
				if (!this.businessChannel.isTerminated()) {
					this.businessChannel.shutdownNow();
				}
			}
			catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	/** Factory method for creating proxy from an EXISTING ID. */
	public static OwnerRepositoryClient fromID(RefactoredObjectID existingId) {
		return new OwnerRepositoryClient(existingId);
	}

	// --- Start of the implementation of the rest of the Service Methods ---

	@Override
	public Collection<Owner> findByLastName(String lastName) {
		FindByLastNameRequest request = FindByLastNameRequest.newBuilder().setObjectId(this.objectId)
				.setLastName(lastName).build();
		FindByLastNameResponse response = this.businessStub.findByLastName(request);
		return response.getOwnersList().stream().map(Owner::fromDTO).collect(Collectors.toList());
	}

	@Override
	public Owner findById(java.lang.Integer id) {
		FindByIdRequest request = FindByIdRequest.newBuilder().setObjectId(this.objectId).setId(id).build();

		FindByIdResponse response = this.businessStub.findById(request);

		if (response.hasOwner()) {
			return Owner.fromDTO(response.getOwner());
		}
		return null;
	}

	@Override
	public List<PetType> findPetTypes() {
		FindPetTypesRequest request = FindPetTypesRequest.newBuilder().setObjectId(this.objectId).build();

		FindPetTypesResponse response = this.businessStub.findPetTypes(request);

		return response.getPetTypesList().stream().map(PetType::fromDTO).collect(Collectors.toList());
	}

	@Override
	public void save(Owner owner) {
		SaveRequest request = SaveRequest.newBuilder().setObjectId(this.objectId).setOwner(owner.toDTO()).build();

		this.businessStub.save(request);
	}

	// --- End of the implementation of the rest of the Service Methods ---

}
