package org.springframework.samples.petclinic.monomorph.dto.generated.server;

import io.grpc.stub.StreamObserver;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitServiceGrpc;
import org.springframework.samples.petclinic.owner.Visit;
import org.springframework.samples.petclinic.monomorph.dto.generated.server.VisitMapper;

/**
 * gRPC Service implementation for Visit. - Handles gRPC requests for Visit API. -
 * Interacts with Mapper for switching between DTO and Visit instances.
 */
public class VisitImpl extends VisitServiceGrpc.VisitServiceImplBase {

	// --- Other gRPC methods defined in the proto file ---
	// --- Start of generated code ---
	// Based on the provided context, no service methods were defined in the proto file.
	// Therefore, no methods are implemented here.
	// --- End of generated code ---

}