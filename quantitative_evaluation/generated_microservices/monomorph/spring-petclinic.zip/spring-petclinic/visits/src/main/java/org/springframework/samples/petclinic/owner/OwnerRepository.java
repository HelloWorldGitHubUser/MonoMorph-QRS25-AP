package org.springframework.samples.petclinic.owner;

import org.springframework.dao.DataAccessException;
import java.util.Collection;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.Owner;
import org.springframework.samples.petclinic.monomorph.dto.generated.client.PetType;

public interface OwnerRepository {

	Collection<Owner> findByLastName(String lastName) throws DataAccessException;

	Owner findById(Integer id) throws DataAccessException;

	void save(Owner owner) throws DataAccessException;

	Collection<PetType> findPetTypes() throws DataAccessException;

}
