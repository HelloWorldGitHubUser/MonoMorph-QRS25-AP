package org.springframework.samples.petclinic.monomorph.dto.generated.client;

import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;
import com.google.type.Date;
import java.time.LocalDate;
import org.springframework.samples.petclinic.monomorph.id.shared.RefactoredObjectID;
import org.springframework.samples.petclinic.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for {@link Visit} and {@link VisitDTO}.
 */
public class Visit extends AbstractRefactoredClient {

	private VisitDTO dtoInstance;

	public Visit() {
		// Default constructor to maintain API compatibility
		this.dtoInstance = VisitDTO.newBuilder().build();
	}

	private Visit(VisitDTO dtoInstance) {
		// dtoConstructor to initialize from a DTO instance
		this.dtoInstance = dtoInstance;
	}

	// mapping methods
	public VisitDTO toDTO() {
		return this.dtoInstance;
	}

	public static Visit fromDTO(VisitDTO dtoInstance) {
		return new Visit(dtoInstance);
	}

	@Override
	public RefactoredObjectID toID() {
		return RefactoredObjectID.newBuilder().setEntityType(this.getClass().getSimpleName()).setObjectId(this.getId())
				.build();
	}

	public static Visit fromID(RefactoredObjectID refactoredObjectID) {
		Visit visit = new Visit();
		visit.setId((int) refactoredObjectID.getObjectId());
		return visit;
	}

	@Override
	protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
		// Visits are created as part of a Pet, not independently via a remote call.
		// This method should not be called for Visit.
		throw new UnsupportedOperationException("Visit objects are created via Pet, not directly.");
	}

	@Override
	protected void performSubclassRpcCleanup() {
		// No specific RPC channel for Visit, as it's managed by Pet.
		// No cleanup needed here.
	}

	@Override
	protected void performRpcSetup() {
		// No specific RPC channel for Visit, as it's managed by Pet.
		// No setup needed here.
	}

	// Implement all other getters and setters corresponding to the DTO fields
	// --- START OF DTO GETTERS AND SETTERS ---

	public Integer getId() {
		return this.dtoInstance.getId();
	}

	public void setId(Integer id) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		if (id == null) {
			builder.clearId();
		}
		else {
			builder.setId(id);
		}
		this.dtoInstance = builder.build();
	}

	public LocalDate getDate() {
		if (this.dtoInstance.hasDate()) {
			Date protoDate = this.dtoInstance.getDate();
			return LocalDate.of(protoDate.getYear(), protoDate.getMonth(), protoDate.getDay());
		}
		return null;
	}

	public void setDate(LocalDate date) {
		VisitDTO.Builder builder = this.dtoInstance.toBuilder();
		if (date == null) {
			builder.clearDate();
		}
		else {
			builder.setDate(Date.newBuilder().setYear(date.getYear()).setMonth(date.getMonthValue())
					.setDay(date.getDayOfMonth()).build());
		}
		this.dtoInstance = builder.build();
	}

	public String getDescription() {
		return this.dtoInstance.getDescription();
	}

	public void setDescription(String description) {
		this.dtoInstance = this.dtoInstance.toBuilder().setDescription(description).build();
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}
