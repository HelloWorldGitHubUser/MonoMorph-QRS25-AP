package org.springframework.samples.petclinic.monomorph.dto.generated.client;

// gRPC imports
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.owner.*;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.pet.PetDTO;
import org.springframework.samples.petclinic.monomorph.dto.generated.proto.visit.VisitDTO;

// Mapper and other client imports
import org.springframework.samples.petclinic.monomorph.dto.generated.mapper.VisitMapper;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.samples.petclinic.monomorph.id.generated.helpers.ServiceRegistry;
import org.springframework.samples.petclinic.monomorph.id.shared.RefactoredObjectID;
import org.springframework.samples.petclinic.monomorph.id.shared.client.AbstractRefactoredClient;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Auto-generated DTO gRPC client for {@link Owner} and {@link OwnerDTO}.
 */
public class Owner extends AbstractRefactoredClient {

	private OwnerDTO dtoInstance;

	public Owner() {
		// Default constructor to maintain API compatibility
		this.dtoInstance = OwnerDTO.newBuilder().build();
	}

	private Owner(OwnerDTO dtoInstance) {
		// dtoConstructor to initialize from a DTO instance
		this.dtoInstance = dtoInstance;
	}

	// mapping methods
	public OwnerDTO toDTO() {
		return this.dtoInstance;
	}

	public static Owner fromDTO(OwnerDTO dtoInstance) {
		return new Owner(dtoInstance);
	}

	// implementation of the gRPC exposed methods

	// TARGET_SERVICE_ID is the unique ID for the ClassA service, provided by the tool
	private static final String TARGET_SERVICE_ID = "customers";

	// --- gRPC Specific Fields ---
	private transient ManagedChannel businessChannel; // Channel for RPC calls

	private transient OwnerServiceGrpc.OwnerServiceBlockingStub businessStub; // Use this

	// stub
	// for RPC
	// calls

	// Helper methods for gRPC
	@Override
	protected void performRpcSetup() throws Exception {
		// Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
		ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
		this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
				.build();
		this.businessStub = OwnerServiceGrpc.newBlockingStub(businessChannel);
	}

	@Override
	protected void performSubclassRpcCleanup() {
		// ... shutdown logic for businessChannel ...
		if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
			try {
				this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
				if (!this.businessChannel.isTerminated()) {
					this.businessChannel.shutdownNow();
				}
			}
			catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}

	@Override
	public RefactoredObjectID toID() {
		return RefactoredObjectID.newBuilder().setInstanceId(this.getId() != null ? String.valueOf(this.getId()) : "")
				.setClassId(this.getClass().getSimpleName()).setServiceId(TARGET_SERVICE_ID).build();
	}

	public static Owner fromID(RefactoredObjectID refactoredObjectID) {
		Owner owner = new Owner();
		if (refactoredObjectID.hasInstanceId()) {
			owner.setId(Integer.parseInt(refactoredObjectID.getInstanceId()));
		}
		return owner;
	}

	@Override
	protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
		try {
			performRpcSetup();
			CreateOwnerRequest request = CreateOwnerRequest.newBuilder().setOwner(this.toDTO()).build();
			CreateOwnerResponse response = this.businessStub.createOwner(request);
			this.dtoInstance = response.getOwner();
			return this.toID();
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	// Implement required methods for gRPC calls here
	// --- START OF gRPC METHOD IMPLEMENTATIONS ---

	public Owner addVisit(Integer petId, Visit visit) {
		try {
			performRpcSetup();
			VisitDTO visitDTO = VisitMapper.INSTANCE.toDTO(visit);
			AddVisitRequest request = AddVisitRequest.newBuilder().setOwner(this.toDTO()).setPetId(petId)
					.setVisit(visitDTO).build();
			AddVisitResponse response = this.businessStub.addVisit(request);
			this.dtoInstance = response.getOwner();
			return this;
		}
		catch (Exception e) {
			throw new RuntimeException("Error adding visit: " + e.getMessage(), e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	public Pet getPet(String name) {
		return getPet(name, false);
	}

	public Pet getPet(Integer id) {
		try {
			performRpcSetup();
			GetPetByIdRequest request = GetPetByIdRequest.newBuilder().setOwner(this.toDTO()).setId(id).build();
			GetPetResponse response = this.businessStub.getPetById(request);
			return response.hasPet() ? Pet.fromDTO(response.getPet()) : null;
		}
		catch (Exception e) {
			throw new RuntimeException("Error getting pet by ID: " + e.getMessage(), e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	public Pet getPet(String name, boolean ignoreNew) {
		try {
			performRpcSetup();
			GetPetByNameExtendedRequest request = GetPetByNameExtendedRequest.newBuilder().setOwner(this.toDTO())
					.setName(name).setIgnoreNew(ignoreNew).build();
			GetPetResponse response = this.businessStub.getPetByNameExtended(request);
			return response.hasPet() ? Pet.fromDTO(response.getPet()) : null;
		}
		catch (Exception e) {
			throw new RuntimeException("Error getting pet by name: " + e.getMessage(), e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	public Owner save() {
		try {
			performRpcSetup();
			SaveOwnerRequest request = SaveOwnerRequest.newBuilder().setOwner(this.toDTO()).build();
			SaveOwnerResponse response = this.businessStub.saveOwner(request);
			this.dtoInstance = response.getOwner();
			return this;
		}
		catch (Exception e) {
			throw new RuntimeException("Error saving owner: " + e.getMessage(), e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	public List<Owner> findByLastName(String lastName) {
		try {
			performRpcSetup();
			FindByLastNameRequest request = FindByLastNameRequest.newBuilder().setLastName(lastName).build();
			FindByLastNameResponse response = this.businessStub.findByLastName(request);
			return response.getOwnersList().stream().map(Owner::fromDTO).collect(Collectors.toList());
		}
		catch (Exception e) {
			throw new RuntimeException("Error finding owner by last name: " + e.getMessage(), e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	public Owner findById(Integer id) {
		try {
			performRpcSetup();
			FindOwnerByIdRequest request = FindOwnerByIdRequest.newBuilder().setId(id).build();
			FindOwnerByIdResponse response = this.businessStub.findOwnerById(request);
			return response.hasOwner() ? Owner.fromDTO(response.getOwner()) : null;
		}
		catch (Exception e) {
			throw new RuntimeException("Error finding owner by ID: " + e.getMessage(), e);
		}
		finally {
			performSubclassRpcCleanup();
		}
	}

	// --- END OF gRPC METHOD IMPLEMENTATIONS ---

	// Implement all other getters and setters corresponding to the DTO fields
	// --- START OF DTO GETTERS AND SETTERS ---

	public Integer getId() {
		return this.dtoInstance.hasId() ? this.dtoInstance.getId() : null;
	}

	public void setId(Integer id) {
		OwnerDTO.Builder builder = this.dtoInstance.toBuilder();
		if (id == null) {
			builder.clearId();
		}
		else {
			builder.setId(id);
		}
		this.dtoInstance = builder.build();
	}

	public String getFirstName() {
		return this.dtoInstance.getFirstName();
	}

	public void setFirstName(String firstName) {
		this.dtoInstance = this.dtoInstance.toBuilder().setFirstName(firstName).build();
	}

	public String getLastName() {
		return this.dtoInstance.getLastName();
	}

	public void setLastName(String lastName) {
		this.dtoInstance = this.dtoInstance.toBuilder().setLastName(lastName).build();
	}

	public String getAddress() {
		return this.dtoInstance.getAddress();
	}

	public void setAddress(String address) {
		this.dtoInstance = this.dtoInstance.toBuilder().setAddress(address).build();
	}

	public String getCity() {
		return this.dtoInstance.getCity();
	}

	public void setCity(String city) {
		this.dtoInstance = this.dtoInstance.toBuilder().setCity(city).build();
	}

	public String getTelephone() {
		return this.dtoInstance.getTelephone();
	}

	public void setTelephone(String telephone) {
		this.dtoInstance = this.dtoInstance.toBuilder().setTelephone(telephone).build();
	}

	public List<Pet> getPets() {
		return this.dtoInstance.getPetsList().stream().map(Pet::fromDTO).collect(Collectors.toList());
	}

	public void setPets(List<Pet> pets) {
		List<PetDTO> petDTOs = pets.stream().map(Pet::toDTO).collect(Collectors.toList());
		this.dtoInstance = this.dtoInstance.toBuilder().clearPets().addAllPets(petDTOs).build();
	}

	// --- END OF DTO GETTERS AND SETTERS ---

}
