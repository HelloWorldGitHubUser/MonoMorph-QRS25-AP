/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package org.mybatis.jpetstore.monomorph.dto.generated.server;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.mybatis.jpetstore.domain.Category;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.categorymapper.CategoryMapperDTO;

/**
 * Auto-generated MapStruct mapper for converting between {@link Category} and {@link CategoryMapperDTO}.
 */
@Mapper(componentModel = "default")
public interface CategoryMapperMapper {
  /**
   * Singleton instance of this mapper. Use this to access mapping methods.
   */
  CategoryMapperMapper INSTANCE = Mappers.getMapper(CategoryMapperMapper.class);

  /**
   * Maps from {@link CategoryMapperDTO} to {@link Category}.
   *
   * @param dto
   *          The source DTO object.
   *
   * @return The mapped {@link Category} object.
   */
  Category fromDTO(CategoryMapperDTO dto);

  /**
   * Maps from {@link Category} to {@link CategoryMapperDTO}.
   *
   * @param original
   *          The source of the Original object.
   *
   * @return The mapped {@link CategoryMapperDTO} object.
   */
  CategoryMapperDTO toDTO(Category domain);

}
