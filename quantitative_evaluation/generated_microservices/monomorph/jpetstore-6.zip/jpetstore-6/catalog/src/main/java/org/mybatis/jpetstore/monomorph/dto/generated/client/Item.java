/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import java.io.Serializable;
import java.math.BigDecimal;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;

/**
 * Client-side DTO for Item. This class is a simplified representation of the original Item domain object, containing
 * only the fields necessary for client-side operations and gRPC communication.
 */
public class Item implements Serializable {

  private static final long serialVersionUID = 6626658280487008092L;

  private String itemId;
  private String productId;
  private BigDecimal listPrice;
  private BigDecimal unitCost;
  private int supplierId; // Changed from String to int
  private String status;
  private String attribute1;
  private String attribute2;
  private String attribute3;
  private String attribute4;
  private String attribute5;
  private int quantity;

  // Default constructor
  public Item() {
  }

  // Constructor to create an Item from an ItemDTO
  public Item(ItemDTO dto) {
    this.itemId = dto.getItemId();
    this.productId = dto.getProductId();
    this.listPrice = new BigDecimal(dto.getListPrice());
    this.unitCost = new BigDecimal(dto.getUnitCost());
    this.supplierId = dto.getSupplierId(); // No longer needs to be parsed as int
    this.status = dto.getStatus();
    this.attribute1 = dto.getAttribute1();
    this.attribute2 = dto.getAttribute2();
    this.attribute3 = dto.getAttribute3();
    this.attribute4 = dto.getAttribute4();
    this.attribute5 = dto.getAttribute5();
    this.quantity = dto.getQuantity();
  }

  // Static factory method to create an Item from an ItemDTO
  public static Item fromDTO(ItemDTO dto) {
    return new Item(dto);
  }

  // Method to convert this Item object to an ItemDTO
  public ItemDTO toDTO() {
    return ItemDTO.newBuilder().setItemId(this.itemId).setProductId(this.productId)
        .setListPrice(this.listPrice.toPlainString()) // Convert BigDecimal to String for proto
        .setUnitCost(this.unitCost.toPlainString()) // Convert BigDecimal to String for proto
        .setSupplierId(this.supplierId).setStatus(this.status).setAttribute1(this.attribute1)
        .setAttribute2(this.attribute2).setAttribute3(this.attribute3).setAttribute4(this.attribute4)
        .setAttribute5(this.attribute5).setQuantity(this.quantity).build();
  }

  public String getItemId() {
    return itemId;
  }

  public void setItemId(String itemId) {
    this.itemId = itemId;
  }

  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public BigDecimal getListPrice() {
    return listPrice;
  }

  public void setListPrice(BigDecimal listPrice) {
    this.listPrice = listPrice;
  }

  public BigDecimal getUnitCost() {
    return unitCost;
  }

  public void setUnitCost(BigDecimal unitCost) {
    this.unitCost = unitCost;
  }

  public int getSupplierId() { // Changed return type to int
    return supplierId;
  }

  public void setSupplierId(int supplierId) { // Changed parameter type to int
    this.supplierId = supplierId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getAttribute1() {
    return attribute1;
  }

  public void setAttribute1(String attribute1) {
    this.attribute1 = attribute1;
  }

  public String getAttribute2() {
    return attribute2;
  }

  public void setAttribute2(String attribute2) {
    this.attribute2 = attribute2;
  }

  public String getAttribute3() {
    return attribute3;
  }

  public void setAttribute3(String attribute3) {
    this.attribute3 = attribute3;
  }

  public String getAttribute4() {
    return attribute4;
  }

  public void setAttribute4(String attribute4) {
    this.attribute4 = attribute4;
  }

  public String getAttribute5() {
    return attribute5;
  }

  public void setAttribute5(String attribute5) {
    this.attribute5 = attribute5;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  @Override
  public String toString() {
    return "Item [itemId=" + itemId + ", productId=" + productId + ", listPrice=" + listPrice + ", unitCost=" + unitCost
        + ", supplierId=" + supplierId + ", status=" + status + ", attribute1=" + attribute1 + ", attribute2="
        + attribute2 + ", attribute3=" + attribute3 + ", attribute4=" + attribute4 + ", attribute5=" + attribute5 + "]";
  }
}
