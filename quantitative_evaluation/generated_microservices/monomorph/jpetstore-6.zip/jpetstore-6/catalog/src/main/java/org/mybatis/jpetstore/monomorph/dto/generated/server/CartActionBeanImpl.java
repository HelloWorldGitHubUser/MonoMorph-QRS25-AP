/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.server;

import io.grpc.stub.StreamObserver;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartactionbean.CartActionBeanDTO;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartactionbean.CartActionBeanServiceGrpc;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartactionbean.ClearRequest;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartactionbean.ClearResponse;
import org.mybatis.jpetstore.web.actions.CartActionBean;

/**
 * gRPC Service implementation for CartActionBean. - Handles gRPC requests for CartActionBean API. - Interacts with
 * Mapper for switching between DTO and CartActionBean instances.
 */
public class CartActionBeanImpl extends CartActionBeanServiceGrpc.CartActionBeanServiceImplBase {

  @Override
  public void clear(ClearRequest request, StreamObserver<ClearResponse> responseObserver) {
    // 1. Retrieve the DTO from the request
    CartActionBeanDTO requestDto = request.getCartActionBean();

    // 2. Map the DTO to the original domain object
    CartActionBean cartActionBean = CartActionBeanMapper.INSTANCE.fromDTO(requestDto);

    // 3. Call the corresponding business logic method
    cartActionBean.clear();

    // 4. Map the modified domain object back to a DTO for the response
    CartActionBeanDTO responseDto = CartActionBeanMapper.INSTANCE.toDTO(cartActionBean);

    // 5. Build and send the response
    ClearResponse response = ClearResponse.newBuilder().setCartActionBean(responseDto).build();
    responseObserver.onNext(response);
    responseObserver.onCompleted();
  }
}
