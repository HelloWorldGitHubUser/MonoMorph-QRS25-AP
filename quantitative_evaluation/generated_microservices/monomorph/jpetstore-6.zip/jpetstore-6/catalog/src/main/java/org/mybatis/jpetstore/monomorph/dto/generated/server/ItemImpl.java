/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.server;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemServiceGrpc;

/**
 * gRPC Service implementation for Item. The original Item class is a domain object (POJO) and does not contain any
 * business logic methods to be exposed as a service. Therefore, this implementation is empty as there are no RPC
 * methods to override from the generated base class. This class and its corresponding mapper are intended for use by
 * other services that consume or produce Item objects.
 */
public class ItemImpl extends ItemServiceGrpc.ItemServiceImplBase {
  // No methods to implement as the Item domain object has no service-like operations.
}