/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.server;

import com.google.protobuf.Empty;

import io.grpc.stub.StreamObserver;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.mybatis.jpetstore.domain.Item;
import org.mybatis.jpetstore.mapper.ItemMapper;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.proto.itemmapper.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.server.LeaseManager;
import org.mybatis.jpetstore.monomorph.id.shared.server.ServerObjectManager;

/**
 * gRPC Service implementation for ItemMapper. - Handles gRPC requests for ItemMapper API. - Manages a singleton
 * ItemMapper instance provided at construction. - Interacts with LeaseManager for instance registration/retrieval. -
 * Calls business methods on the ItemMapper instance.
 */
public class ItemMapperImpl extends ItemMapperServiceGrpc.ItemMapperServiceImplBase implements ServerObjectManager {

  private final LeaseManager leaseManager;
  private final String serviceId = ServiceRegistry.getServiceId();
  private final ItemMapper itemMapperInstance;

  // Static identifier for the class type managed by this service
  public static final String CLASS_ID = ClassIdRegistry.getClassId("ItemMapper");

  public ItemMapperImpl(LeaseManager leaseManager, ItemMapper itemMapperInstance) {
    this.leaseManager = Objects.requireNonNull(leaseManager, "LeaseManager cannot be null");
    this.itemMapperInstance = Objects.requireNonNull(itemMapperInstance, "ItemMapper instance cannot be null");
  }

  // --- createObject gRPC Method Implementation ---

  @Override
  public void createObject(CreateObjectRequest request, StreamObserver<RefactoredObjectID> responseObserver) {
    try {
      // 1. Extract client ID
      String clientId = request.getClientID();
      // ConstructorArgs is empty for an interface, so no arguments to process.

      // 2. Use the singleton instance provided during construction.
      // MyBatis Mappers are thread-safe and can be treated as singletons.
      // The "transient" nature is handled by the LeaseManager, which creates a new
      // lease and a unique instanceID for each createObject call per client.
      ItemMapper instance = this.itemMapperInstance;

      // 3. Generate a RefactoredObjectID ID
      RefactoredObjectID responseProto = toID(instance, clientId);

      // 4. Send the response
      responseObserver.onNext(responseProto);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  // --- Start of ServerObjectManager method implementations ---
  @Override
  public RefactoredObjectID toID(Object instance, String clientId) throws Exception {
    // Validate if id instance exists
    String instanceId = leaseManager.findInstanceIdForInstance(instance);
    if (instanceId == null) {
      // Generate a new unique instance ID
      instanceId = UUID.randomUUID().toString();
    }
    // Register with LeaseManager
    boolean registered = leaseManager.registerInstanceAndGrantLease(instanceId, CLASS_ID, instance, clientId);
    if (!registered) {
      throw new RuntimeException("Failed to register new instance ID: " + instanceId);
    }
    // Build RefactoredObjectID
    return RefactoredObjectID.newBuilder().setInstanceID(instanceId).setClassID(CLASS_ID).setServiceID(this.serviceId)
        .build();
  }

  @Override
  public RefactoredObjectID toID(Object instance) throws Exception {
    return toID(instance, serviceId);
  }

  @Override
  public ItemMapper fromID(RefactoredObjectID id) throws Exception {
    // Validate the class ID
    if (id.getClassID() == null || !id.getClassID().equals(CLASS_ID)) {
      throw new IllegalArgumentException("class ID mismatch: expected " + CLASS_ID + ", got " + id.getClassID());
    }
    // Retrieve the instance from LeaseManager
    ItemMapper instance = (ItemMapper) leaseManager.getInstance(id.getInstanceID());
    if (instance == null) {
      throw new IllegalArgumentException("No instance found for ID: " + id);
    }
    return instance;
  }

  @Override
  public String getManagedClassId() {
    return CLASS_ID;
  }

  @Override
  public String getServiceId() {
    return serviceId;
  }
  // --- End of ServerObjectManager method implementations ---

  // --- Other gRPC methods defined in the proto file ---

  @Override
  public void updateInventoryQuantity(UpdateInventoryQuantityRequest request, StreamObserver<Empty> responseObserver) {
    try {
      ItemMapper instance = fromID(request.getObjectId());
      // The original method takes a Map. We reconstruct it from the typed request.
      // The MyBatis XML for this method uses 'itemId' and 'increment' as keys.
      Map<String, Object> params = new HashMap<>();
      params.put("itemId", request.getItemId());
      params.put("increment", request.getQuantity());
      instance.updateInventoryQuantity(params);
      responseObserver.onNext(Empty.getDefaultInstance());
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void getInventoryQuantity(GetInventoryQuantityRequest request,
      StreamObserver<GetInventoryQuantityResponse> responseObserver) {
    try {
      ItemMapper instance = fromID(request.getObjectId());
      int quantity = instance.getInventoryQuantity(request.getItemId());
      GetInventoryQuantityResponse response = GetInventoryQuantityResponse.newBuilder().setQuantity(quantity).build();
      responseObserver.onNext(response);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void getItem(GetItemRequest request, StreamObserver<GetItemResponse> responseObserver) {
    try {
      ItemMapper instance = fromID(request.getObjectId());
      Item item = instance.getItem(request.getItemId());

      GetItemResponse.Builder responseBuilder = GetItemResponse.newBuilder();
      if (item != null) {
        // Map the domain object to its DTO representation
        ItemDTO itemDto = org.mybatis.jpetstore.monomorph.dto.generated.server.ItemMapper.INSTANCE.toDTO(item);
        responseBuilder.setItem(itemDto);
      }

      responseObserver.onNext(responseBuilder.build());
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }
}
