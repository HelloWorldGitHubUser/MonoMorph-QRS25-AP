/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import java.math.BigDecimal;

// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartitem.*;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;

// Removed: import org.mybatis.jpetstore.monomorph.dto.generated.server.ItemMapper; // This mapper is for domain.Item, not client.Item

/**
 * Auto-generated DTO gRPC client for {@code CartItem}. This class acts as a client-side representation of the CartItem
 * domain object, using composition to wrap the gRPC-generated {@link CartItemDTO}. It provides the same public API as
 * the original {@code org.mybatis.jpetstore.domain.CartItem} class for fields represented in the DTO, while omitting
 * server-side business logic.
 */
public class CartItem {
  private CartItemDTO dtoInstance;

  /**
   * Constructor to initialize from a DTO instance.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  public CartItem(CartItemDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
  }

  /**
   * Default constructor. Initializes with a default CartItemDTO instance. This provides compatibility with code that
   * expects a no-arg constructor.
   */
  public CartItem() {
    this.dtoInstance = CartItemDTO.getDefaultInstance();
  }

  // mapping methods
  public CartItemDTO toDTO() {
    return this.dtoInstance;
  }

  public static CartItem fromDTO(CartItemDTO dtoInstance) {
    // Corrected implementation: wrap the provided DTO instance.
    return new CartItem(dtoInstance);
  }

  // implementation of the gRPC exposed methods
  // This section is for actual RPC calls, which are not required by the current task.
  // The task is to implement the client-side data object.

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---

  public boolean isInStock() {
    return dtoInstance.getInStock();
  }

  public void setInStock(boolean inStock) {
    this.dtoInstance = this.dtoInstance.toBuilder().setInStock(inStock).build();
  }

  public BigDecimal getTotal() {
    // Protobuf default for string is empty string, which is not a valid BigDecimal.
    // Return null if the total is not set or is empty, mirroring original behavior where total could be null.
    if (dtoInstance.getTotal().isEmpty()) {
      return null;
    }
    return new BigDecimal(dtoInstance.getTotal());
  }

  public org.mybatis.jpetstore.monomorph.dto.generated.client.Item getItem() {
    // Check if the item field is set in the DTO before conversion.
    if (!dtoInstance.hasItem()) {
      return null;
    }
    // Use the client-side Item class's fromDTO method.
    return org.mybatis.jpetstore.monomorph.dto.generated.client.Item.fromDTO(dtoInstance.getItem());
  }

  public void setItem(org.mybatis.jpetstore.monomorph.dto.generated.client.Item item) {
    // Use the client-side Item class's toDTO method.
    ItemDTO itemDto = (item == null) ? ItemDTO.getDefaultInstance() : item.toDTO();
    this.dtoInstance = this.dtoInstance.toBuilder().setItem(itemDto).build();
    // The business logic for calculateTotal() is removed from this client-side object.
  }

  public int getQuantity() {
    return dtoInstance.getQuantity();
  }

  public void setQuantity(int quantity) {
    this.dtoInstance = this.dtoInstance.toBuilder().setQuantity(quantity).build();
    // The business logic for calculateTotal() is removed from this client-side object.
  }

  public void incrementQuantity() {
    setQuantity(getQuantity() + 1);
    // The business logic for calculateTotal() is removed from this client-side object.
  }

  // --- END OF DTO GETTERS AND SETTERS ---

}
