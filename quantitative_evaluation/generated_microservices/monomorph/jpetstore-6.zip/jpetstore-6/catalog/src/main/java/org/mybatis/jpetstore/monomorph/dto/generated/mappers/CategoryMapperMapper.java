/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.mybatis.jpetstore.domain.Category;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.category.CategoryDTO;

@Mapper
public interface CategoryMapperMapper {
  CategoryMapperMapper INSTANCE = Mappers.getMapper(CategoryMapperMapper.class);

  CategoryDTO toDTO(Category category);

  Category fromDTO(CategoryDTO categoryDTO);
}
