/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package org.mybatis.jpetstore.monomorph.dto.generated.server;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.mybatis.jpetstore.domain.Item;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;

/**
 * Auto-generated MapStruct mapper for converting between {@link Item} and {@link ItemDTO}.
 */
@Mapper(componentModel = "default")
public interface ItemMapper {
  /**
   * Singleton instance of this mapper. Use this to access mapping methods.
   */
  ItemMapper INSTANCE = Mappers.getMapper(ItemMapper.class);

  /**
   * Maps from {@link ItemDTO} to {@link Item}.
   *
   * @param dto
   *          The source DTO object.
   *
   * @return The mapped {@link Item} object.
   */
  Item fromDTO(ItemDTO dto);

  /**
   * Maps from {@link Item} to {@link ItemDTO}.
   *
   * @param original
   *          The source of the Original object.
   *
   * @return The mapped {@link ItemDTO} object.
   */
  ItemDTO toDTO(Item domain);

}
