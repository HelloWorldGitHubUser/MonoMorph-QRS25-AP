/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.server;

import io.grpc.stub.StreamObserver;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import org.mybatis.jpetstore.domain.Product;
import org.mybatis.jpetstore.mapper.CategoryMapper;
import org.mybatis.jpetstore.mapper.ItemMapper;
import org.mybatis.jpetstore.mapper.ProductMapper;
import org.mybatis.jpetstore.monomorph.dto.generated.mappers.ProductMapperMapper;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.product.ProductDTO;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.IDMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.proto.catalogservice.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.server.LeaseManager;
import org.mybatis.jpetstore.monomorph.id.shared.server.ServerObjectManager;
import org.mybatis.jpetstore.service.CatalogService;

/**
 * gRPC Service implementation for CatalogService. - Handles gRPC requests for CatalogService API. - Creates transient
 * CatalogService instances. - Interacts with LeaseManager for instance registration/retrieval. - Calls business methods
 * on retrieved CatalogService instances.
 */
public class CatalogServiceImpl extends CatalogServiceServiceGrpc.CatalogServiceServiceImplBase
    implements ServerObjectManager {

  private final LeaseManager leaseManager;
  private final String serviceId = ServiceRegistry.getServiceId();

  // Static identifier for the class type managed by this service
  public static final String CLASS_ID = ClassIdRegistry.getClassId("CatalogService");

  public CatalogServiceImpl(LeaseManager leaseManager) {
    this.leaseManager = Objects.requireNonNull(leaseManager);
  }

  // --- createObject gRPC Method Implementation ---

  @Override
  public void createObject(CreateObjectRequest request, StreamObserver<RefactoredObjectID> responseObserver) {
    try {
      // 1. Extract args & client ID
      String clientId = request.getClientID();
      ConstructorArgs constructorArgs = request.getConstructorArgs();
      // --- Start of generated code ---
      // Map proto to actual args
      CategoryMapper categoryMapper = (CategoryMapper) IDMapper.fromID(constructorArgs.getCategoryMapper());
      ItemMapper itemMapper = (ItemMapper) IDMapper.fromID(constructorArgs.getItemMapper());
      ProductMapper productMapper = (ProductMapper) IDMapper.fromID(constructorArgs.getProductMapper());
      // --- End of generated code ---

      // 2. *** Create the transient instance DIRECTLY ***
      // --- Start of generated code ---
      CatalogService newInstance = new CatalogService(categoryMapper, itemMapper, productMapper);
      // --- End of generated code ---

      // 3- Generate a RefactoredObjectID ID
      RefactoredObjectID responseProto = toID(newInstance, clientId);
      // 4. Send the response
      responseObserver.onNext(responseProto);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  // --- Start of ServerObjectManager method implementations ---
  @Override
  public RefactoredObjectID toID(Object instance, String clientId) throws Exception {
    // Validate if id instance exists
    String instanceId = leaseManager.findInstanceIdForInstance(instance);
    if (instanceId == null) {
      // Generate a new unique instance ID
      instanceId = UUID.randomUUID().toString();
    }
    // Register with LeaseManager
    boolean registered = leaseManager.registerInstanceAndGrantLease(instanceId, CLASS_ID, instance, clientId);
    if (!registered) {
      throw new RuntimeException("Failed to register new instance ID: " + instanceId);
    }
    // Build RefactoredObjectID
    return RefactoredObjectID.newBuilder().setInstanceID(instanceId).setClassID(CLASS_ID).setServiceID(this.serviceId)
        .build();
  }

  @Override
  public RefactoredObjectID toID(Object instance) throws Exception {
    return toID(instance, serviceId);
  }

  @Override
  public CatalogService fromID(RefactoredObjectID id) throws Exception {
    // Validate the class ID
    if (id.getClassID() == null || !id.getClassID().equals(CLASS_ID)) {
      throw new IllegalArgumentException("class ID mismatch: expected " + CLASS_ID + ", got " + id.getClassID());
    }
    // Retrieve the instance from LeaseManager
    // Note: The LeaseManager.getInstance() method should return the correct type based on the class ID
    CatalogService instance = (CatalogService) leaseManager.getInstance(id.getInstanceID());
    if (instance == null) {
      throw new IllegalArgumentException("No instance found for ID: " + id);
    }
    return instance;
  }

  @Override
  public String getManagedClassId() {
    return CLASS_ID;
  }

  @Override
  public String getServiceId() {
    return serviceId;
  }
  // --- End of ServerObjectManager method implementations ---

  // --- Other gRPC methods defined in the proto file ---
  // --- Start of generated code ---
  @Override
  public void getProductListByCategory(GetProductListByCategoryRequest request,
      StreamObserver<GetProductListByCategoryResponse> responseObserver) {
    try {
      // Retrieve the instance using the provided ID
      CatalogService instance = fromID(request.getObjectId());

      // Extract arguments from the request
      String categoryId = request.getCategoryId();

      // Call the actual method from the original class
      List<Product> products = instance.getProductListByCategory(categoryId);

      // Map the result to the response DTO
      List<ProductDTO> productDTOs = products.stream().map(ProductMapperMapper.INSTANCE::toDTO)
          .collect(Collectors.toList());

      // Build and send the response
      GetProductListByCategoryResponse response = GetProductListByCategoryResponse.newBuilder()
          .addAllProducts(productDTOs).build();
      responseObserver.onNext(response);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }
  // --- End of generated code ---

}
