/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.mybatis.jpetstore.monomorph.dto.generated.client.CartItem;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.proto.cart.*;
import org.mybatis.jpetstore.monomorph.id.generated.proto.cart.CartServiceGrpc.CartServiceBlockingStub;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * gRPC Client implementation for the Cart class. This class acts as a proxy, forwarding method calls to a remote gRPC
 * service.
 */
public class Cart extends AbstractRefactoredClient {

  // TARGET_SERVICE_ID is the unique ID for the Cart service, provided by the tool
  private static final String TARGET_SERVICE_ID = "order";

  // --- gRPC Specific Fields ---
  private ManagedChannel businessChannel; // Channel for RPC calls
  private CartServiceBlockingStub businessStub; // Use this stub for RPC calls

  /**
   * Public constructor for creating a new remote Cart instance. Matches the original class's default constructor.
   */
  public Cart() {
    // MAKE SURE TO CALL THIS INITIALIZATION METHOD FROM THE PARENT (void initialize(Object... args))
    // This triggers the remote object creation via performRemoteCreateAndGetId.
    initialize();
  }

  /**
   * Private constructor used by the fromID factory for existing remote instances.
   */
  private Cart(RefactoredObjectID existingId) {
    super(existingId); // Use the base constructor for existing IDs
  }

  // --- Implementation of Abstract Methods ---

  @Override
  protected void performRpcSetup() throws Exception {
    // Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
    ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
        .build();
    this.businessStub = CartServiceGrpc.newBlockingStub(businessChannel);
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    performRpcSetup();
    // The original Cart class has a no-argument constructor, so ConstructorArgs is empty.
    ConstructorArgs constructorArgs = ConstructorArgs.newBuilder().build();

    CreateObjectRequest createRequest = CreateObjectRequest.newBuilder().setClientID(clientId)
        .setConstructorArgs(constructorArgs).build();

    RefactoredObjectID newId = this.businessStub.createObject(createRequest);

    return newId;
  }

  @Override
  protected void performSubclassRpcCleanup() {
    // Shutdown logic for businessChannel
    if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
      try {
        this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        if (!this.businessChannel.isTerminated()) {
          this.businessChannel.shutdownNow();
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }

  /**
   * Factory method for creating a proxy from an EXISTING ID.
   */
  public static Cart fromID(RefactoredObjectID existingId) {
    return new Cart(existingId);
  }

  // --- Start of the implementation of the rest of the Service Methods ---

  /**
   * Adds an item to the cart.
   *
   * @param item
   *          the item to add
   * @param isInStock
   *          whether the item is in stock
   */
  public void addItem(ItemDTO item, boolean isInStock) {
    ensureInitialized();
    AddItemRequest request = AddItemRequest.newBuilder().setObjectId(this.objectId).setItem(item)
        .setIsInStock(isInStock).build();
    this.businessStub.addItem(request);
  }

  /**
   * Checks if the cart contains a specific item ID.
   *
   * @param itemId
   *          the item ID to check
   *
   * @return true if the item is in the cart, false otherwise
   */
  public boolean containsItemId(String itemId) {
    ensureInitialized();
    ContainsItemIdRequest request = ContainsItemIdRequest.newBuilder().setObjectId(this.objectId).setItemId(itemId)
        .build();
    ContainsItemIdResponse response = this.businessStub.containsItemId(request);
    return response.getResult();
  }

  /**
   * Gets an iterator for all items in the cart.
   *
   * @return an iterator of CartItem objects
   */
  public Iterator<CartItem> getAllCartItems() {
    ensureInitialized();
    GetAllCartItemsRequest request = GetAllCartItemsRequest.newBuilder().setObjectId(this.objectId).build();
    GetAllCartItemsResponse response = this.businessStub.getAllCartItems(request);
    List<CartItem> cartItems = response.getItemsList().stream().map(CartItem::fromDTO).collect(Collectors.toList());
    return cartItems.iterator();
  }

  /**
   * Increments the quantity of an item in the cart by its ID.
   *
   * @param itemId
   *          the ID of the item to increment
   */
  public void incrementQuantityByItemId(String itemId) {
    ensureInitialized();
    IncrementQuantityByItemIdRequest request = IncrementQuantityByItemIdRequest.newBuilder().setObjectId(this.objectId)
        .setItemId(itemId).build();
    this.businessStub.incrementQuantityByItemId(request);
  }

  /**
   * Removes an item from the cart by its ID.
   *
   * @param itemId
   *          the ID of the item to remove
   *
   * @return the removed Item, or null if not found
   */
  public ItemDTO removeItemById(String itemId) {
    ensureInitialized();
    RemoveItemByIdRequest request = RemoveItemByIdRequest.newBuilder().setObjectId(this.objectId).setItemId(itemId)
        .build();
    RemoveItemByIdResponse response = this.businessStub.removeItemById(request);
    if (response.hasItem()) {
      return response.getItem();
    }
    return null;
  }

  /**
   * Sets the quantity of an item in the cart by its ID.
   *
   * @param itemId
   *          the ID of the item
   * @param quantity
   *          the new quantity
   */
  public void setQuantityByItemId(String itemId, int quantity) {
    ensureInitialized();
    SetQuantityByItemIdRequest request = SetQuantityByItemIdRequest.newBuilder().setObjectId(this.objectId)
        .setItemId(itemId).setQuantity(quantity).build();
    this.businessStub.setQuantityByItemId(request);
  }

  // --- End of the implementation of the rest of the Service Methods ---
}
