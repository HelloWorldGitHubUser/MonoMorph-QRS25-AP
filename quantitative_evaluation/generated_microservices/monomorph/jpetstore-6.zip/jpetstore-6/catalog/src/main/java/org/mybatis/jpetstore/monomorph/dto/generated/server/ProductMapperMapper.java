/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package org.mybatis.jpetstore.monomorph.dto.generated.server;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.mybatis.jpetstore.domain.Product;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.ProductMapperDTO;

/**
 * Auto-generated MapStruct mapper for converting between {@link Product} and {@link ProductMapperDTO}.
 */
@Mapper(componentModel = "default")
public interface ProductMapperMapper {
  /**
   * Singleton instance of this mapper. Use this to access mapping methods.
   */
  ProductMapperMapper INSTANCE = Mappers.getMapper(ProductMapperMapper.class);

  /**
   * Maps from {@link ProductMapperDTO} to {@link Product}.
   *
   * @param dto
   *          The source DTO object.
   *
   * @return The mapped {@link Product} object.
   */
  Product fromDTO(ProductMapperDTO dto);

  /**
   * Maps from {@link Product} to {@link ProductMapperDTO}.
   *
   * @param original
   *          The source of the Original object.
   *
   * @return The mapped {@link ProductMapperDTO} object.
   */
  ProductMapperDTO toDTO(Product domain);

}
