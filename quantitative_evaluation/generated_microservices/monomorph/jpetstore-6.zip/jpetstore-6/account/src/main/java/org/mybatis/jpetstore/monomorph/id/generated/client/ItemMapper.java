/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Map;
import java.util.concurrent.TimeUnit;

// DTO Proxy imports
import org.mybatis.jpetstore.monomorph.dto.generated.client.Item;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
// gRPC imports
import org.mybatis.jpetstore.monomorph.id.generated.proto.itemmapper.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * gRPC Client Proxy for org.mybatis.jpetstore.mapper.ItemMapper. This class is a transparent proxy that forwards method
 * calls to a remote gRPC service.
 */
public class ItemMapper extends AbstractRefactoredClient {

  // TARGET_SERVICE_ID is the unique ID for the ItemMapper service, provided by the tool
  private static final String TARGET_SERVICE_ID = "itemmapper-service";

  // --- gRPC Specific Fields ---
  private ManagedChannel businessChannel; // Channel for RPC calls
  private ItemMapperServiceGrpc.ItemMapperServiceBlockingStub businessStub; // Use this stub for RPC calls

  /**
   * Default constructor for creating a new remote instance.
   */
  public ItemMapper() {
    // MAKE SURE TO CALL THIS INITIALIZATION METHOD FROM THE PARENT (void initialize(Object... args))
    initialize();
  }

  /** Private constructor used by the fromID factory. */
  private ItemMapper(RefactoredObjectID existingId) {
    super(existingId); // Use the base constructor for existing IDs
  }

  // --- Implementation of Abstract Methods ---

  @Override
  protected void performRpcSetup() throws Exception {
    // Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
    ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
        .build();
    this.businessStub = ItemMapperServiceGrpc.newBlockingStub(this.businessChannel);
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    // For service clients, remote creation is not applicable in the same way as for domain objects.
    // We return a RefactoredObjectID representing the service client itself.
    return RefactoredObjectID.newBuilder().setClassID(ClassIdRegistry.getClassId(ItemMapper.class.getSimpleName()))
        .build();
  }

  @Override
  protected void performSubclassRpcCleanup() {
    // ... shutdown logic for businessChannel ...
    if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
      try {
        this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        if (!this.businessChannel.isTerminated()) {
          this.businessChannel.shutdownNow();
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }

  /** Factory method for creating proxy from an EXISTING ID. */
  public static ItemMapper fromID(RefactoredObjectID existingId) {
    return new ItemMapper(existingId);
  }

  @Override
  public RefactoredObjectID toID() {
    // For service clients, generate a consistent RefactoredObjectID based on the class name.
    // This ID does not represent a specific instance, but the service client itself.
    return RefactoredObjectID.newBuilder().setClassID(ClassIdRegistry.getClassId(ItemMapper.class.getSimpleName()))
        .build();
  }

  // --- Start of the implementation of the rest of the Service Methods ---

  public void updateInventoryQuantity(Map<String, Object> param) {
    ensureInitialized();
    UpdateInventoryQuantityRequest request = UpdateInventoryQuantityRequest.newBuilder().setObjectId(this.objectId)
        .setItemId((String) param.get("itemId")).setQuantity((Integer) param.get("quantity")).build();
    this.businessStub.updateInventoryQuantity(request);
  }

  public int getInventoryQuantity(String itemId) {
    ensureInitialized();
    GetInventoryQuantityRequest request = GetInventoryQuantityRequest.newBuilder().setObjectId(this.objectId)
        .setItemId(itemId).build();
    GetInventoryQuantityResponse response = this.businessStub.getInventoryQuantity(request);
    return response.getQuantity();
  }

  public Item getItem(String itemId) {
    ensureInitialized();
    GetItemRequest request = GetItemRequest.newBuilder().setObjectId(this.objectId).setItemId(itemId).build();
    GetItemResponse response = this.businessStub.getItem(request);
    if (!response.hasItem()) {
      return null;
    }
    return Item.fromDTO(response.getItem());
  }

  // --- End of the implementation of the rest of the Service Methods ---

}
