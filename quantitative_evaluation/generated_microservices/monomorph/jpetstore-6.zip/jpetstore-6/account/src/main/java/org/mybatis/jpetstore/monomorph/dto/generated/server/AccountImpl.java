/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.server;

import org.mybatis.jpetstore.domain.Account;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.account.AccountServiceGrpc;

/**
 * gRPC Service implementation for Account. - Handles gRPC requests for Account API. - Interacts with Mapper for
 * switching between DTO and Account instances. As per the provided protobuf definition, no RPC services are defined for
 * Account. This class serves as a placeholder for future service implementations.
 */
public class AccountImpl extends AccountServiceGrpc.AccountServiceImplBase {

  // --- Other gRPC methods defined in the proto file ---
  // --- Start of generated code ---
  // No gRPC service methods were defined in the provided proto file for the Account class.
  // Therefore, no methods are implemented here.
  // --- End of generated code ---
}
