/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

// Proxy/DTO client classes
import org.mybatis.jpetstore.monomorph.dto.generated.client.CategoryMapper;
import org.mybatis.jpetstore.monomorph.dto.generated.client.Product;
import org.mybatis.jpetstore.monomorph.dto.generated.client.ProductMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.IDMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
// gRPC imports
import org.mybatis.jpetstore.monomorph.id.generated.proto.catalogservice.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * gRPC Client for the CatalogService. This class acts as a proxy, sending RPC calls to a remote microservice.
 */
public class CatalogService extends AbstractRefactoredClient {

  // TARGET_SERVICE_ID is the unique ID for the CatalogService service, provided by the tool
  private static final String TARGET_SERVICE_ID = "catalog";

  // --- gRPC Specific Fields ---
  private ManagedChannel businessChannel; // Channel for RPC calls
  private CatalogServiceServiceGrpc.CatalogServiceServiceBlockingStub businessStub; // Use this stub for RPC calls

  /**
   * Public constructor with an API identical to the original class. This constructor creates a new remote object.
   */
  public CatalogService(org.mybatis.jpetstore.monomorph.dto.generated.client.CategoryMapper categoryMapper,
      org.mybatis.jpetstore.monomorph.id.generated.client.ItemMapper itemMapper,
      org.mybatis.jpetstore.monomorph.dto.generated.client.ProductMapper productMapper) {
    // This will call performRemoteCreateAndGetId to create the object on the remote service
    initialize(categoryMapper, itemMapper, productMapper);
  }

  /** Private constructor used by the fromID factory. */
  private CatalogService(RefactoredObjectID existingId) {
    super(existingId); // Use the base constructor for existing IDs
  }

  // --- Implementation of Abstract Methods ---

  @Override
  protected void performRpcSetup() throws Exception {
    // Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
    ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
        .build();
    this.businessStub = CatalogServiceServiceGrpc.newBlockingStub(businessChannel);
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    performRpcSetup();

    // Cast constructor arguments from Object...
    CategoryMapper categoryMapper = (CategoryMapper) args[0];
    ItemMapper itemMapper = (ItemMapper) args[1];
    ProductMapper productMapper = (ProductMapper) args[2];

    // Map client-side objects to their protobuf message equivalents
    ConstructorArgs constructorArgs = ConstructorArgs.newBuilder().setCategoryMapper(categoryMapper.toDTO())
        .setItemMapper(IDMapper.toID(itemMapper)).setProductMapper(productMapper.toDTO()).build();

    // Build the request for the createObject RPC
    CreateObjectRequest createRequest = CreateObjectRequest.newBuilder().setClientID(clientId)
        .setConstructorArgs(constructorArgs).build();

    // Make the RPC call and return the new object's ID
    return this.businessStub.createObject(createRequest);
  }

  @Override
  protected void performSubclassRpcCleanup() {
    if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
      try {
        this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        if (!this.businessChannel.isTerminated()) {
          this.businessChannel.shutdownNow();
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }

  /** Factory method for creating a proxy from an EXISTING ID. */
  public static CatalogService fromID(RefactoredObjectID existingId) {
    return new CatalogService(existingId);
  }

  /**
   * Ensures the gRPC stub is initialized. This is necessary for methods called on instances created via fromID(), which
   * do not trigger the initial setup.
   */
  private void ensureRpcSetup() {
    if (this.businessStub == null) {
      try {
        performRpcSetup();
      } catch (Exception e) {
        throw new RuntimeException("Failed to setup RPC connection", e);
      }
    }
  }

  // --- Start of the implementation of the rest of the Service Methods ---

  /**
   * Retrieves a list of products belonging to a specific category by making an RPC call.
   *
   * @param categoryId
   *          The ID of the category.
   *
   * @return A list of Product proxy objects.
   */
  public java.util.List<org.mybatis.jpetstore.monomorph.dto.generated.client.Product> getProductListByCategory(
      java.lang.String categoryId) {
    ensureRpcSetup();

    // Build the gRPC request message
    GetProductListByCategoryRequest request = GetProductListByCategoryRequest.newBuilder().setObjectId(this.objectId)
        .setCategoryId(categoryId).build();

    // Execute the remote call
    GetProductListByCategoryResponse response = this.businessStub.getProductListByCategory(request);

    // Map the list of ProductDTOs from the response back to a list of client-side Product proxy objects
    return response.getProductsList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }

  // --- End of the implementation of the rest of the Service Methods ---
}
