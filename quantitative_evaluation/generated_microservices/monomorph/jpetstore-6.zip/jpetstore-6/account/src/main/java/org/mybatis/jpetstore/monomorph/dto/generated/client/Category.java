/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.category.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for {@code Category}. This class acts as a client-side representation of the Category
 * entity, using composition to wrap the gRPC-generated {@link CategoryDTO}. It provides the same public API as the
 * original domain class, ensuring backward compatibility while enabling microservice communication.
 */
public class Category extends AbstractRefactoredClient implements java.io.Serializable {

  private static final long serialVersionUID = -2159121673445254631L;

  private CategoryDTO dtoInstance;

  /**
   * Default constructor. Initializes with an empty DTO.
   */
  public Category() {
    this.dtoInstance = CategoryDTO.newBuilder().build();
  }

  /**
   * Constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  public Category(CategoryDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
  }

  /**
   * Converts this client object to its underlying DTO representation.
   *
   * @return The {@link CategoryDTO} instance.
   */
  public CategoryDTO toDTO() {
    return this.dtoInstance;
  }

  /**
   * Creates a new {@code Category} client object from a DTO instance.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   *
   * @return A new {@code Category} instance.
   */
  public static Category fromDTO(CategoryDTO dtoInstance) {
    if (dtoInstance == null) {
      return null;
    }
    return new Category(dtoInstance);
  }

  /**
   * Creates a new Category client proxy from a RefactoredObjectID.
   *
   * @param refactoredObjectID
   *          The RefactoredObjectID.
   *
   * @return A new Category object wrapping the DTO, or null if the input is null.
   */
  public static Category fromID(RefactoredObjectID refactoredObjectID) {
    if (refactoredObjectID == null || refactoredObjectID.getInstanceID() == null) {
      return null;
    }
    return new Category(CategoryDTO.newBuilder().setCategoryId(refactoredObjectID.getInstanceID()).build());
  }

  // implementation of the gRPC exposed methods
  // No service methods were defined in the proto file for Category.

  // --- START OF DTO GETTERS AND SETTERS ---

  public java.lang.String getCategoryId() {
    return this.dtoInstance.getCategoryId();
  }

  public void setCategoryId(java.lang.String categoryId) {
    CategoryDTO.Builder builder = this.dtoInstance.toBuilder();
    if (categoryId != null) {
      builder.setCategoryId(categoryId.trim());
    } else {
      builder.clearCategoryId();
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getName() {
    return this.dtoInstance.getName();
  }

  public void setName(java.lang.String name) {
    CategoryDTO.Builder builder = this.dtoInstance.toBuilder();
    if (name != null) {
      builder.setName(name);
    } else {
      builder.clearName();
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getDescription() {
    return this.dtoInstance.getDescription();
  }

  public void setDescription(java.lang.String description) {
    CategoryDTO.Builder builder = this.dtoInstance.toBuilder();
    if (description != null) {
      builder.setDescription(description);
    } else {
      builder.clearDescription();
    }
    this.dtoInstance = builder.build();
  }

  // --- END OF DTO GETTERS AND SETTERS ---

  @java.lang.Override
  public java.lang.String toString() {
    return getCategoryId();
  }

  @java.lang.Override
  protected void performSubclassRpcCleanup() {
    this.dtoInstance = CategoryDTO.newBuilder().build();
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    // For DTOs, remote creation is not applicable in the same way as for mappers.
    // We assume the DTO is either created locally or populated from an existing ID.
    // If a new ID is needed, it should be generated or provided by the caller.
    // For now, we'll return a new RefactoredObjectID based on a generated UUID or a provided ID.
    // This method might need to be adjusted based on how DTOs are intended to be managed remotely.
    // For simplicity, let's assume if args contain a String, it's the categoryId.
    String categoryId = null;
    if (args.length > 0 && args[0] instanceof String) {
      categoryId = (String) args[0];
    }

    if (categoryId == null || categoryId.isEmpty()) {
      // Generate a new ID if not provided. This is a placeholder.
      // In a real scenario, this might involve a call to an ID generation service.
      categoryId = java.util.UUID.randomUUID().toString();
    }

    // Update the DTO instance with the new ID
    setCategoryId(categoryId);

    // Return a RefactoredObjectID based on the DTO's ID
    return RefactoredObjectID.newBuilder().setInstanceID(categoryId)
        .setOriginalFullyQualifiedClassName(CategoryDTO.getDescriptor().getFullName()).build();
  }

  @Override
  protected void performRpcSetup() throws Exception {
    // No specific RPC setup needed for DTOs as they are data carriers.
    // RPC calls are typically handled by the corresponding Mapper/Service classes.
  }
}
