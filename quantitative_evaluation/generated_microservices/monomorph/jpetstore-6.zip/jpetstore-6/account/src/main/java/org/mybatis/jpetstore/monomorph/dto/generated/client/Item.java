/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import java.math.BigDecimal;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for Item. This class replaces the original domain object
 * org.mybatis.jpetstore.domain.Item and provides the same public API through composition with ItemDTO. It is
 * serializable to maintain compatibility with existing code.
 *
 * @see ItemDTO
 */
public class Item extends AbstractRefactoredClient implements java.io.Serializable {

  private static final long serialVersionUID = -2159121673445254631L;

  private ItemDTO dtoInstance;

  /**
   * Default constructor. Initializes an empty Item object. This is crucial for backward compatibility with code that
   * uses `new Item()`.
   */
  public Item() {
    this.dtoInstance = ItemDTO.newBuilder().build();
  }

  /**
   * Private constructor to initialize from a DTO instance. Used by the fromDTO factory method to enforce encapsulation.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  private Item(ItemDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
  }

  /**
   * Creates a new Item client proxy from a DTO instance.
   *
   * @param dtoInstance
   *          The DTO instance.
   *
   * @return A new Item object wrapping the DTO, or null if the input is null.
   */
  public static Item fromDTO(ItemDTO dtoInstance) {
    if (dtoInstance == null) {
      return null;
    }
    return new Item(dtoInstance);
  }

  /**
   * Creates a new Item client proxy from a RefactoredObjectID.
   *
   * @param refactoredObjectID
   *          The RefactoredObjectID.
   *
   * @return A new Item object wrapping the DTO, or null if the input is null.
   */
  public static Item fromID(RefactoredObjectID refactoredObjectID) {
    if (refactoredObjectID == null || refactoredObjectID.getInstanceID() == null) {
      return null;
    }
    return new Item(ItemDTO.newBuilder().setItemId(refactoredObjectID.getInstanceID()).build());
  }

  /**
   * Returns the internal DTO instance.
   *
   * @return The ItemDTO backing this object.
   */
  public ItemDTO toDTO() {
    return this.dtoInstance;
  }

  // --- START OF DTO GETTERS AND SETTERS ---

  public String getItemId() {
    return dtoInstance.getItemId();
  }

  public void setItemId(String itemId) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (itemId != null) {
      builder.setItemId(itemId.trim());
    } else {
      builder.clearItemId();
    }
    this.dtoInstance = builder.build();
  }

  public int getQuantity() {
    return dtoInstance.getQuantity();
  }

  public void setQuantity(int quantity) {
    this.dtoInstance = dtoInstance.toBuilder().setQuantity(quantity).build();
  }

  public Product getProduct() {
    if (dtoInstance.hasProduct()) {
      return Product.fromDTO(dtoInstance.getProduct());
    }
    return null;
  }

  public void setProduct(Product product) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (product != null) {
      builder.setProduct(product.toDTO());
    } else {
      builder.clearProduct();
    }
    this.dtoInstance = builder.build();
  }

  public int getSupplierId() {
    return dtoInstance.getSupplierId();
  }

  public void setSupplierId(int supplierId) {
    this.dtoInstance = dtoInstance.toBuilder().setSupplierId(supplierId).build();
  }

  public BigDecimal getListPrice() {
    String listPriceStr = dtoInstance.getListPrice();
    if (listPriceStr != null && !listPriceStr.isEmpty()) {
      return new BigDecimal(listPriceStr);
    }
    return null;
  }

  public void setListPrice(BigDecimal listPrice) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (listPrice != null) {
      builder.setListPrice(listPrice.toPlainString());
    } else {
      builder.clearListPrice();
    }
    this.dtoInstance = builder.build();
  }

  public BigDecimal getUnitCost() {
    String unitCostStr = dtoInstance.getUnitCost();
    if (unitCostStr != null && !unitCostStr.isEmpty()) {
      return new BigDecimal(unitCostStr);
    }
    return null;
  }

  public void setUnitCost(BigDecimal unitCost) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (unitCost != null) {
      builder.setUnitCost(unitCost.toPlainString());
    } else {
      builder.clearUnitCost();
    }
    this.dtoInstance = builder.build();
  }

  public String getStatus() {
    return dtoInstance.getStatus();
  }

  public void setStatus(String status) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (status != null) {
      builder.setStatus(status);
    } else {
      builder.clearStatus();
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute1() {
    return dtoInstance.getAttribute1();
  }

  public void setAttribute1(String attribute1) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute1 != null) {
      builder.setAttribute1(attribute1);
    } else {
      builder.clearAttribute1();
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute2() {
    return dtoInstance.getAttribute2();
  }

  public void setAttribute2(String attribute2) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute2 != null) {
      builder.setAttribute2(attribute2);
    } else {
      builder.clearAttribute2();
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute3() {
    return dtoInstance.getAttribute3();
  }

  public void setAttribute3(String attribute3) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute3 != null) {
      builder.setAttribute3(attribute3);
    } else {
      builder.clearAttribute3();
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute4() {
    return dtoInstance.getAttribute4();
  }

  public void setAttribute4(String attribute4) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute4 != null) {
      builder.setAttribute4(attribute4);
    } else {
      builder.clearAttribute4();
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute5() {
    return dtoInstance.getAttribute5();
  }

  public void setAttribute5(String attribute5) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute5 != null) {
      builder.setAttribute5(attribute5);
    } else {
      builder.clearAttribute5();
    }
    this.dtoInstance = builder.build();
  }

  @Override
  public String toString() {
    Product product = getProduct();
    String productId = (product != null && product.getProductId() != null) ? product.getProductId() : "null";
    String itemId = getItemId() != null ? getItemId() : "null";
    return "(" + itemId + "-" + productId + ")";
  }

  @java.lang.Override
  protected void performSubclassRpcCleanup() {
    this.dtoInstance = ItemDTO.newBuilder().build();
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    // For DTOs, remote creation is not applicable in the same way as for mappers.
    // We assume the DTO is either created locally or populated from an existing ID.
    // If a new ID is needed, it should be generated or provided by the caller.
    // For now, we'll return a new RefactoredObjectID based on a generated UUID or a provided ID.
    // This method might need to be adjusted based on how DTOs are intended to be managed remotely.
    // For simplicity, let's assume if args contain a String, it's the itemId.
    String itemId = null;
    if (args.length > 0 && args[0] instanceof String) {
      itemId = (String) args[0];
    }

    if (itemId == null || itemId.isEmpty()) {
      // Generate a new ID if not provided. This is a placeholder.
      // In a real scenario, this might involve a call to an ID generation service.
      itemId = java.util.UUID.randomUUID().toString();
    }

    // Update the DTO instance with the new ID
    setItemId(itemId);

    // Return a RefactoredObjectID based on the DTO's ID
    return RefactoredObjectID.newBuilder().setInstanceID(itemId).setClassID(ItemDTO.getDescriptor().getFullName())
        .build();
  }

  @Override
  protected void performRpcSetup() throws Exception {
    // No specific RPC setup needed for DTOs as they are data carriers.
    // RPC calls are typically handled by the corresponding Mapper/Service classes.
  }
}
