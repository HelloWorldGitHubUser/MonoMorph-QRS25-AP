/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.annotation.PreDestroy;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.GetProductListByCategoryRequest;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.GetProductListByCategoryResponse;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.GetProductRequest;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.GetProductResponse;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.ProductMapperDTO;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.ProductMapperServiceGrpc;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.ProductMapperServiceGrpc.ProductMapperServiceBlockingStub;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.SearchProductListRequest;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.SearchProductListResponse;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for {@link ProductMapper} and {@link ProductMapperDTO}. This class provides the same
 * public API as the original interface but delegates calls to a remote gRPC service.
 */
public class ProductMapper extends AbstractRefactoredClient {
  private static final String TARGET_SERVICE_ID = "productmapper-service";
  private ManagedChannel channel;
  private ProductMapperServiceBlockingStub blockingStub;
  private ProductMapperDTO dtoInstance;

  /**
   * Default constructor. Initializes with an empty DTO.
   */
  public ProductMapper() {
    this.dtoInstance = ProductMapperDTO.newBuilder().build();
    // RPC setup is now handled in performRpcSetup()
  }

  /**
   * Constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  public ProductMapper(ProductMapperDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
    // RPC setup is now handled in performRpcSetup()
  }

  // mapping methods
  public ProductMapperDTO toDTO() {
    return this.dtoInstance;
  }

  public static ProductMapper fromDTO(ProductMapperDTO dtoInstance) {
    return new ProductMapper(dtoInstance);
  }

  /**
   * Creates a new ProductMapper client proxy from a RefactoredObjectID. Since ProductMapper is a service client and not
   * a domain object, the RefactoredObjectID is not used to identify a specific instance. A new instance is always
   * returned.
   *
   * @param refactoredObjectID
   *          The RefactoredObjectID (ignored for service clients).
   *
   * @return A new ProductMapper object.
   */
  public static ProductMapper fromID(RefactoredObjectID refactoredObjectID) {
    return new ProductMapper();
  }

  @Override
  public RefactoredObjectID toID() {
    // For service clients, generate a consistent RefactoredObjectID based on the class name.
    // This ID does not represent a specific instance, but the service client itself.
    return RefactoredObjectID.newBuilder().setClassID(ClassIdRegistry.getClassId(ProductMapper.class.getSimpleName()))
        .build();
  }

  // implementation of the gRPC exposed methods
  public java.util.List<Product> getProductListByCategory(java.lang.String categoryId) {
    ensureInitialized();
    GetProductListByCategoryRequest request = GetProductListByCategoryRequest.newBuilder().setCategoryId(categoryId)
        .build();

    GetProductListByCategoryResponse response = blockingStub.getProductListByCategory(request);

    return response.getProductsList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }

  public Product getProduct(java.lang.String productId) {
    ensureInitialized();
    GetProductRequest request = GetProductRequest.newBuilder().setProductId(productId).build();

    GetProductResponse response = blockingStub.getProduct(request);

    return response.hasProduct() ? Product.fromDTO(response.getProduct()) : null;
  }

  public java.util.List<Product> searchProductList(java.lang.String keywords) {
    ensureInitialized();
    SearchProductListRequest request = SearchProductListRequest.newBuilder().setKeywords(keywords).build();

    SearchProductListResponse response = blockingStub.searchProductList(request);

    return response.getProductsList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }

  /**
   * Shuts down the gRPC channel to release resources.
   *
   * @throws InterruptedException
   *           if the channel fails to shut down in time.
   */
  @PreDestroy
  public void shutdown() throws InterruptedException {
    if (channel != null) {
      channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }
  }

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---
  // The ProductMapperDTO is empty, so there are no getters or setters.
  // --- END OF DTO GETTERS AND SETTERS ---

  @Override
  protected void performSubclassRpcCleanup() {
    // For service clients, we can reset the DTO instance if needed, or simply do nothing.
    // Since ProductMapperDTO has no fields, resetting it is not strictly necessary but good practice.
    this.dtoInstance = ProductMapperDTO.newBuilder().build();
    // Also, shut down the channel to release resources.
    try {
      shutdown();
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new RuntimeException("Failed to shut down gRPC channel for ProductMapper", e);
    }
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    // For service clients, remote creation is not applicable in the same way as for domain objects.
    // We return a RefactoredObjectID representing the service client itself.
    return RefactoredObjectID.newBuilder().setClassID(ClassIdRegistry.getClassId(ProductMapper.class.getSimpleName()))
        .build();
  }

  @Override
  protected void performRpcSetup() throws Exception {
    if (this.channel == null || this.channel.isShutdown() || this.channel.isTerminated()) {
      ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
      String target = endpoint.getHost() + ":" + endpoint.getPort();
      this.channel = ManagedChannelBuilder.forTarget(target).usePlaintext().build();
      this.blockingStub = ProductMapperServiceGrpc.newBlockingStub(channel);
    }
  }
}
