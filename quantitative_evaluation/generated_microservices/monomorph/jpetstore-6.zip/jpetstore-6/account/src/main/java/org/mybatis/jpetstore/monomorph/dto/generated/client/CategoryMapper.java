/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

// gRPC and Service Discovery imports
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

// Standard Java imports
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.annotation.PreDestroy;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.categorymapper.*;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry.ServiceEndpoint;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for the CategoryMapper service. This class replaces the original
 * org.mybatis.jpetstore.mapper.CategoryMapper interface and provides the same API through composition and gRPC calls.
 */
public class CategoryMapper extends AbstractRefactoredClient { // Extend AbstractRefactoredClient

  private static final String TARGET_SERVICE_ID = "categorymapper-service";
  private ManagedChannel channel;
  private CategoryMapperServiceGrpc.CategoryMapperServiceBlockingStub blockingStub;

  private final CategoryMapperDTO dtoInstance;

  /**
   * Default constructor. Initializes the gRPC client for communication with the remote service.
   */
  public CategoryMapper() {
    this.dtoInstance = CategoryMapperDTO.newBuilder().build();
    // RPC setup is now handled in performRpcSetup()
  }

  /**
   * Constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance representing the object's state.
   */
  public CategoryMapper(CategoryMapperDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
    // RPC setup is now handled in performRpcSetup()
  }

  // mapping methods
  public CategoryMapperDTO toDTO() {
    return this.dtoInstance;
  }

  public static CategoryMapper fromDTO(CategoryMapperDTO dtoInstance) {
    return new CategoryMapper(dtoInstance);
  }

  /**
   * Creates a new CategoryMapper client proxy from a RefactoredObjectID. Since CategoryMapper is a service client and
   * not a domain object, the RefactoredObjectID is not used to identify a specific instance. A new instance is always
   * returned.
   *
   * @param refactoredObjectID
   *          The RefactoredObjectID (ignored for service clients).
   *
   * @return A new CategoryMapper object.
   */
  public static CategoryMapper fromID(RefactoredObjectID refactoredObjectID) {
    return new CategoryMapper();
  }

  @Override
  public RefactoredObjectID toID() {
    // For service clients, generate a consistent RefactoredObjectID based on the class name.
    // This ID does not represent a specific instance, but the service client itself.
    return RefactoredObjectID.newBuilder().setClassID(ClassIdRegistry.getClassId(CategoryMapper.class.getSimpleName()))
        .build();
  }

  // implementation of the gRPC exposed methods
  public List<org.mybatis.jpetstore.monomorph.dto.generated.client.Category> getCategoryList() {
    ensureInitialized();
    GetCategoryListRequest request = GetCategoryListRequest.newBuilder().build();
    GetCategoryListResponse response = blockingStub.getCategoryList(request);

    return response.getCategoriesList().stream().map(this::convertToCategoryDTO)
        .map(org.mybatis.jpetstore.monomorph.dto.generated.client.Category::fromDTO).collect(Collectors.toList());
  }

  public org.mybatis.jpetstore.monomorph.dto.generated.client.Category getCategory(String categoryId) {
    ensureInitialized();
    GetCategoryRequest request = GetCategoryRequest.newBuilder().setCategoryId(categoryId).build();
    GetCategoryResponse response = blockingStub.getCategory(request);

    if (response.hasCategory()) {
      org.mybatis.jpetstore.monomorph.dto.generated.proto.category.CategoryDTO categoryDto = convertToCategoryDTO(
          response.getCategory());
      return org.mybatis.jpetstore.monomorph.dto.generated.client.Category.fromDTO(categoryDto);
    }
    // Return null if category is not found, matching original mapper behavior.
    return null;
  }

  /**
   * Helper method to convert from categorymapper.Category to category.CategoryDTO. This is necessary because the gRPC
   * service returns categorymapper.Category, but the client-side Category.fromDTO expects category.CategoryDTO.
   *
   * @param categoryMapperProto
   *          The Category object from the categorymapper proto.
   *
   * @return The converted CategoryDTO object.
   */
  private org.mybatis.jpetstore.monomorph.dto.generated.proto.category.CategoryDTO convertToCategoryDTO(
      org.mybatis.jpetstore.monomorph.dto.generated.proto.categorymapper.Category categoryMapperProto) {
    return org.mybatis.jpetstore.monomorph.dto.generated.proto.category.CategoryDTO.newBuilder()
        .setCategoryId(categoryMapperProto.getCategoryId()).setName(categoryMapperProto.getName())
        .setDescription(categoryMapperProto.getDescription()).build();
  }

  /**
   * Shuts down the gRPC channel to release resources.
   *
   * @throws InterruptedException
   *           if the channel fails to shut down in time.
   */
  @PreDestroy
  public void shutdown() throws InterruptedException {
    if (channel != null) {
      channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }
  }

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---
  // No fields in CategoryMapperDTO, so no getters or setters are needed.
  // --- END OF DTO GETTERS AND SETTERS ---

  @Override
  protected void performSubclassRpcCleanup() {
    // For service clients, we can reset the DTO instance if needed, or simply do nothing.
    // Since CategoryMapperDTO has no fields, resetting it is not strictly necessary but good practice.
    // this.dtoInstance = CategoryMapperDTO.newBuilder().build(); // Removed as dtoInstance is final
    // Also, shut down the channel to release resources.
    try {
      shutdown();
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new RuntimeException("Failed to shut down gRPC channel for CategoryMapper", e);
    }
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    // For service clients, remote creation is not applicable in the same way as for domain objects.
    // We return a RefactoredObjectID representing the service client itself.
    return RefactoredObjectID.newBuilder().setClassID(ClassIdRegistry.getClassId(CategoryMapper.class.getSimpleName()))
        .build();
  }

  @Override
  protected void performRpcSetup() throws Exception {
    if (this.channel == null || this.channel.isShutdown() || this.channel.isTerminated()) {
      ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
      String target = endpoint.getHost() + ":" + endpoint.getPort();
      this.channel = ManagedChannelBuilder.forTarget(target).usePlaintext().build();
      this.blockingStub = CategoryMapperServiceGrpc.newBlockingStub(channel);
    }
  }
}
