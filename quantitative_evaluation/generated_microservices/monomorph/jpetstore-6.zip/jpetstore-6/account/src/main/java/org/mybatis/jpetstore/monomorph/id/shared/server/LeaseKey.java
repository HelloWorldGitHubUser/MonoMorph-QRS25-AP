/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.shared.server;

import java.io.Serializable;
import java.util.Objects;

/**
 * Uniquely identifies a specific lease held by a client for a specific object instance. Used as the key in the Caffeine
 * cache. Immutable.
 */
public final class LeaseKey implements Serializable {
  private static final long serialVersionUID = 1L;

  private final String instanceId;
  private final String clientId;

  /**
   * Creates a new LeaseKey.
   *
   * @param instanceId
   *          The unique ID of the object instance. Must not be null.
   * @param clientId
   *          The unique ID of the client holding the lease. Must not be null.
   *
   * @throws NullPointerException
   *           if instanceId or clientId is null.
   */
  public LeaseKey(String instanceId, String clientId) {
    // Using Objects.requireNonNull is generally acceptable for Java 7+ builds
    // If strictly targeting only Java 7 *runtime features*, use a manual check.
    this.instanceId = Objects.requireNonNull(instanceId, "instanceId cannot be null in LeaseKey");
    this.clientId = Objects.requireNonNull(clientId, "clientId cannot be null in LeaseKey");
  }

  public String getInstanceId() {
    return instanceId;
  }

  public String getClientId() {
    return clientId;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    LeaseKey leaseKey = (LeaseKey) o;
    // Both fields must match for equality.
    if (!instanceId.equals(leaseKey.instanceId))
      return false;
    return clientId.equals(leaseKey.clientId);
  }

  @Override
  public int hashCode() {
    int result = instanceId.hashCode();
    result = 31 * result + clientId.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return "LeaseKey{" + "instanceId='" + instanceId + '\'' + ", clientId='" + clientId + '\'' + '}';
  }
}
