/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.product.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for {@link org.mybatis.jpetstore.domain.Product} and {@link ProductDTO}. This class
 * provides the same public API as the original class but uses a DTO for data storage and retrieval, enabling
 * microservice communication.
 */
public class Product extends AbstractRefactoredClient implements java.io.Serializable {

  private static final long serialVersionUID = -2159121673445254631L;

  private ProductDTO dtoInstance;

  /**
   * Default constructor. Initializes an empty Product with a default DTO instance.
   */
  public Product() {
    this.dtoInstance = ProductDTO.newBuilder().build();
  }

  /**
   * Private constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  private Product(ProductDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
  }

  // mapping methods
  public ProductDTO toDTO() {
    return this.dtoInstance;
  }

  public static Product fromDTO(ProductDTO dtoInstance) {
    if (dtoInstance == null) {
      return null;
    }
    return new Product(dtoInstance);
  }

  /**
   * Creates a new Product client proxy from a RefactoredObjectID.
   *
   * @param refactoredObjectID
   *          The RefactoredObjectID.
   *
   * @return A new Product object wrapping the DTO, or null if the input is null.
   */
  public static Product fromID(RefactoredObjectID refactoredObjectID) {
    if (refactoredObjectID == null || refactoredObjectID.getInstanceID() == null) {
      return null;
    }
    return new Product(ProductDTO.newBuilder().setProductId(refactoredObjectID.getInstanceID()).build());
  }

  // implementation of the gRPC exposed methods
  // No RPC methods were defined in the service, so none are implemented here.

  // --- START OF DTO GETTERS AND SETTERS ---

  public java.lang.String getProductId() {
    return dtoInstance.getProductId();
  }

  public void setProductId(java.lang.String productId) {
    ProductDTO.Builder builder = dtoInstance.toBuilder();
    if (productId != null) {
      builder.setProductId(productId.trim());
    } else {
      builder.clearProductId();
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getCategoryId() {
    return dtoInstance.getCategoryId();
  }

  public void setCategoryId(java.lang.String categoryId) {
    ProductDTO.Builder builder = dtoInstance.toBuilder();
    if (categoryId != null) {
      builder.setCategoryId(categoryId.trim());
    } else {
      builder.clearCategoryId();
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getName() {
    return dtoInstance.getName();
  }

  public void setName(java.lang.String name) {
    ProductDTO.Builder builder = dtoInstance.toBuilder();
    if (name != null) {
      builder.setName(name);
    } else {
      builder.clearName();
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getDescription() {
    return dtoInstance.getDescription();
  }

  public void setDescription(java.lang.String description) {
    ProductDTO.Builder builder = dtoInstance.toBuilder();
    if (description != null) {
      builder.setDescription(description);
    } else {
      builder.clearDescription();
    }
    this.dtoInstance = builder.build();
  }

  @java.lang.Override
  public java.lang.String toString() {
    // Replicates original class behavior: return getName();
    return getName();
  }

  @java.lang.Override
  protected void performSubclassRpcCleanup() {
    this.dtoInstance = ProductDTO.newBuilder().build();
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    // For DTOs, remote creation is not applicable in the same way as for mappers.
    // We assume the DTO is either created locally or populated from an existing ID.
    // If a new ID is needed, it should be generated or provided by the caller.
    // For now, we'll return a new RefactoredObjectID based on a generated UUID or a provided ID.
    // This method might need to be adjusted based on how DTOs are intended to be managed remotely.
    // For simplicity, let's assume if args contain a String, it's the productId.
    String productId = null;
    if (args.length > 0 && args[0] instanceof String) {
      productId = (String) args[0];
    }

    if (productId == null || productId.isEmpty()) {
      // Generate a new ID if not provided. This is a placeholder.
      // In a real scenario, this might involve a call to an ID generation service.
      productId = java.util.UUID.randomUUID().toString();
    }

    // Update the DTO instance with the new ID
    setProductId(productId);

    // Return a RefactoredObjectID based on the DTO's ID
    return RefactoredObjectID.newBuilder().setInstanceID(productId).setClassID(ProductDTO.getDescriptor().getFullName())
        .build();
  }

  @Override
  protected void performRpcSetup() throws Exception {
    // No specific RPC setup needed for DTOs as they are data carriers.
    // RPC calls are typically handled by the corresponding Mapper/Service classes.
  }
}
