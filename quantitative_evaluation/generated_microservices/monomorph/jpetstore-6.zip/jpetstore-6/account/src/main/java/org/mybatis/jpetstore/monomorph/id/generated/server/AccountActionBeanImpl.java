/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.server;

import io.grpc.stub.StreamObserver;

import java.util.Objects;
import java.util.UUID;

import org.mybatis.jpetstore.monomorph.dto.mappers.AccountMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.server.LeaseManager;
import org.mybatis.jpetstore.monomorph.id.shared.server.ServerObjectManager;
import org.mybatis.jpetstore.web.actions.AccountActionBean;

/**
 * gRPC Service implementation for AccountActionBean. - Handles gRPC requests for AccountActionBean API. - Creates
 * transient AccountActionBean instances. - Interacts with LeaseManager for instance registration/retrieval. - Calls
 * business methods on retrieved AccountActionBean instances.
 */
public class AccountActionBeanImpl extends AccountActionBeanServiceGrpc.AccountActionBeanServiceImplBase
    implements ServerObjectManager {

  private final LeaseManager leaseManager;
  private final String serviceId = ServiceRegistry.getServiceId();

  // Static identifier for the class type managed by this service
  public static final String CLASS_ID = ClassIdRegistry.getClassId("AccountActionBean");

  public AccountActionBeanImpl(LeaseManager leaseManager) {
    this.leaseManager = Objects.requireNonNull(leaseManager, "LeaseManager cannot be null");
  }

  // --- createObject gRPC Method Implementation ---

  @Override
  public void createObject(CreateObjectRequest request, StreamObserver<RefactoredObjectID> responseObserver) {
    try {
      // 1. Extract args & client ID
      String clientId = request.getClientID();
      // ConstructorArgs is empty for the default constructor, so no mapping is needed.

      // 2. *** Create the transient instance DIRECTLY ***
      AccountActionBean newInstance = new AccountActionBean();

      // 3. Generate a RefactoredObjectID ID and register with LeaseManager
      RefactoredObjectID responseProto = toID(newInstance, clientId);

      // 4. Send the response
      responseObserver.onNext(responseProto);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  // --- Start of ServerObjectManager method implementations ---
  @Override
  public RefactoredObjectID toID(Object instance, String clientId) throws Exception {
    // Validate if id instance exists
    String instanceId = leaseManager.findInstanceIdForInstance(instance);
    if (instanceId == null) {
      // Generate a new unique instance ID
      instanceId = UUID.randomUUID().toString();
    }
    // Register with LeaseManager
    boolean registered = leaseManager.registerInstanceAndGrantLease(instanceId, CLASS_ID, instance, clientId);
    if (!registered) {
      throw new RuntimeException("Failed to register new instance ID: " + instanceId);
    }
    // Build RefactoredObjectID
    return RefactoredObjectID.newBuilder().setInstanceID(instanceId).setClassID(CLASS_ID).setServiceID(this.serviceId)
        .build();
  }

  @Override
  public RefactoredObjectID toID(Object instance) throws Exception {
    return toID(instance, serviceId);
  }

  @Override
  public AccountActionBean fromID(RefactoredObjectID id) throws Exception {
    // Validate the class ID
    if (id.getClassID() == null || !id.getClassID().equals(CLASS_ID)) {
      throw new IllegalArgumentException("Class ID mismatch: expected " + CLASS_ID + ", got " + id.getClassID());
    }
    // Retrieve the instance from LeaseManager
    AccountActionBean instance = (AccountActionBean) leaseManager.getInstance(id.getInstanceID());
    if (instance == null) {
      throw new IllegalArgumentException("No instance found for ID: " + id.getInstanceID());
    }
    return instance;
  }

  @Override
  public String getManagedClassId() {
    return CLASS_ID;
  }

  @Override
  public String getServiceId() {
    return serviceId;
  }
  // --- End of ServerObjectManager method implementations ---

  // --- Other gRPC methods defined in the proto file ---

  @Override
  public void getAccount(GetAccountRequest request, StreamObserver<GetAccountResponse> responseObserver) {
    try {
      // Retrieve the instance using the provided ID
      AccountActionBean instance = fromID(request.getObjectId());

      // Call the actual method from the original class
      org.mybatis.jpetstore.domain.Account account = instance.getAccount();

      // Map the domain object to its DTO representation
      org.mybatis.jpetstore.monomorph.dto.generated.proto.account.AccountDTO accountDto = AccountMapper.INSTANCE
          .toDTO(account);

      // Build and send the response
      GetAccountResponse response = GetAccountResponse.newBuilder().setAccount(accountDto).build();
      responseObserver.onNext(response);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void isAuthenticated(IsAuthenticatedRequest request,
      StreamObserver<IsAuthenticatedResponse> responseObserver) {
    try {
      // Retrieve the instance using the provided ID
      AccountActionBean instance = fromID(request.getObjectId());

      // Call the actual method from the original class
      boolean authenticated = instance.isAuthenticated();

      // Build and send the response
      IsAuthenticatedResponse response = IsAuthenticatedResponse.newBuilder().setAuthenticated(authenticated).build();
      responseObserver.onNext(response);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }
}
