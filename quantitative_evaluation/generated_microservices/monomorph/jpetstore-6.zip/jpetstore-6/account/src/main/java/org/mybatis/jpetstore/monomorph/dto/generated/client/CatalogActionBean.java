/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import java.util.List;
import java.util.stream.Collectors;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.catalogactionbean.CatalogActionBeanDTO;
import org.mybatis.jpetstore.monomorph.id.generated.client.CatalogService;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.IDMapper;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for {@code org.mybatis.jpetstore.web.actions.CatalogActionBean} and
 * {@link CatalogActionBeanDTO}. This client uses composition to encapsulate the DTO and provides the same public API as
 * the original class.
 */
public class CatalogActionBean extends AbstractRefactoredClient {
  private CatalogActionBeanDTO dtoInstance;

  /**
   * Default constructor. Initializes a new DTO instance with default values.
   */
  public CatalogActionBean() {
    this.dtoInstance = CatalogActionBeanDTO.newBuilder().build();
  }

  /**
   * Private constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  private CatalogActionBean(CatalogActionBeanDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
  }

  /**
   * Factory method to create a new client instance from a DTO.
   *
   * @param dtoInstance
   *          The DTO instance.
   *
   * @return A new CatalogActionBean client instance.
   */
  public static CatalogActionBean fromDTO(CatalogActionBeanDTO dtoInstance) {
    return new CatalogActionBean(dtoInstance);
  }

  /**
   * Returns the underlying DTO instance.
   *
   * @return The CatalogActionBeanDTO.
   */
  public CatalogActionBeanDTO toDTO() {
    return this.dtoInstance;
  }

  @Override
  public RefactoredObjectID toID() {
    // For action beans, generate a consistent RefactoredObjectID based on the class name.
    // This ID does not represent a specific instance, but the action bean itself.
    return RefactoredObjectID.newBuilder()
        .setClassID(ClassIdRegistry.getClassId(CatalogActionBean.class.getSimpleName())).build();
  }

  // Since no gRPC service methods were defined in the proto,
  // no business logic methods (e.g., viewCategory, searchProducts) are implemented here.
  // The client's primary role is to act as a data container with the same API as the original class.

  // --- START OF DTO GETTERS AND SETTERS ---

  public String getKeyword() {
    return dtoInstance.hasKeyword() ? dtoInstance.getKeyword() : null;
  }

  public void setKeyword(String keyword) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (keyword != null) {
      builder.setKeyword(keyword);
    } else {
      builder.clearKeyword();
    }
    this.dtoInstance = builder.build();
  }

  public String getCategoryId() {
    return dtoInstance.hasCategoryId() ? dtoInstance.getCategoryId() : null;
  }

  public void setCategoryId(String categoryId) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (categoryId != null) {
      builder.setCategoryId(categoryId);
    } else {
      builder.clearCategoryId();
    }
    this.dtoInstance = builder.build();
  }

  public String getProductId() {
    return dtoInstance.hasProductId() ? dtoInstance.getProductId() : null;
  }

  public void setProductId(String productId) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (productId != null) {
      builder.setProductId(productId);
    } else {
      builder.clearProductId();
    }
    this.dtoInstance = builder.build();
  }

  public String getItemId() {
    return dtoInstance.hasItemId() ? dtoInstance.getItemId() : null;
  }

  public void setItemId(String itemId) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (itemId != null) {
      builder.setItemId(itemId);
    } else {
      builder.clearItemId();
    }
    this.dtoInstance = builder.build();
  }

  public Category getCategory() {
    if (!dtoInstance.hasCategory()) {
      return null;
    }
    return Category.fromDTO(dtoInstance.getCategory());
  }

  public void setCategory(Category category) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (category != null) {
      builder.setCategory(category.toDTO());
    } else {
      builder.clearCategory();
    }
    this.dtoInstance = builder.build();
  }

  public Product getProduct() {
    if (!dtoInstance.hasProduct()) {
      return null;
    }
    return Product.fromDTO(dtoInstance.getProduct());
  }

  public void setProduct(Product product) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (product != null) {
      builder.setProduct(product.toDTO());
    } else {
      builder.clearProduct();
    }
    this.dtoInstance = builder.build();
  }

  public Item getItem() {
    if (!dtoInstance.hasItem()) {
      return null;
    }
    return Item.fromDTO(dtoInstance.getItem());
  }

  public void setItem(Item item) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (item != null) {
      builder.setItem(item.toDTO());
    } else {
      builder.clearItem();
    }
    this.dtoInstance = builder.build();
  }

  public List<Category> getCategoryList() {
    if (dtoInstance.getCategoryListList() == null || dtoInstance.getCategoryListList().isEmpty()) {
      return null;
    }
    return dtoInstance.getCategoryListList().stream().map(Category::fromDTO).collect(Collectors.toList());
  }

  public void setCategoryList(List<Category> categoryList) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder().clearCategoryList();
    if (categoryList != null) {
      builder.addAllCategoryList(categoryList.stream().map(Category::toDTO).collect(Collectors.toList()));
    }
    this.dtoInstance = builder.build();
  }

  public List<Product> getProductList() {
    if (dtoInstance.getProductListList() == null || dtoInstance.getProductListList().isEmpty()) {
      return null;
    }
    return dtoInstance.getProductListList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }

  public void setProductList(List<Product> productList) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder().clearProductList();
    if (productList != null) {
      builder.addAllProductList(productList.stream().map(Product::toDTO).collect(Collectors.toList()));
    }
    this.dtoInstance = builder.build();
  }

  public List<Item> getItemList() {
    if (dtoInstance.getItemListList() == null || dtoInstance.getItemListList().isEmpty()) {
      return null;
    }
    return dtoInstance.getItemListList().stream().map(Item::fromDTO).collect(Collectors.toList());
  }

  public void setItemList(List<Item> itemList) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder().clearItemList();
    if (itemList != null) {
      builder.addAllItemList(itemList.stream().map(Item::toDTO).collect(Collectors.toList()));
    }
    this.dtoInstance = builder.build();
  }

  public CatalogService getCatalogService() throws Exception {
    if (!dtoInstance.hasCatalogService()) {
      return null;
    }
    return (CatalogService) IDMapper.fromID(dtoInstance.getCatalogService());
  }

  public void setCatalogService(CatalogService catalogService) throws Exception {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (catalogService != null) {
      builder.setCatalogService(IDMapper.toID(catalogService));
    } else {
      builder.clearCatalogService();
    }
    this.dtoInstance = builder.build();
  }

  // --- END OF DTO GETTERS AND SETTERS ---

  @Override
  protected void performSubclassRpcCleanup() {
    this.dtoInstance = CatalogActionBeanDTO.newBuilder().build();
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    // For action beans, remote creation is not applicable in the same way as for domain objects.
    // We return a RefactoredObjectID representing the action bean itself.
    return RefactoredObjectID.newBuilder()
        .setClassID(ClassIdRegistry.getClassId(CatalogActionBean.class.getSimpleName())).build();
  }

  @Override
  protected void performRpcSetup() throws Exception {
    // No specific RPC setup needed for action beans as they are data carriers.
    // RPC calls are typically handled by the corresponding Mapper/Service classes.
  }
}
