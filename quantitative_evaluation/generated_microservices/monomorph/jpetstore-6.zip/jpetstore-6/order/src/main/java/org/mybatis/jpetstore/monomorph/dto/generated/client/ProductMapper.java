/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

// gRPC and service discovery imports
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.List;
import java.util.stream.Collectors;

// Proto-generated DTO, request, response, and service classes
import org.mybatis.jpetstore.monomorph.dto.generated.proto.productmapper.*;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry.ServiceEndpoint;

/**
 * Auto-generated DTO gRPC client for ProductMapper. This class provides the same API as the original
 * org.mybatis.jpetstore.mapper.ProductMapper interface but delegates calls to a remote gRPC service. It uses
 * composition with {@link ProductMapperDTO}.
 */
public class ProductMapper {
  private static final String TARGET_SERVICE_ID = "productmapper-service";
  private ProductMapperDTO dtoInstance;

  private transient ManagedChannel channel;
  private transient ProductMapperServiceGrpc.ProductMapperServiceBlockingStub blockingStub;

  /**
   * Default constructor. Initializes the gRPC client for the ProductMapper service.
   */
  public ProductMapper() {
    this.dtoInstance = ProductMapperDTO.getDefaultInstance();
    performRpcSetup();
  }

  public ProductMapper(ProductMapperDTO dtoInstance) {
    // dtoConstructor to initialize from a DTO instance
    this.dtoInstance = (dtoInstance == null) ? ProductMapperDTO.getDefaultInstance() : dtoInstance;
    performRpcSetup();
  }

  /**
   * Initializes the gRPC channel and stub for communication.
   */
  private void performRpcSetup() {
    ServiceEndpoint location = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    ManagedChannel managedChannel = ManagedChannelBuilder.forAddress(location.getHost(), location.getPort())
        .usePlaintext().build();
    this.channel = managedChannel;
    this.blockingStub = ProductMapperServiceGrpc.newBlockingStub(this.channel);
  }

  // mapping methods
  public ProductMapperDTO toDTO() {
    return this.dtoInstance;
  }

  public static ProductMapper fromDTO(ProductMapperDTO dtoInstance) {
    return new ProductMapper(dtoInstance);
  }

  // implementation of the gRPC exposed methods

  /**
   * Retrieves a list of products by category from the remote service.
   *
   * @param categoryId
   *          The category ID.
   *
   * @return A list of Product objects.
   */
  public List<Product> getProductListByCategory(String categoryId) {
    GetProductListByCategoryRequest request = GetProductListByCategoryRequest.newBuilder().setCategoryId(categoryId)
        .build();
    GetProductListByCategoryResponse response = blockingStub.getProductListByCategory(request);
    return response.getProductsList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }

  /**
   * Retrieves a single product by its ID from the remote service.
   *
   * @param productId
   *          The product ID.
   *
   * @return The Product object, or null if not found.
   */
  public Product getProduct(String productId) {
    GetProductRequest request = GetProductRequest.newBuilder().setProductId(productId).build();
    GetProductResponse response = blockingStub.getProduct(request);
    if (response.hasProduct()) {
      return Product.fromDTO(response.getProduct());
    }
    return null;
  }

  /**
   * Searches for products based on keywords from the remote service.
   *
   * @param keywords
   *          The search keywords.
   *
   * @return A list of matching Product objects.
   */
  public List<Product> searchProductList(String keywords) {
    SearchProductListRequest request = SearchProductListRequest.newBuilder().setKeywords(keywords).build();
    SearchProductListResponse response = blockingStub.searchProductList(request);
    return response.getProductsList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---
  // ProductMapperDTO is empty, so there are no fields and thus no getters or setters.
  // --- END OF DTO GETTERS AND SETTERS ---
}
