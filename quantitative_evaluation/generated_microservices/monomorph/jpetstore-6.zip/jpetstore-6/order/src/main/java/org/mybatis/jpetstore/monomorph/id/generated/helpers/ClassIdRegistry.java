/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package org.mybatis.jpetstore.monomorph.id.generated.helpers;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ClassIdRegistry This utility class provides a registry for mapping logical class names (keys) to integer Class IDs.
 * It allows configuration of these IDs via environment variables, with specified default values. Usage: // Retrieve a
 * class ID using its logical key (initialization happens automatically on first use) int id =
 * ClassIdRegistry.getClassId("YourClassLogicalName"); Configuration: For each registered class key (e.g., "MyClass"),
 * the registry checks an environment variable (e.g., "MY_CLASS_ID"). If the variable is set and contains a valid
 * integer, that value is used. Otherwise, the configured default ID is used.
 */
public final class ClassIdRegistry {

  private static final Map<String, String> registry = new ConcurrentHashMap<>();
  private static final Object initLock = new Object();
  private static volatile boolean initialized = false;

  /**
   * Initializes the registry by loading class IDs based on environment variables or defaults. This method is
   * thread-safe and idempotent. It's called automatically on the first call to `getClassId` if not called explicitly
   * beforehand.
   */
  public static void initialize() {
    if (initialized) {
      return;
    }
    synchronized (initLock) {
      if (initialized) {
        return;
      }
      // --- Register known class IDs ---

      registerClassInternal("AccountActionBeanImpl", "ACCOUNTACTIONBEANIMPL_CID", "cc6b6e29");

      registerClassInternal("AccountImpl", "ACCOUNTIMPL_CID", "62759af3");

      registerClassInternal("CartImpl", "CARTIMPL_CID", "36a9b0e1");

      registerClassInternal("CartItemImpl", "CARTITEMIMPL_CID", "6959fcce");

      registerClassInternal("CatalogServiceImpl", "CATALOGSERVICEIMPL_CID", "a2cc9bea");

      registerClassInternal("ItemMapperImpl", "ITEMMAPPERIMPL_CID", "95201789");

      registerClassInternal("ItemImpl", "ITEMIMPL_CID", "73c3f472");

      registerClassInternal("CartActionBeanImpl", "CARTACTIONBEANIMPL_CID", "5df0dc1c");

      // --- End of known class IDs ---

      initialized = true;
    }
  }

  /**
   * Internal method to register a single class key, its environment variable, and default ID. It resolves the actual ID
   * based on environment settings.
   *
   * @param classKey
   *          The logical name/key for the class.
   * @param envVarName
   *          The name of the environment variable to check for the ID.
   * @param defaultClassId
   *          The default ID to use if the environment variable is missing or invalid.
   */
  private static void registerClassInternal(String classKey, String envVarName, String defaultClassId) {
    String envValue = null;
    String resolvedClassId = defaultClassId; // Start with the default

    try {
      envValue = System.getenv(envVarName);
      if (envValue != null && !envValue.isEmpty()) {
        resolvedClassId = resolvedClassId;
      }
      // If envValue is null or empty, resolvedClassId remains the default
    } catch (SecurityException e) {
    } catch (Exception e) {
    }

    registry.put(classKey, resolvedClassId);
  }

  /**
   * Retrieves the registered Class ID for the given logical class key. Ensures the registry is initialized before
   * attempting lookup.
   *
   * @param classKey
   *          The logical name/key of the class whose ID is requested.
   *
   * @return The resolved Class ID.
   *
   * @throws IllegalArgumentException
   *           if the classKey is not found in the registry.
   */
  public static String getClassId(String classKey) {
    if (!initialized) {
      initialize(); // Auto-initialize on first access
    }
    String classId = registry.get(classKey);
    if (classId == null) {
      throw new IllegalArgumentException(
          "Class Key '" + classKey + "' not found in ClassIdRegistry. Registered keys: " + registry.keySet());
    }
    return classId; // Auto-unboxing
  }

  /**
   * Returns an unmodifiable set of all registered class keys. Ensures the registry is initialized.
   *
   * @return A Set containing all registered class keys.
   */
  public static Set<String> getRegisteredClassKeys() {
    if (!initialized) {
      initialize();
    }
    return Collections.unmodifiableSet(registry.keySet());
  }

  /**
   * Private constructor to prevent instantiation of this utility class.
   */
  private ClassIdRegistry() {
    throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
  }
}
