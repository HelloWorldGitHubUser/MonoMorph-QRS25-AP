/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import java.io.Serializable;
import java.math.BigDecimal;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartitem.CartItemDTO;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;

public class CartItem implements Serializable {

  private static final long serialVersionUID = 6607848080126162093L;

  private String itemId;
  private String productId;
  private int quantity;
  private BigDecimal unitCost;
  private BigDecimal total;

  public CartItem() {
  }

  // New constructor for DTO conversion
  private CartItem(CartItemDTO dto) {
    this.itemId = dto.getItem().getItemId();
    this.productId = dto.getItem().getProductId();
    this.quantity = dto.getQuantity();
    this.unitCost = new BigDecimal(dto.getItem().getUnitCost());
    this.total = new BigDecimal(dto.getTotal());
  }

  // New toDTO method
  public CartItemDTO toDTO() {
    ItemDTO itemDto = ItemDTO.newBuilder().setItemId(this.itemId == null ? "" : this.itemId)
        .setProductId(this.productId == null ? "" : this.productId)
        .setUnitCost(this.unitCost == null ? "0.0" : this.unitCost.toPlainString()).build();

    return CartItemDTO.newBuilder().setItem(itemDto).setQuantity(this.quantity)
        .setTotal(this.total == null ? "0.0" : this.total.toPlainString()).build();
  }

  // New fromDTO method
  public static CartItem fromDTO(CartItemDTO dto) {
    return new CartItem(dto);
  }

  public String getItemId() {
    return itemId;
  }

  public void setItemId(String itemId) {
    this.itemId = itemId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  public BigDecimal getUnitCost() {
    return unitCost;
  }

  public void setUnitCost(BigDecimal unitCost) {
    this.unitCost = unitCost;
  }

  public BigDecimal getTotal() {
    return total;
  }

  public void setTotal(BigDecimal total) {
    this.total = total;
  }
}
