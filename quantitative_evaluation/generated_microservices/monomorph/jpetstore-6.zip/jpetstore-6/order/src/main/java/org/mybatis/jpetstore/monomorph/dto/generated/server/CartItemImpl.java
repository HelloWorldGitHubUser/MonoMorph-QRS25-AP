/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.server;

import io.grpc.stub.StreamObserver;

import org.mybatis.jpetstore.domain.CartItem;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartitem.CartItemDTO;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartitem.CartItemServiceGrpc;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartitem.IncrementQuantityRequest;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartitem.IncrementQuantityResponse;

/**
 * gRPC Service implementation for CartItem. - Handles gRPC requests for CartItem API. - Interacts with Mapper for
 * switching between DTO and CartItem instances.
 */
public class CartItemImpl extends CartItemServiceGrpc.CartItemServiceImplBase {

  /**
   * Implements the incrementQuantity RPC method based on an assumed service definition. This method follows the
   * DTO-to-domain-to-DTO pattern to apply business logic.
   *
   * @param request
   *          The gRPC request containing the source CartItemDTO.
   * @param responseObserver
   *          The observer used to send the response.
   */
  @Override
  public void incrementQuantity(IncrementQuantityRequest request,
      StreamObserver<IncrementQuantityResponse> responseObserver) {
    // 1. Retrieve the DTO from the request
    CartItemDTO requestDto = request.getCartItem();

    // 2. Map the DTO to the domain object
    CartItem cartItem = CartItemMapper.INSTANCE.fromDTO(requestDto);

    // 3. Call the corresponding business logic method
    cartItem.incrementQuantity();

    // 4. Map the updated domain object back to a DTO
    CartItemDTO responseDto = CartItemMapper.INSTANCE.toDTO(cartItem);

    // 5. Build and send the response
    IncrementQuantityResponse response = IncrementQuantityResponse.newBuilder().setCartItem(responseDto).build();
    responseObserver.onNext(response);
    responseObserver.onCompleted();
  }
}
