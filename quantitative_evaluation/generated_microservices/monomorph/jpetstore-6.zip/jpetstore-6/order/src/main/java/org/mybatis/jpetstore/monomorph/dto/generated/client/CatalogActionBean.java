/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.List;
import java.util.stream.Collectors;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.catalogactionbean.*;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.category.CategoryDTO;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.product.ProductDTO;
import org.mybatis.jpetstore.monomorph.id.generated.client.CatalogService;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.IDMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry.ServiceEndpoint;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for {@code org.mybatis.jpetstore.web.actions.CatalogActionBean} and
 * {@link CatalogActionBeanDTO}. This client uses composition to wrap the DTO and provides the same public API as the
 * original class. Business logic methods are delegated to a remote gRPC service.
 */
public class CatalogActionBean extends AbstractRefactoredClient {
  private static final String TARGET_SERVICE_ID = "CatalogActionBeanService";
  private transient CatalogActionBeanServiceGrpc.CatalogActionBeanServiceBlockingStub stub;
  private CatalogActionBeanDTO dtoInstance;

  /**
   * Default constructor. Initializes with an empty DTO.
   */
  public CatalogActionBean() {
    super();
    initialize(TARGET_SERVICE_ID);
    this.dtoInstance = CatalogActionBeanDTO.newBuilder().build();
  }

  /**
   * Constructor to initialize from a DTO instance.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  public CatalogActionBean(CatalogActionBeanDTO dtoInstance) {
    super();
    initialize(TARGET_SERVICE_ID);
    this.dtoInstance = dtoInstance;
  }

  /**
   * Constructor to initialize from a RefactoredObjectID.
   *
   * @param objectId
   *          The RefactoredObjectID instance.
   */
  public CatalogActionBean(RefactoredObjectID objectId) {
    super(objectId);
    this.dtoInstance = CatalogActionBeanDTO.newBuilder().build(); // Initialize with a default DTO
  }

  /**
   * Sets up the gRPC stub for communication with the remote service.
   */
  @Override
  protected void performRpcSetup() {
    try {
      if (stub == null) {
        ServiceEndpoint location = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
        ManagedChannel channel = ManagedChannelBuilder.forAddress(location.getHost(), location.getPort()).usePlaintext()
            .build();
        stub = CatalogActionBeanServiceGrpc.newBlockingStub(channel);
        super.registerChannelForCleanup(channel); // Register channel for cleanup
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to set up RPC for CatalogActionBean", e);
    }
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) {
    // For CatalogActionBean, we assume no explicit remote creation RPC is needed for its
    // instantiation. It primarily acts as a client-side DTO wrapper.
    // Therefore, we generate a new RefactoredObjectID locally.
    this.dtoInstance = CatalogActionBeanDTO.newBuilder().build();
    return RefactoredObjectID.newBuilder().setInstanceID(clientId).build(); // Generate a new ID for this client
                                                                            // instance
  }

  @Override
  protected void performSubclassRpcCleanup() {
    // No specific cleanup needed for this subclass beyond what AbstractRefactoredClient handles.
    // The ManagedChannel is managed by the parent class's cleanup mechanism.
  }

  // mapping methods
  public CatalogActionBeanDTO toDTO() {
    return this.dtoInstance;
  }

  public static CatalogActionBean fromDTO(CatalogActionBeanDTO dtoInstance) {
    return new CatalogActionBean(dtoInstance);
  }

  // The fromID method is already provided by AbstractRefactoredClient, so we remove the duplicate here.
  // public static CatalogActionBean fromID(RefactoredObjectID id) {
  // return new CatalogActionBean(id);
  // }

  // implementation of the gRPC exposed methods

  /**
   * Delegates to the remote gRPC service to view a category. The client's state is updated with the result from the
   * service.
   */
  public void viewCategory() { // Removed throws Exception
    try {
      ensureNotClosed();
      performRpcSetup();
      ViewCategoryRequest request = ViewCategoryRequest.newBuilder().setCategoryId(this.dtoInstance.getCategoryId())
          .build();
      ViewCategoryResponse response = stub.viewCategory(request);
      this.dtoInstance = this.dtoInstance.toBuilder().setCategory(response.getCategory())
          .addAllProductList(response.getProductListList()).build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to view category", e);
    }
  }

  /**
   * Delegates to the remote gRPC service to view a product. The client's state is updated with the result from the
   * service.
   */
  public void viewProduct() { // Removed throws Exception
    try {
      ensureNotClosed();
      performRpcSetup();
      ViewProductRequest request = ViewProductRequest.newBuilder().setProductId(this.dtoInstance.getProductId())
          .build();
      ViewProductResponse response = stub.viewProduct(request);
      this.dtoInstance = this.dtoInstance.toBuilder().setProduct(response.getProduct())
          .addAllItemList(response.getItemListList()).build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to view product", e);
    }
  }

  /**
   * Delegates to the remote gRPC service to view an item. The client's state is updated with the result from the
   * service.
   */
  public void viewItem() { // Removed throws Exception
    try {
      ensureNotClosed();
      performRpcSetup();
      ViewItemRequest request = ViewItemRequest.newBuilder().setItemId(this.dtoInstance.getItemId()).build();
      ViewItemResponse response = stub.viewItem(request);
      this.dtoInstance = this.dtoInstance.toBuilder().setItem(response.getItem()).build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to view item", e);
    }
  }

  /**
   * Delegates to the remote gRPC service to search for products. The client's state is updated with the result from the
   * service.
   */
  public void searchProducts() { // Removed throws Exception
    try {
      ensureNotClosed();
      performRpcSetup();
      SearchProductsRequest request = SearchProductsRequest.newBuilder().setKeyword(this.dtoInstance.getKeyword())
          .build();
      SearchProductsResponse response = stub.searchProducts(request);
      this.dtoInstance = this.dtoInstance.toBuilder().addAllProductList(response.getProductListList()).build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to search products", e);
    }
  }

  /**
   * Clears the state of the client.
   */
  public void clear() {
    this.dtoInstance = CatalogActionBeanDTO.newBuilder().build();
  }

  // --- START OF DTO GETTERS AND SETTERS ---

  public String getKeyword() {
    return dtoInstance.getKeyword();
  }

  public void setKeyword(String keyword) {
    this.dtoInstance = dtoInstance.toBuilder().setKeyword(keyword).build();
  }

  public String getCategoryId() {
    return dtoInstance.getCategoryId();
  }

  public void setCategoryId(String categoryId) {
    this.dtoInstance = dtoInstance.toBuilder().setCategoryId(categoryId).build();
  }

  public String getProductId() {
    return dtoInstance.getProductId();
  }

  public void setProductId(String productId) {
    this.dtoInstance = dtoInstance.toBuilder().setProductId(productId).build();
  }

  public String getItemId() {
    return dtoInstance.getItemId();
  }

  public void setItemId(String itemId) {
    this.dtoInstance = dtoInstance.toBuilder().setItemId(itemId).build();
  }

  public Category getCategory() {
    if (!dtoInstance.hasCategory()) {
      return null;
    }
    return Category.fromDTO(dtoInstance.getCategory());
  }

  public void setCategory(Category category) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (category == null) {
      builder.clearCategory();
    } else {
      builder.setCategory(category.toDTO());
    }
    this.dtoInstance = builder.build();
  }

  public Product getProduct() {
    if (!dtoInstance.hasProduct()) {
      return null;
    }
    return Product.fromDTO(dtoInstance.getProduct());
  }

  public void setProduct(Product product) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (product == null) {
      builder.clearProduct();
    } else {
      builder.setProduct(product.toDTO());
    }
    this.dtoInstance = builder.build();
  }

  public Item getItem() {
    if (!dtoInstance.hasItem()) {
      return null;
    }
    return Item.fromDTO(dtoInstance.getItem());
  }

  public void setItem(Item item) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (item == null) {
      builder.clearItem();
    } else {
      builder.setItem(item.toDTO());
    }
    this.dtoInstance = builder.build();
  }

  public List<Category> getCategoryList() {
    return dtoInstance.getCategoryListList().stream().map(Category::fromDTO).collect(Collectors.toList());
  }

  public void setCategoryList(List<Category> categoryList) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder().clearCategoryList();
    if (categoryList != null) {
      List<CategoryDTO> dtoList = categoryList.stream().map(Category::toDTO).collect(Collectors.toList());
      builder.addAllCategoryList(dtoList);
    }
    this.dtoInstance = builder.build();
  }

  public List<Product> getProductList() {
    return dtoInstance.getProductListList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }

  public void setProductList(List<Product> productList) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder().clearProductList();
    if (productList != null) {
      List<ProductDTO> dtoList = productList.stream().map(Product::toDTO).collect(Collectors.toList());
      builder.addAllProductList(dtoList);
    }
    this.dtoInstance = builder.build();
  }

  public List<Item> getItemList() {
    return dtoInstance.getItemListList().stream().map(Item::fromDTO).collect(Collectors.toList());
  }

  public void setItemList(List<Item> itemList) {
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder().clearItemList();
    if (itemList != null) {
      List<ItemDTO> dtoList = itemList.stream().map(Item::toDTO).collect(Collectors.toList());
      builder.addAllItemList(dtoList);
    }
    this.dtoInstance = builder.build();
  }

  public CatalogService getCatalogService() { // Removed throws Exception
    if (!dtoInstance.hasCatalogService()) {
      return null;
    }
    try {
      return (CatalogService) IDMapper.fromID(dtoInstance.getCatalogService());
    } catch (Exception e) {
      throw new RuntimeException("Failed to get CatalogService", e);
    }
  }

  public void setCatalogService(CatalogService catalogService) { // Removed throws Exception
    CatalogActionBeanDTO.Builder builder = dtoInstance.toBuilder();
    if (catalogService == null) {
      builder.clearCatalogService();
    } else {
      try {
        builder.setCatalogService(IDMapper.toID(catalogService));
      } catch (Exception e) {
        throw new RuntimeException("Failed to set CatalogService", e);
      }
    }
    this.dtoInstance = builder.build();
  }

  // --- END OF DTO GETTERS AND SETTERS ---

  @Override
  public RefactoredObjectID toID() {
    // Assuming a unique identifier for CatalogActionBean is not directly available in the DTO,
    // we'll use a placeholder or a combination of relevant fields if available.
    // For now, returning a fixed ID for singleton-like behavior or a generated one.
    // If there's a natural key, it should be used here.
    return RefactoredObjectID.newBuilder()
        .setClassId(ClassIdRegistry.getClassId(CatalogActionBean.class.getSimpleName())) // Changed setRefactoredClassId
                                                                                         // to setClassId
        .setInstanceID("singleton").build();
  }

  // The fromID method is already provided by AbstractRefactoredClient, so we remove the duplicate here.
  // public static CatalogActionBean fromID(RefactoredObjectID id) {
  // // In a real scenario, this would involve an RPC call to retrieve the CatalogActionBean by its ID.
  // // For now, we'll create a dummy CatalogActionBean.
  // return new CatalogActionBean(id);
  // }
}
