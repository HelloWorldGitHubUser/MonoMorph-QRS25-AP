/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.mybatis.jpetstore.monomorph.dto.generated.client.Item;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.proto.itemmapper.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * gRPC Client for the ItemMapper service. This class acts as a proxy, forwarding method calls to a remote microservice.
 */
public class ItemMapper extends AbstractRefactoredClient {

  // TARGET_SERVICE_ID is the unique ID for the ItemMapper service, provided by the tool
  private static final String TARGET_SERVICE_ID = "catalog";

  // --- gRPC Specific Fields ---
  private ManagedChannel businessChannel; // Channel for RPC calls
  private ItemMapperServiceGrpc.ItemMapperServiceBlockingStub businessStub; // Use this stub for RPC calls

  /**
   * Default constructor for client-side instantiation. Initializes the remote object.
   */
  public ItemMapper() {
    // MAKE SURE TO CALL THIS INITIALIZATION METHOD FROM THE PARENT (void initialize(Object... args))
    initialize();
  }

  /** Private constructor used by the fromID factory. */
  private ItemMapper(RefactoredObjectID existingId) {
    super(existingId); // Use the base constructor for existing IDs
  }

  // --- Implementation of Abstract Methods ---

  @Override
  protected void performRpcSetup() throws Exception {
    // Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
    ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
        .build();
    this.businessStub = ItemMapperServiceGrpc.newBlockingStub(this.businessChannel);
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    performRpcSetup();
    // Start of logic for creating the RPC "createObject" request
    // The original ItemMapper is an interface, so it has no constructor arguments.
    ConstructorArgs constructorArgs = ConstructorArgs.newBuilder().build();

    CreateObjectRequest createRequest = CreateObjectRequest.newBuilder().setClientID(clientId)
        .setConstructorArgs(constructorArgs).build();
    // End of logic for creating the RPC "createObject" request

    return this.businessStub.createObject(createRequest);
  }

  @Override
  protected void performSubclassRpcCleanup() {
    // shutdown logic for businessChannel
    if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
      try {
        this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        if (!this.businessChannel.isTerminated()) {
          this.businessChannel.shutdownNow();
        }
      } catch (InterruptedException e) {
        // Propagate interruption
        Thread.currentThread().interrupt();
      }
    }
  }

  /** Factory method for creating proxy from an EXISTING ID. */
  public static ItemMapper fromID(RefactoredObjectID existingId) {
    return new ItemMapper(existingId);
  }

  // --- Start of the implementation of the rest of the Service Methods ---

  public void updateInventoryQuantity(java.util.Map<java.lang.String, java.lang.Object> param) {
    // The proto message uses "item_id" and "quantity". We assume the map keys match the proto contract.
    // The original code used "itemId" and "increment". This client follows the gRPC contract.
    String itemId = (String) param.get("item_id");
    Integer quantity = (Integer) param.get("quantity");

    UpdateInventoryQuantityRequest request = UpdateInventoryQuantityRequest.newBuilder().setObjectId(this.objectId)
        .setItemId(itemId).setQuantity(quantity).build();
    this.businessStub.updateInventoryQuantity(request);
  }

  public int getInventoryQuantity(java.lang.String itemId) {
    GetInventoryQuantityRequest request = GetInventoryQuantityRequest.newBuilder().setObjectId(this.objectId)
        .setItemId(itemId).build();
    GetInventoryQuantityResponse response = this.businessStub.getInventoryQuantity(request);
    return response.getQuantity();
  }

  public Item getItem(java.lang.String itemId) {
    GetItemRequest request = GetItemRequest.newBuilder().setObjectId(this.objectId).setItemId(itemId).build();
    GetItemResponse response = this.businessStub.getItem(request);

    if (!response.hasItem()) {
      return null;
    }
    // Convert from proto DTO to client-side proxy object
    return Item.fromDTO(response.getItem());
  }

  // --- End of the implementation of the rest of the Service Methods ---

}
