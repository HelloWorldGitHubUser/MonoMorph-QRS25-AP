/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.mybatis.jpetstore.monomorph.dto.generated.client.Product;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.IDMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.proto.catalogservice.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * gRPC Client implementation for the CatalogService. This class acts as a proxy, forwarding method calls to a remote
 * microservice via gRPC. It maintains the public API of the original class for backward compatibility.
 */
public class CatalogService extends AbstractRefactoredClient {

  // TARGET_SERVICE_ID is the unique ID for the CatalogService service, used for service discovery.
  private static final String TARGET_SERVICE_ID = "catalog";

  // --- gRPC Specific Fields ---
  private ManagedChannel businessChannel; // Channel for RPC calls
  private CatalogServiceServiceGrpc.CatalogServiceServiceBlockingStub businessStub; // Stub for making blocking RPC
                                                                                    // calls

  /**
   * Public constructor with an API identical to the original class. It initializes the client proxy, which will create
   * a remote object instance on the first call.
   *
   * @param categoryMapper
   *          A proxy for the CategoryMapper dependency.
   * @param itemMapper
   *          A proxy for the ItemMapper dependency.
   * @param productMapper
   *          A proxy for the ProductMapper dependency.
   */
  public CatalogService(org.mybatis.jpetstore.monomorph.dto.generated.client.CategoryMapper categoryMapper,
      org.mybatis.jpetstore.monomorph.id.generated.client.ItemMapper itemMapper,
      org.mybatis.jpetstore.monomorph.dto.generated.client.ProductMapper productMapper) {
    // This method from the parent class triggers the remote object creation process.
    initialize(categoryMapper, itemMapper, productMapper);
  }

  /**
   * Private constructor used by the fromID factory method. This allows creating a client proxy for an already existing
   * remote object.
   *
   * @param existingId
   *          The ID of the existing remote object.
   */
  private CatalogService(RefactoredObjectID existingId) {
    super(existingId); // Use the base constructor for existing IDs
  }

  // --- Implementation of Abstract Methods ---

  @Override
  protected void performRpcSetup() throws Exception {
    // Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
    ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
        .build();
    this.businessStub = CatalogServiceServiceGrpc.newBlockingStub(businessChannel);
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    performRpcSetup();

    // Cast constructor arguments to their expected proxy types
    org.mybatis.jpetstore.monomorph.dto.generated.client.CategoryMapper categoryMapper = (org.mybatis.jpetstore.monomorph.dto.generated.client.CategoryMapper) args[0];
    org.mybatis.jpetstore.monomorph.id.generated.client.ItemMapper itemMapper = (org.mybatis.jpetstore.monomorph.id.generated.client.ItemMapper) args[1];
    org.mybatis.jpetstore.monomorph.dto.generated.client.ProductMapper productMapper = (org.mybatis.jpetstore.monomorph.dto.generated.client.ProductMapper) args[2];

    // Map proxy objects to their corresponding Protobuf messages (DTOs or IDs)
    ConstructorArgs constructorArgs = ConstructorArgs.newBuilder().setCategoryMapper(categoryMapper.toDTO())
        .setItemMapper(IDMapper.toID(itemMapper)).setProductMapper(productMapper.toDTO()).build();

    // Build the gRPC request for creating a remote object
    CreateObjectRequest createRequest = CreateObjectRequest.newBuilder().setClientID(clientId)
        .setConstructorArgs(constructorArgs).build();

    // Execute the remote call and return the ID of the newly created object
    return this.businessStub.createObject(createRequest);
  }

  @Override
  protected void performSubclassRpcCleanup() {
    // Gracefully shut down the gRPC channel
    if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
      try {
        this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        if (!this.businessChannel.isTerminated()) {
          this.businessChannel.shutdownNow();
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }

  /**
   * Factory method for creating a client proxy from an existing remote object ID.
   *
   * @param existingId
   *          The ID of the remote object.
   *
   * @return A new CatalogService client instance pointing to the existing remote object.
   */
  public static CatalogService fromID(RefactoredObjectID existingId) {
    return new CatalogService(existingId);
  }

  // --- Implementation of Service Methods from Proto ---

  /**
   * Retrieves a list of products belonging to a specific category by making a remote gRPC call.
   *
   * @param categoryId
   *          The ID of the category.
   *
   * @return A list of Product proxy objects.
   */
  public List<Product> getProductListByCategory(java.lang.String categoryId) {
    // Build the gRPC request message
    GetProductListByCategoryRequest request = GetProductListByCategoryRequest.newBuilder().setObjectId(this.objectId) // ID
                                                                                                                      // of
                                                                                                                      // the
                                                                                                                      // remote
                                                                                                                      // CatalogService
                                                                                                                      // instance
        .setCategoryId(categoryId).build();

    // Execute the remote call
    GetProductListByCategoryResponse response = this.businessStub.getProductListByCategory(request);

    // Map the list of ProductDTOs from the response back to a list of client-side Product proxy objects
    return response.getProductsList().stream().map(Product::fromDTO).collect(Collectors.toList());
  }
}
