/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.category.*;

/**
 * Auto-generated DTO gRPC client for {@link org.mybatis.jpetstore.domain.Category}. This class uses composition to hold
 * a CategoryDTO instance and exposes the same public API as the original class.
 */
public class Category {
  private CategoryDTO dtoInstance;

  /**
   * Default constructor. Initializes with an empty DTO.
   */
  public Category() {
    this.dtoInstance = CategoryDTO.newBuilder().build();
  }

  /**
   * Private constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  private Category(CategoryDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
  }

  /**
   * Returns the internal DTO instance.
   *
   * @return The CategoryDTO object.
   */
  public CategoryDTO toDTO() {
    return this.dtoInstance;
  }

  /**
   * Creates a new Category client instance from a DTO.
   *
   * @param dtoInstance
   *          The DTO instance.
   *
   * @return A new Category client instance.
   */
  public static Category fromDTO(CategoryDTO dtoInstance) {
    return new Category(dtoInstance);
  }

  // implementation of the gRPC exposed methods
  // No service methods were defined in the proto file.

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---

  public java.lang.String getCategoryId() {
    return dtoInstance.getCategoryId();
  }

  public void setCategoryId(java.lang.String categoryId) {
    CategoryDTO.Builder builder = dtoInstance.toBuilder();
    if (categoryId != null) {
      builder.setCategoryId(categoryId.trim());
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getName() {
    return dtoInstance.getName();
  }

  public void setName(java.lang.String name) {
    CategoryDTO.Builder builder = dtoInstance.toBuilder();
    if (name != null) {
      builder.setName(name);
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getDescription() {
    return dtoInstance.getDescription();
  }

  public void setDescription(java.lang.String description) {
    CategoryDTO.Builder builder = dtoInstance.toBuilder();
    if (description != null) {
      builder.setDescription(description);
    }
    this.dtoInstance = builder.build();
  }

  public long getSerialVersionUID() {
    return dtoInstance.getSerialVersionUID();
  }

  public void setSerialVersionUID(long serialVersionUID) {
    CategoryDTO.Builder builder = dtoInstance.toBuilder();
    builder.setSerialVersionUID(serialVersionUID);
    this.dtoInstance = builder.build();
  }

  // --- END OF DTO GETTERS AND SETTERS ---

  @java.lang.Override
  public java.lang.String toString() {
    return getCategoryId();
  }
}