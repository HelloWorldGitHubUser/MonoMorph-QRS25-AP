/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.concurrent.TimeUnit;

// DTO Proxy imports
import org.mybatis.jpetstore.monomorph.dto.generated.client.Account;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
// gRPC imports
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.AccountActionBeanServiceGrpc;
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.ConstructorArgs;
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.CreateObjectRequest;
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.GetAccountRequest;
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.GetAccountResponse;
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.IsAuthenticatedRequest;
import org.mybatis.jpetstore.monomorph.id.generated.proto.accountactionbean.IsAuthenticatedResponse;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * gRPC Client for the AccountActionBean class. This class acts as a proxy, forwarding method calls to a remote gRPC
 * service.
 */
public class AccountActionBean extends AbstractRefactoredClient {

  // TARGET_SERVICE_ID is the unique ID for the AccountActionBean service.
  private static final String TARGET_SERVICE_ID = "account";

  // --- gRPC Specific Fields ---
  private ManagedChannel businessChannel; // Channel for RPC calls
  private AccountActionBeanServiceGrpc.AccountActionBeanServiceBlockingStub businessStub; // Use this stub for RPC calls

  /**
   * Default constructor. Initializes a new remote instance.
   */
  public AccountActionBean() {
    // The parent initialize method triggers the remote object creation.
    initialize();
  }

  /**
   * Private constructor used by the fromID factory to wrap an existing remote instance.
   */
  private AccountActionBean(RefactoredObjectID existingId) {
    super(existingId); // Use the base constructor for existing IDs
  }

  // --- Implementation of Abstract Methods ---

  @Override
  protected void performRpcSetup() throws Exception {
    // Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
    ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
        .build();
    this.businessStub = AccountActionBeanServiceGrpc.newBlockingStub(businessChannel);
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) throws Exception {
    performRpcSetup();

    // Build request for the default constructor
    ConstructorArgs constructorArgs = ConstructorArgs.newBuilder().build();
    CreateObjectRequest createRequest = CreateObjectRequest.newBuilder().setClientID(clientId)
        .setConstructorArgs(constructorArgs).build();

    RefactoredObjectID createResponseProto = this.businessStub.createObject(createRequest);

    return createResponseProto;
  }

  @Override
  protected void performSubclassRpcCleanup() {
    if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
      try {
        this.businessChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        if (!this.businessChannel.isTerminated()) {
          this.businessChannel.shutdownNow();
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }

  /**
   * Factory method for creating a proxy from an EXISTING ID.
   */
  public static AccountActionBean fromID(RefactoredObjectID existingId) {
    return new AccountActionBean(existingId);
  }

  // --- Start of the implementation of the rest of the Service Methods ---

  /**
   * Retrieves the account information from the remote service. Corresponds to the getAccount() method.
   *
   * @return The Account object proxy.
   */
  public Account getAccount() {
    ensureNotClosed();
    GetAccountRequest request = GetAccountRequest.newBuilder().setObjectId(this.objectId).build();
    GetAccountResponse response = this.businessStub.getAccount(request);
    // Convert the DTO from the response to the client-side proxy object
    return Account.fromDTO(response.getAccount());
  }

  /**
   * Checks if the user is authenticated on the remote service. Corresponds to the isAuthenticated() method.
   *
   * @return true if authenticated, false otherwise.
   */
  public boolean isAuthenticated() {
    ensureNotClosed();
    IsAuthenticatedRequest request = IsAuthenticatedRequest.newBuilder().setObjectId(this.objectId).build();
    IsAuthenticatedResponse response = this.businessStub.isAuthenticated(request);
    return response.getAuthenticated();
  }

  // --- End of the implementation of the rest of the Service Methods ---

}
