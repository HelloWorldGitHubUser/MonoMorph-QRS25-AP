/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

// Java standard library imports
import java.util.List;
import java.util.stream.Collectors;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.category.CategoryDTO; // Corrected import for CategoryDTO
import org.mybatis.jpetstore.monomorph.dto.generated.proto.categorymapper.*;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry.ServiceEndpoint;

/**
 * Auto-generated DTO gRPC client for the CategoryMapper service. This class provides the same public API as the
 * original CategoryMapper interface but delegates calls to a remote gRPC service. It uses composition to wrap a
 * {@link CategoryMapperDTO}.
 */
public class CategoryMapper {

  private static final String TARGET_SERVICE_ID = "category-mapper-service";

  private final CategoryMapperDTO dtoInstance;
  private final ManagedChannel channel;
  private final CategoryMapperServiceGrpc.CategoryMapperServiceBlockingStub blockingStub;

  /**
   * Default constructor. Initializes the gRPC client and channel.
   */
  public CategoryMapper() {
    this.dtoInstance = CategoryMapperDTO.newBuilder().build();
    ServiceEndpoint location = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.channel = ManagedChannelBuilder.forAddress(location.getHost(), location.getPort()).usePlaintext().build();
    this.blockingStub = CategoryMapperServiceGrpc.newBlockingStub(channel);
  }

  /**
   * Private constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  private CategoryMapper(CategoryMapperDTO dtoInstance) {
    this.dtoInstance = dtoInstance;
    ServiceEndpoint location = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.channel = ManagedChannelBuilder.forAddress(location.getHost(), location.getPort()).usePlaintext().build();
    this.blockingStub = CategoryMapperServiceGrpc.newBlockingStub(channel);
  }

  // mapping methods
  public CategoryMapperDTO toDTO() {
    return this.dtoInstance;
  }

  public static CategoryMapper fromDTO(CategoryMapperDTO dtoInstance) {
    return new CategoryMapper(dtoInstance);
  }

  // implementation of the gRPC exposed methods

  /**
   * Retrieves a list of all categories by making a gRPC call. This method corresponds to the original
   * CategoryMapper#getCategoryList().
   *
   * @return A list of {@link Category} objects.
   */
  public List<Category> getCategoryList() {
    GetCategoryListRequest request = GetCategoryListRequest.newBuilder().build(); // Changed from Empty to
                                                                                  // GetCategoryListRequest
    GetCategoryListResponse response = blockingStub.getCategoryList(request);
    // Assumes the client-side domain.Category has a fromDto static factory method
    // that accepts a proto-generated Category DTO.
    return response.getCategoriesList().stream().map(Category::fromDTO).collect(Collectors.toList());
  }

  /**
   * Retrieves a single category by its ID by making a gRPC call. This method corresponds to the original
   * CategoryMapper#getCategory(String).
   *
   * @param categoryId
   *          The ID of the category to retrieve.
   *
   * @return The {@link Category} object corresponding to the given ID, or null if not found.
   */
  public Category getCategory(String categoryId) {
    GetCategoryRequest request = GetCategoryRequest.newBuilder().setCategoryId(categoryId).build();
    // The gRPC service returns a proto Category DTO
    CategoryDTO categoryDto = blockingStub.getCategory(request); // Removed fully qualified name as import is added

    if (categoryDto == null || categoryDto.getCategoryId().isEmpty()) {
      return null;
    }

    // Assumes the client-side domain.Category has a fromDto static factory method
    return Category.fromDTO(categoryDto);
  }

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---
  // CategoryMapperDTO is empty, so there are no getters or setters to implement.
  // --- END OF DTO GETTERS AND SETTERS ---
}
