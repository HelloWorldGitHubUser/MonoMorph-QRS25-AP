/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.generated.server;

import com.google.protobuf.Empty;

import io.grpc.stub.StreamObserver;

import java.util.Objects;
import java.util.UUID;

import org.mybatis.jpetstore.domain.Cart;
import org.mybatis.jpetstore.monomorph.dto.generated.client.Item;
import org.mybatis.jpetstore.monomorph.dto.generated.server.CartItemMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.generated.proto.cart.*;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.server.LeaseManager;
import org.mybatis.jpetstore.monomorph.id.shared.server.ServerObjectManager;

/**
 * gRPC Service implementation for Cart. - Handles gRPC requests for Cart API. - Creates transient Cart instances. -
 * Interacts with LeaseManager for instance registration/retrieval. - Calls business methods on retrieved Cart
 * instances.
 */
public class CartImpl extends CartServiceGrpc.CartServiceImplBase implements ServerObjectManager {

  private final LeaseManager leaseManager;
  private final String serviceId = ServiceRegistry.getServiceId();

  // Static identifier for the class type managed by this service
  public static final String CLASS_ID = ClassIdRegistry.getClassId("Cart");

  public CartImpl(LeaseManager leaseManager) {
    this.leaseManager = Objects.requireNonNull(leaseManager);
  }

  // --- createObject gRPC Method Implementation ---

  @Override
  public void createObject(CreateObjectRequest request, StreamObserver<RefactoredObjectID> responseObserver) {
    try {
      // 1. Extract args & client ID
      String clientId = request.getClientID();
      // Constructor for Cart takes no arguments.
      // ConstructorArgs is empty as defined in the proto.

      // 2. *** Create the transient instance DIRECTLY ***
      Cart newInstance = new Cart();

      // 3- Generate a RefactoredObjectID ID
      RefactoredObjectID responseProto = toID(newInstance, clientId);
      // 4. Send the response
      responseObserver.onNext(responseProto);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  // --- Start of ServerObjectManager method implementations ---
  @Override
  public RefactoredObjectID toID(Object instance, String clientId) throws Exception {
    // Validate if id instance exists
    String instanceId = leaseManager.findInstanceIdForInstance(instance);
    if (instanceId == null) {
      // Generate a new unique instance ID
      instanceId = UUID.randomUUID().toString();
    }
    // Register with LeaseManager
    boolean registered = leaseManager.registerInstanceAndGrantLease(instanceId, CLASS_ID, instance, clientId);
    if (!registered) {
      throw new RuntimeException("Failed to register new instance ID: " + instanceId);
    }
    // Build RefactoredObjectID
    return RefactoredObjectID.newBuilder().setInstanceID(instanceId).setClassID(CLASS_ID).setServiceID(this.serviceId)
        .build();
  }

  @Override
  public RefactoredObjectID toID(Object instance) throws Exception {
    return toID(instance, serviceId);
  }

  @Override
  public Cart fromID(RefactoredObjectID id) throws Exception {
    // Validate the class ID
    if (id.getClassID() == null || !id.getClassID().equals(CLASS_ID)) {
      throw new IllegalArgumentException("class ID mismatch: expected " + CLASS_ID + ", got " + id.getClassID());
    }
    // Retrieve the instance from LeaseManager
    // Note: The LeaseManager.getInstance() method should return the correct type based on the class ID
    Cart instance = (Cart) leaseManager.getInstance(id.getInstanceID());
    if (instance == null) {
      throw new IllegalArgumentException("No instance found for ID: " + id);
    }
    return instance;
  }

  @Override
  public String getManagedClassId() {
    return CLASS_ID;
  }

  @Override
  public String getServiceId() {
    return serviceId;
  }
  // --- End of ServerObjectManager method implementations ---

  // --- Other gRPC methods defined in the proto file ---

  @Override
  public void addItem(AddItemRequest request, StreamObserver<Empty> responseObserver) {
    try {
      Cart instance = fromID(request.getObjectId());
      Item item = Item.fromDTO(request.getItem());
      boolean isInStock = request.getIsInStock();
      instance.addItem(item, isInStock);
      responseObserver.onNext(Empty.newBuilder().build());
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void containsItemId(ContainsItemIdRequest request, StreamObserver<ContainsItemIdResponse> responseObserver) {
    try {
      Cart instance = fromID(request.getObjectId());
      boolean result = instance.containsItemId(request.getItemId());
      ContainsItemIdResponse response = ContainsItemIdResponse.newBuilder().setResult(result).build();
      responseObserver.onNext(response);
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void getAllCartItems(GetAllCartItemsRequest request,
      StreamObserver<GetAllCartItemsResponse> responseObserver) {
    try {
      Cart instance = fromID(request.getObjectId());
      java.util.Iterator<org.mybatis.jpetstore.domain.CartItem> cartItemsIterator = instance.getAllCartItems();
      GetAllCartItemsResponse.Builder responseBuilder = GetAllCartItemsResponse.newBuilder();
      cartItemsIterator.forEachRemaining(cartItem -> responseBuilder.addItems(CartItemMapper.INSTANCE.toDTO(cartItem)));
      responseObserver.onNext(responseBuilder.build());
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void incrementQuantityByItemId(IncrementQuantityByItemIdRequest request,
      StreamObserver<Empty> responseObserver) {
    try {
      Cart instance = fromID(request.getObjectId());
      instance.incrementQuantityByItemId(request.getItemId());
      responseObserver.onNext(Empty.newBuilder().build());
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void removeItemById(RemoveItemByIdRequest request, StreamObserver<RemoveItemByIdResponse> responseObserver) {
    try {
      Cart instance = fromID(request.getObjectId());
      org.mybatis.jpetstore.domain.Item removedItem = instance.removeItemById(request.getItemId());
      RemoveItemByIdResponse.Builder responseBuilder = RemoveItemByIdResponse.newBuilder();
      if (removedItem != null) {
        // The item stored in the cart is a proxy object that can be converted to a DTO.
        Item itemProxy = (Item) removedItem;
        responseBuilder.setItem(itemProxy.toDTO());
      }
      responseObserver.onNext(responseBuilder.build());
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }

  @Override
  public void setQuantityByItemId(SetQuantityByItemIdRequest request, StreamObserver<Empty> responseObserver) {
    try {
      Cart instance = fromID(request.getObjectId());
      instance.setQuantityByItemId(request.getItemId(), request.getQuantity());
      responseObserver.onNext(Empty.newBuilder().build());
      responseObserver.onCompleted();
    } catch (Exception e) {
      responseObserver.onError(e);
    }
  }
}
