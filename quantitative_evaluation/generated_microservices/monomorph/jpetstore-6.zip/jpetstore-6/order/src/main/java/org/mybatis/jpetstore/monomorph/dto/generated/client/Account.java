/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.account.*;

/**
 * Auto-generated DTO gRPC client {@link Account} and {@link AccountDTO}.
 */
public class Account {
  private AccountDTO dtoInstance;

  public Account(AccountDTO dtoInstance) {
    // dtoConstructor to initialize from a DTO instance
    this.dtoInstance = dtoInstance;
  }

  // add any additional constructors if needed
  public Account() {
    this.dtoInstance = AccountDTO.newBuilder().build();
  }

  // mapping methods
  public AccountDTO toDTO() {
    return this.dtoInstance;
  }

  public static Account fromDTO(AccountDTO dtoInstance) {
    return new Account(dtoInstance);
  }

  // implementation of the gRPC exposed methods

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---
  public java.lang.String getUsername() {
    return dtoInstance.getUsername();
  }

  public void setUsername(java.lang.String username) {
    this.dtoInstance = this.dtoInstance.toBuilder().setUsername(username).build();
  }

  public java.lang.String getPassword() {
    return dtoInstance.getPassword();
  }

  public void setPassword(java.lang.String password) {
    this.dtoInstance = this.dtoInstance.toBuilder().setPassword(password).build();
  }

  public java.lang.String getEmail() {
    return dtoInstance.getEmail();
  }

  public void setEmail(java.lang.String email) {
    this.dtoInstance = this.dtoInstance.toBuilder().setEmail(email).build();
  }

  public java.lang.String getFirstName() {
    return dtoInstance.getFirstName();
  }

  public void setFirstName(java.lang.String firstName) {
    this.dtoInstance = this.dtoInstance.toBuilder().setFirstName(firstName).build();
  }

  public java.lang.String getLastName() {
    return dtoInstance.getLastName();
  }

  public void setLastName(java.lang.String lastName) {
    this.dtoInstance = this.dtoInstance.toBuilder().setLastName(lastName).build();
  }

  public java.lang.String getStatus() {
    return dtoInstance.getStatus();
  }

  public void setStatus(java.lang.String status) {
    this.dtoInstance = this.dtoInstance.toBuilder().setStatus(status).build();
  }

  public java.lang.String getAddress1() {
    return dtoInstance.getAddress1();
  }

  public void setAddress1(java.lang.String address1) {
    this.dtoInstance = this.dtoInstance.toBuilder().setAddress1(address1).build();
  }

  public java.lang.String getAddress2() {
    return dtoInstance.getAddress2();
  }

  public void setAddress2(java.lang.String address2) {
    this.dtoInstance = this.dtoInstance.toBuilder().setAddress2(address2).build();
  }

  public java.lang.String getCity() {
    return dtoInstance.getCity();
  }

  public void setCity(java.lang.String city) {
    this.dtoInstance = this.dtoInstance.toBuilder().setCity(city).build();
  }

  public java.lang.String getState() {
    return dtoInstance.getState();
  }

  public void setState(java.lang.String state) {
    this.dtoInstance = this.dtoInstance.toBuilder().setState(state).build();
  }

  public java.lang.String getZip() {
    return dtoInstance.getZip();
  }

  public void setZip(java.lang.String zip) {
    this.dtoInstance = this.dtoInstance.toBuilder().setZip(zip).build();
  }

  public java.lang.String getCountry() {
    return dtoInstance.getCountry();
  }

  public void setCountry(java.lang.String country) {
    this.dtoInstance = this.dtoInstance.toBuilder().setCountry(country).build();
  }

  public java.lang.String getPhone() {
    return dtoInstance.getPhone();
  }

  public void setPhone(java.lang.String phone) {
    this.dtoInstance = this.dtoInstance.toBuilder().setPhone(phone).build();
  }

  public java.lang.String getFavouriteCategoryId() {
    return dtoInstance.getFavouriteCategoryId();
  }

  public void setFavouriteCategoryId(java.lang.String favouriteCategoryId) {
    this.dtoInstance = this.dtoInstance.toBuilder().setFavouriteCategoryId(favouriteCategoryId).build();
  }

  public java.lang.String getLanguagePreference() {
    return dtoInstance.getLanguagePreference();
  }

  public void setLanguagePreference(java.lang.String languagePreference) {
    this.dtoInstance = this.dtoInstance.toBuilder().setLanguagePreference(languagePreference).build();
  }

  public boolean isListOption() {
    return dtoInstance.getListOption();
  }

  public void setListOption(boolean listOption) {
    this.dtoInstance = this.dtoInstance.toBuilder().setListOption(listOption).build();
  }

  public boolean isBannerOption() {
    return dtoInstance.getBannerOption();
  }

  public void setBannerOption(boolean bannerOption) {
    this.dtoInstance = this.dtoInstance.toBuilder().setBannerOption(bannerOption).build();
  }

  public java.lang.String getBannerName() {
    return dtoInstance.getBannerName();
  }

  public void setBannerName(java.lang.String bannerName) {
    this.dtoInstance = this.dtoInstance.toBuilder().setBannerName(bannerName).build();
  }
  // --- END OF DTO GETTERS AND SETTERS ---
}