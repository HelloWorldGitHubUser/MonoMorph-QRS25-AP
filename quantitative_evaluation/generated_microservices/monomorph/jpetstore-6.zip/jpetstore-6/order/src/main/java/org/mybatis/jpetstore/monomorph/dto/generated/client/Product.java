/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.product.*;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ClassIdRegistry;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for the {@code Product} entity, wrapping the {@link ProductDTO}. This class provides
 * the same public API as the original {@code org.mybatis.jpetstore.domain.Product} class but uses composition to
 * delegate data storage to a DTO instance, enabling seamless microservices communication.
 */
public class Product extends AbstractRefactoredClient implements java.io.Serializable {
  private static final long serialVersionUID = -7492639752670189553L;

  private ProductDTO dtoInstance;

  /**
   * Default constructor. Initializes an empty DTO instance.
   */
  public Product() {
    this.dtoInstance = ProductDTO.newBuilder().build();
  }

  /**
   * Constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  public Product(ProductDTO dtoInstance) {
    // dtoConstructor to initialize from a DTO instance
    this.dtoInstance = dtoInstance;
  }

  // mapping methods
  public ProductDTO toDTO() {
    return this.dtoInstance;
  }

  public static Product fromDTO(ProductDTO dtoInstance) {
    return new Product(dtoInstance);
  }

  // implementation of the gRPC exposed methods
  // No RPC methods were defined in the proto service for this DTO.

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---

  public java.lang.String getProductId() {
    return this.dtoInstance.getProductId();
  }

  public void setProductId(java.lang.String productId) {
    // The original class\'s setter included a trim() operation.
    // This behavior is preserved for API compatibility.
    ProductDTO.Builder builder = this.dtoInstance.toBuilder();
    if (productId != null) {
      builder.setProductId(productId.trim());
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getCategoryId() {
    return this.dtoInstance.getCategoryId();
  }

  public void setCategoryId(java.lang.String categoryId) {
    ProductDTO.Builder builder = this.dtoInstance.toBuilder();
    if (categoryId != null) {
      builder.setCategoryId(categoryId);
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getName() {
    return this.dtoInstance.getName();
  }

  public void setName(java.lang.String name) {
    ProductDTO.Builder builder = this.dtoInstance.toBuilder();
    if (name != null) {
      builder.setName(name);
    }
    this.dtoInstance = builder.build();
  }

  public java.lang.String getDescription() {
    return this.dtoInstance.getDescription();
  }

  public void setDescription(java.lang.String description) {
    ProductDTO.Builder builder = this.dtoInstance.toBuilder();
    if (description != null) {
      builder.setDescription(description);
    }
    this.dtoInstance = builder.build();
  }

  // --- END OF DTO GETTERS AND SETTERS ---

  @java.lang.Override
  public java.lang.String toString() {
    return getName();
  }

  @Override
  public RefactoredObjectID toID() {
    // Assuming ProductId is the unique identifier for Product
    return RefactoredObjectID.newBuilder().setClassID(ClassIdRegistry.getClassId(Product.class.getSimpleName()))
        .setInstanceID(this.getProductId()).build();
  }

  public static Product fromID(RefactoredObjectID id) {
    // In a real scenario, this would involve an RPC call to retrieve the Product by its ID.
    // For now, we\'ll create a dummy Product with the ID.
    Product product = new Product();
    product.setProductId(id.getInstanceID());
    return product;
  }

  @Override
  protected void performSubclassRpcCleanup() {
    // No specific cleanup needed for Product DTO client.
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String methodName, Object... args) {
    throw new UnsupportedOperationException("Product DTO client does not support remote creation.");
  }

  @Override
  protected void performRpcSetup() {
    // No specific RPC setup needed for Product DTO client.
  }
}
