/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.id.shared.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.leasing.AcquireLeaseRequest;
import org.mybatis.jpetstore.monomorph.id.shared.leasing.AcquireLeaseResponse;
import org.mybatis.jpetstore.monomorph.id.shared.leasing.LeaseServiceGrpc;
import org.mybatis.jpetstore.monomorph.id.shared.leasing.ReleaseLeaseRequest;
import org.mybatis.jpetstore.monomorph.id.shared.leasing.ReleaseLeaseResponse;
import org.mybatis.jpetstore.monomorph.id.shared.leasing.RenewLeaseRequest;
import org.mybatis.jpetstore.monomorph.id.shared.leasing.RenewLeaseResponse;

public class GrpcLeaseRpcClient implements LeaseRpcClient {

  private final ManagedChannel channel;
  private final LeaseServiceGrpc.LeaseServiceBlockingStub blockingStub;
  private final RefactoredObjectID targetObjectId;

  public GrpcLeaseRpcClient(RefactoredObjectID targetObjectId) {
    this.targetObjectId = targetObjectId;
    // For now, assume localhost and a fixed port. In a real scenario, this would be dynamic.
    // The port should be derived from the targetObjectId or a service discovery mechanism.
    // For the purpose of this refactoring, we'll use a placeholder port.
    // TODO: Implement proper service discovery or port resolution.
    int port = 50051; // Placeholder port
    this.channel = ManagedChannelBuilder.forAddress("localhost", port).usePlaintext().build();
    this.blockingStub = LeaseServiceGrpc.newBlockingStub(channel);
  }

  @Override
  public boolean acquireLease(String clientId) {
    AcquireLeaseRequest request = AcquireLeaseRequest.newBuilder().setClientId(clientId)
        .setObjectId(targetObjectId.toProto()).build();
    try {
      AcquireLeaseResponse response = blockingStub.acquireLease(request);
      return response.getSuccess();
    } catch (Exception e) {
      System.err.println("Error acquiring lease: " + e.getMessage());
      return false;
    }
  }

  @Override
  public boolean renewLease(String clientId) {
    RenewLeaseRequest request = RenewLeaseRequest.newBuilder().setClientId(clientId)
        .setObjectId(targetObjectId.toProto()).build();
    try {
      RenewLeaseResponse response = blockingStub.renewLease(request);
      return response.getSuccess();
    } catch (Exception e) {
      System.err.println("Error renewing lease: " + e.getMessage());
      return false;
    }
  }

  @Override
  public void releaseLease(String clientId) {
    ReleaseLeaseRequest request = ReleaseLeaseRequest.newBuilder().setClientId(clientId)
        .setObjectId(targetObjectId.toProto()).build();
    try {
      ReleaseLeaseResponse response = blockingStub.releaseLease(request);
      if (!response.getSuccess()) {
        System.err.println("Failed to release lease for client " + clientId + ", object " + targetObjectId);
      }
    } catch (Exception e) {
      System.err.println("Error releasing lease: " + e.getMessage());
    }
  }

  @Override
  public void close() {
    try {
      if (!channel.isShutdown()) {
        channel.shutdown().awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS);
      }
    } catch (InterruptedException e) {
      channel.shutdownNow();
      Thread.currentThread().interrupt();
    }
  }
}
