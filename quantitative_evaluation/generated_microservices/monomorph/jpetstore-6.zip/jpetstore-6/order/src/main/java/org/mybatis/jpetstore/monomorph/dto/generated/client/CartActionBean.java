/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.List;
import java.util.stream.Collectors;

// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartactionbean.*;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.cartitem.CartItemDTO;
import org.mybatis.jpetstore.monomorph.id.generated.client.CatalogService;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.IDMapper;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for `org.mybatis.jpetstore.web.actions.CartActionBean` and {@link CartActionBeanDTO}.
 */
public class CartActionBean extends AbstractRefactoredClient {
  private CartActionBeanDTO dtoInstance;

  // TARGET_SERVICE_ID is the unique ID for the ClassA service, provided by the tool
  private static final String TARGET_SERVICE_ID = "catalog";

  private CartActionBeanServiceGrpc.CartActionBeanServiceBlockingStub businessStub; // Use this stub for RPC calls

  /**
   * Default constructor, initializes with an empty DTO. This maintains constructor compatibility with the original
   * class.
   */
  public CartActionBean() {
    super();
    initialize(TARGET_SERVICE_ID);
    this.dtoInstance = CartActionBeanDTO.newBuilder().build();
  }

  private CartActionBean(CartActionBeanDTO dtoInstance) {
    super();
    initialize(TARGET_SERVICE_ID);
    // dtoConstructor to initialize from a DTO instance
    this.dtoInstance = dtoInstance;
  }

  private CartActionBean(RefactoredObjectID objectId) {
    super(objectId);
    this.dtoInstance = CartActionBeanDTO.newBuilder().build(); // Initialize with a default DTO
  }

  // mapping methods
  public CartActionBeanDTO toDTO() {
    return this.dtoInstance;
  }

  public static CartActionBean fromDTO(CartActionBeanDTO dtoInstance) {
    return new CartActionBean(dtoInstance);
  }

  public static CartActionBean fromID(RefactoredObjectID id) {
    return new CartActionBean(id);
  }

  @Override
  protected void performRpcSetup() {
    // Use the static TARGET_SERVICE_ID to find the endpoint for business logic calls
    try {
      ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
      ManagedChannel businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort())
          .usePlaintext().build();
      this.businessStub = CartActionBeanServiceGrpc.newBlockingStub(businessChannel);
      // The channel cleanup is now handled by AbstractRefactoredClient internally.
      // No need to call registerChannelForCleanup(businessChannel);
    } catch (Exception e) {
      throw new RuntimeException("Failed to set up RPC for CartActionBean", e);
    }
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) {
    // For CartActionBean, we assume no explicit remote creation RPC is needed for its
    // instantiation. It primarily acts as a client-side DTO wrapper.
    // Therefore, we generate a new RefactoredObjectID locally.
    this.dtoInstance = CartActionBeanDTO.newBuilder().build();
    return RefactoredObjectID.newBuilder().setInstanceID(clientId).build(); // Generate a new ID for this client
                                                                            // instance
  }

  @Override
  protected void performSubclassRpcCleanup() {
    // No specific cleanup needed for this subclass beyond what AbstractRefactoredClient handles.
    // The ManagedChannel is managed by the parent class's cleanup mechanism.
  }

  // implementation of the gRPC exposed methods

  // --- START OF gRPC METHOD IMPLEMENTATIONS ---

  /**
   * Corresponds to the original clear() method. Makes a gRPC call to the CartActionBeanService to clear the cart state.
   */
  public void clear() {
    try {
      ensureNotClosed(); // Ensure the client is not closed before making RPC calls
      ClearRequest request = ClearRequest.newBuilder().setCartActionBean(this.toDTO()).build();
      ClearResponse response = this.businessStub.clear(request);
      // Update the local DTO state with the result from the service
      this.dtoInstance = response.getCartActionBean();
    } catch (Exception e) {
      throw new RuntimeException("Failed to clear cart", e);
    }
  }

  /**
   * Corresponds to the original getCart() method. Makes a gRPC call to the CartActionBeanService to retrieve the cart
   * state.
   */
  public CartActionBean getCart() {
    try {
      ensureNotClosed(); // Ensure the client is not closed before making RPC calls
      GetCartRequest request = GetCartRequest.newBuilder().setCartActionBean(this.toDTO()).build();
      GetCartResponse response = this.businessStub.getCart(request);
      // Update the local DTO state with the result from the service
      this.dtoInstance = response.getCartActionBean();
      return this; // Return the updated CartActionBean instance
    } catch (Exception e) {
      throw new RuntimeException("Failed to get cart", e);
    }
  }

  // --- END OF gRPC METHOD IMPLEMENTATIONS ---

  // Implement all other getters and setters corresponding to the DTO fields
  // --- START OF DTO GETTERS AND SETTERS ---

  public List<CartItem> getItems() {
    return this.dtoInstance.getItemsList().stream().map(CartItem::fromDTO).collect(Collectors.toList());
  }

  public void setItems(List<CartItem> items) {
    List<CartItemDTO> dtoList = items.stream().map(CartItem::toDTO).collect(Collectors.toList());
    this.dtoInstance = this.dtoInstance.toBuilder().clearItems().addAllItems(dtoList).build();
  }

  public double getSubTotal() {
    return this.dtoInstance.getSubTotal();
  }

  public String getUsername() {
    return this.dtoInstance.getUsername();
  }

  public void setUsername(String username) {
    this.dtoInstance = this.dtoInstance.toBuilder().setUsername(username == null ? "" : username).build();
  }

  public String getWorkingItemId() {
    return this.dtoInstance.getWorkingItemId();
  }

  public void setWorkingItemId(String workingItemId) {
    this.dtoInstance = this.dtoInstance.toBuilder().setWorkingItemId(workingItemId == null ? "" : workingItemId)
        .build();
  }

  public CatalogService getCatalogService() {
    if (!this.dtoInstance.hasCatalogService()) {
      return null;
    }
    return (CatalogService) IDMapper.fromID(this.dtoInstance.getCatalogService());
  }

  public void setCatalogService(CatalogService catalogService) {
    RefactoredObjectID id = IDMapper.toID(catalogService);
    this.dtoInstance = this.dtoInstance.toBuilder().setCatalogService(id).build();
  }

  // --- END OF DTO GETTERS AND SETTERS ---

}
