/*
 *    Copyright 2010-2025 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.monomorph.dto.generated.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

// Java standard library imports
import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.GetItemRequest;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.GetItemResponse;
// gRPC imports
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemDTO;
import org.mybatis.jpetstore.monomorph.dto.generated.proto.item.ItemServiceGrpc;
import org.mybatis.jpetstore.monomorph.id.generated.helpers.ServiceRegistry;
import org.mybatis.jpetstore.monomorph.id.shared.RefactoredObjectID;
import org.mybatis.jpetstore.monomorph.id.shared.client.AbstractRefactoredClient;

/**
 * Auto-generated DTO gRPC client for {@link Item} and {@link ItemDTO}. This class acts as a client-side proxy,
 * providing the same API as the original domain object while delegating data storage and manipulation to an internal
 * DTO instance.
 */
public class Item extends AbstractRefactoredClient implements java.io.Serializable {

  private static final long serialVersionUID = -2159121673445254631L;

  private transient ItemDTO dtoInstance;

  private static final String TARGET_SERVICE_ID = "catalog"; // Assuming Item is part of the catalog service
  private ItemServiceGrpc.ItemServiceBlockingStub businessStub;
  private ManagedChannel businessChannel; // Keep a reference to the channel for cleanup

  /**
   * Default constructor. Initializes an empty internal DTO.
   */
  public Item() {
    super(); // Call no-arg super constructor
    initialize(TARGET_SERVICE_ID); // Initialize with service ID
    this.dtoInstance = ItemDTO.newBuilder().build();
  }

  /**
   * Private constructor to initialize from a DTO instance. Used by the fromDTO factory method.
   *
   * @param dtoInstance
   *          The DTO instance to wrap.
   */
  private Item(ItemDTO dtoInstance) {
    super(); // Call no-arg super constructor
    initialize(TARGET_SERVICE_ID); // Initialize with service ID
    this.dtoInstance = dtoInstance;
  }

  private Item(RefactoredObjectID objectId) {
    super(objectId); // Call super constructor with objectId
    // When initialized from an ID, we need to fetch the DTO from the remote service
    try {
      performRpcSetup();
      GetItemRequest request = GetItemRequest.newBuilder().setItemId(objectId.getInstanceID()).build();
      GetItemResponse response = this.businessStub.getItem(request);
      this.dtoInstance = response.getItem();
    } catch (Exception e) {
      throw new RuntimeException("Failed to retrieve Item DTO for ID: " + objectId.getInstanceID(), e);
    } finally {
      // The channel will be closed by the cleanup mechanism in AbstractRefactoredClient
      // No direct call to performRpcCleanup() here.
    }
  }

  /**
   * Factory method to create an Item client proxy from a DTO.
   *
   * @param dtoInstance
   *          The DTO instance.
   *
   * @return A new Item instance wrapping the DTO, or null if the input is null.
   */
  public static Item fromDTO(ItemDTO dtoInstance) {
    if (dtoInstance == null) {
      return null;
    }
    return new Item(dtoInstance);
  }

  public static Item fromID(RefactoredObjectID id) {
    return new Item(id);
  }

  /**
   * Returns the internal DTO instance.
   *
   * @return The ItemDTO.
   */
  public ItemDTO toDTO() {
    return this.dtoInstance;
  }

  @Override
  protected void performRpcSetup() throws Exception {
    ServiceRegistry.ServiceEndpoint endpoint = ServiceRegistry.getEndpoint(TARGET_SERVICE_ID);
    this.businessChannel = ManagedChannelBuilder.forAddress(endpoint.getHost(), endpoint.getPort()).usePlaintext()
        .build();
    this.businessStub = ItemServiceGrpc.newBlockingStub(businessChannel);
    // registerChannelForCleanup(businessChannel); // This method is no longer available/needed
  }

  @Override
  protected RefactoredObjectID performRemoteCreateAndGetId(String clientId, Object... args) {
    // For Item, we might not have a direct "create" RPC method that returns an ID.
    // If the original class had a constructor that performed some logic, that logic would be
    // encapsulated in a remote RPC call here.
    // For now, we'll assume the default constructor behavior and return a new ID.
    // You might need to adjust this based on how Item is truly initialized remotely.
    // If there's no remote creation, this might just return a new ID and the DTO is built locally.
    this.dtoInstance = ItemDTO.newBuilder().build();
    return getObjectID(); // Return the objectId managed by AbstractRefactoredClient
  }

  @Override
  protected void performSubclassRpcCleanup() {
    if (this.businessChannel != null && !this.businessChannel.isShutdown()) {
      this.businessChannel.shutdown();
      try {
        this.businessChannel.awaitTermination(5, TimeUnit.SECONDS);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      } finally {
        if (!this.businessChannel.isTerminated()) {
          this.businessChannel.shutdownNow();
        }
      }
    }
  }

  // implementation of the gRPC exposed methods
  // No service methods were defined in the provided proto, so this section is empty.

  // --- START OF DTO GETTERS AND SETTERS ---

  public String getItemId() {
    return dtoInstance.getItemId();
  }

  public void setItemId(String itemId) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (itemId == null) {
      builder.clearItemId();
    } else {
      // Replicates original class behavior
      builder.setItemId(itemId.trim());
    }
    this.dtoInstance = builder.build();
  }

  public int getQuantity() {
    return dtoInstance.getQuantity();
  }

  public void setQuantity(int quantity) {
    this.dtoInstance = dtoInstance.toBuilder().setQuantity(quantity).build();
  }

  public Product getProduct() {
    if (!dtoInstance.hasProduct()) {
      return null;
    }
    return Product.fromDTO(dtoInstance.getProduct());
  }

  public void setProduct(Product product) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (product == null) {
      builder.clearProduct();
    } else {
      builder.setProduct(product.toDTO());
    }
    this.dtoInstance = builder.build();
  }

  public int getSupplierId() {
    return dtoInstance.getSupplierId();
  }

  public void setSupplierId(int supplierId) {
    this.dtoInstance = dtoInstance.toBuilder().setSupplierId(supplierId).build();
  }

  public BigDecimal getListPrice() {
    if (dtoInstance.getListPrice() == null || dtoInstance.getListPrice().isEmpty()) {
      return null;
    }
    return new BigDecimal(dtoInstance.getListPrice());
  }

  public void setListPrice(BigDecimal listPrice) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (listPrice == null) {
      builder.clearListPrice();
    } else {
      builder.setListPrice(listPrice.toString());
    }
    this.dtoInstance = builder.build();
  }

  public BigDecimal getUnitCost() {
    if (dtoInstance.getUnitCost() == null || dtoInstance.getUnitCost().isEmpty()) {
      return null;
    }
    return new BigDecimal(dtoInstance.getUnitCost());
  }

  public void setUnitCost(BigDecimal unitCost) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (unitCost == null) {
      builder.clearUnitCost();
    } else {
      builder.setUnitCost(unitCost.toString());
    }
    this.dtoInstance = builder.build();
  }

  public String getStatus() {
    return dtoInstance.getStatus();
  }

  public void setStatus(String status) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (status == null) {
      builder.clearStatus();
    } else {
      builder.setStatus(status);
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute1() {
    return dtoInstance.getAttribute1();
  }

  public void setAttribute1(String attribute1) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute1 == null) {
      builder.clearAttribute1();
    } else {
      builder.setAttribute1(attribute1);
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute2() {
    return dtoInstance.getAttribute2();
  }

  public void setAttribute2(String attribute2) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute2 == null) {
      builder.clearAttribute2();
    } else {
      builder.setAttribute2(attribute2);
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute3() {
    return dtoInstance.getAttribute3();
  }

  public void setAttribute3(String attribute3) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute3 == null) {
      builder.clearAttribute3();
    } else {
      builder.setAttribute3(attribute3);
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute4() {
    return dtoInstance.getAttribute4();
  }

  public void setAttribute4(String attribute4) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute4 == null) {
      builder.clearAttribute4();
    } else {
      builder.setAttribute4(attribute4);
    }
    this.dtoInstance = builder.build();
  }

  public String getAttribute5() {
    return dtoInstance.getAttribute5();
  }

  public void setAttribute5(String attribute5) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (attribute5 == null) {
      builder.clearAttribute5();
    } else {
      builder.setAttribute5(attribute5);
    }
    this.dtoInstance = builder.build();
  }

  public String getProductId() {
    return dtoInstance.getProductId();
  }

  public void setProductId(String productId) {
    ItemDTO.Builder builder = dtoInstance.toBuilder();
    if (productId == null) {
      builder.clearProductId();
    } else {
      builder.setProductId(productId);
    }
    this.dtoInstance = builder.build();
  }

  @Override
  public String toString() {
    return "Item{" + "itemId='" + getItemId() + "'" + ", productId='" + getProductId() + "'" + '}';
  }
}
