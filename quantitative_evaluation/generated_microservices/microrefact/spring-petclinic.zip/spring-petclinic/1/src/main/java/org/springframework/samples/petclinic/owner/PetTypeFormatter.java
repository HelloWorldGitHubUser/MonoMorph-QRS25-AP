package org.springframework.samples.petclinic.owner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.Formatter;
import org.springframework.stereotype.Component;
import java.text.ParseException;
import java.util.Collection;
import java.util.Locale;
import org.springframework.samples.petclinic.Interface.OwnerRepository;
import org.springframework.samples.petclinic.DTO.PetType;

@Component
public class PetTypeFormatter implements Formatter<PetType> {

	private OwnerRepository owners;

	@Autowired

	public PetTypeFormatter(OwnerRepository owners) {

		this.owners = owners;

	}

	@Override
	public String print(PetType petType, Locale locale) {

		return petType.getName();

	}

	@Override
	public PetType parse(String text, Locale locale) throws ParseException {

		Collection<PetType> findPetTypes = this.owners.findPetTypes();

		for (PetType type : findPetTypes) {

			if (type.getName().equals(text)) {

				return type;

			}

		}

		throw new ParseException("type not found: " + text, 0);

	}

}